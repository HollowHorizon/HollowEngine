
/** Generated code. DO NOT MODIFY! Changes to this file will be overwritten. **/

package com.sunnychung.lib.multiplatform.kotlite.stdlib

import com.sunnychung.lib.multiplatform.kotlite.model.AnyType
import com.sunnychung.lib.multiplatform.kotlite.model.BooleanValue
import com.sunnychung.lib.multiplatform.kotlite.model.ByteValue
import com.sunnychung.lib.multiplatform.kotlite.model.ComparableRuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionParameter
import com.sunnychung.lib.multiplatform.kotlite.model.CharValue
import com.sunnychung.lib.multiplatform.kotlite.model.DataType
import com.sunnychung.lib.multiplatform.kotlite.model.DelegatedValue
import com.sunnychung.lib.multiplatform.kotlite.model.DoubleValue
import com.sunnychung.lib.multiplatform.kotlite.model.ExtensionProperty
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionModifier
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionBodyFormat
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionType
import com.sunnychung.lib.multiplatform.kotlite.model.GlobalProperty
import com.sunnychung.lib.multiplatform.kotlite.model.IntValue
import com.sunnychung.lib.multiplatform.kotlite.model.IterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorClass
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.KotlinValueHolder
import com.sunnychung.lib.multiplatform.kotlite.model.LambdaValue
import com.sunnychung.lib.multiplatform.kotlite.model.LibraryModule
import com.sunnychung.lib.multiplatform.kotlite.model.ListClass
import com.sunnychung.lib.multiplatform.kotlite.model.ListValue
import com.sunnychung.lib.multiplatform.kotlite.model.LongValue
import com.sunnychung.lib.multiplatform.kotlite.model.NothingType
import com.sunnychung.lib.multiplatform.kotlite.model.NullValue
import com.sunnychung.lib.multiplatform.kotlite.model.ObjectType
import com.sunnychung.lib.multiplatform.kotlite.model.PairClass
import com.sunnychung.lib.multiplatform.kotlite.model.PairValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveType
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveTypeName
import com.sunnychung.lib.multiplatform.kotlite.model.ProvidedClassDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.SourcePosition
import com.sunnychung.lib.multiplatform.kotlite.model.StringValue
import com.sunnychung.lib.multiplatform.kotlite.model.FloatValue
import com.sunnychung.lib.multiplatform.kotlite.model.ShortValue
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameter
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameterType
import com.sunnychung.lib.multiplatform.kotlite.model.RuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.UnitType
import com.sunnychung.lib.multiplatform.kotlite.model.UnitValue
import com.sunnychung.lib.multiplatform.kotlite.util.wrapPrimitiveValueAsRuntimeValue

import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KInstantValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KZonedInstantValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KZoneOffsetValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KDurationValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KZonedDateTimeValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KDateValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KDateTimeFormatValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KDateTimeFormattableInterface
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KPointOfTimeValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KFixedTimeUnitValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KInstantClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KZonedInstantClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KZoneOffsetClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KDurationClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KZonedDateTimeClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KDateClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KDateTimeFormatClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KPointOfTimeClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.kdatetime.KFixedTimeUnitClass
import com.sunnychung.lib.multiplatform.kdatetime.KFixedTimeUnit
import com.sunnychung.lib.multiplatform.kdatetime.KInstant
import com.sunnychung.lib.multiplatform.kdatetime.KZonedInstant
import com.sunnychung.lib.multiplatform.kdatetime.KZoneOffset
import com.sunnychung.lib.multiplatform.kdatetime.KDuration
import com.sunnychung.lib.multiplatform.kdatetime.KZonedDateTime
import com.sunnychung.lib.multiplatform.kdatetime.KDate
import com.sunnychung.lib.multiplatform.kdatetime.KDateTimeFormat
import com.sunnychung.lib.multiplatform.kdatetime.KDateTimeFormattable
import com.sunnychung.lib.multiplatform.kdatetime.KPointOfTime
import com.sunnychung.lib.multiplatform.kdatetime.toKZonedDateTime
import com.sunnychung.lib.multiplatform.kdatetime.extension.milliseconds
import com.sunnychung.lib.multiplatform.kdatetime.extension.seconds
import com.sunnychung.lib.multiplatform.kdatetime.extension.minutes
import com.sunnychung.lib.multiplatform.kdatetime.extension.hours
import com.sunnychung.lib.multiplatform.kdatetime.extension.days
import com.sunnychung.lib.multiplatform.kdatetime.extension.weeks




abstract class AbstractKDateTimeLibModule : LibraryModule("KDateTime") {
    override val classes = emptyList<ProvidedClassDefinition>()

    override val properties = listOf<ExtensionProperty>(
        ExtensionProperty(
            declaredName = "zoneOffset",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KZonedInstant",
            type = "KZoneOffset",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedInstant
                val result = unwrappedReceiver.zoneOffset
                result?.let { KZoneOffsetValue(it /* _t = KZoneOffset; t.name = KZoneOffset; t = KZoneOffset */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "UTC",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KZoneOffset.Companion",
            type = "KZoneOffset",
            getter = { interpreter, receiver, typeArgs ->
        
                val result = KZoneOffset.Companion.UTC
                result?.let { KZoneOffsetValue(it /* _t = KZoneOffset; t.name = KZoneOffset; t = KZoneOffset */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "ZERO",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KDuration.Companion",
            type = "KDuration",
            getter = { interpreter, receiver, typeArgs ->
        
                val result = KDuration.Companion.ZERO
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "year",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KZonedDateTime",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val result = unwrappedReceiver.year
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "month",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KZonedDateTime",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val result = unwrappedReceiver.month
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "day",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KZonedDateTime",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val result = unwrappedReceiver.day
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "hour",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KZonedDateTime",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val result = unwrappedReceiver.hour
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "minute",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KZonedDateTime",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val result = unwrappedReceiver.minute
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "second",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KZonedDateTime",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val result = unwrappedReceiver.second
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "millisecond",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KZonedDateTime",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val result = unwrappedReceiver.millisecond
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "zoneOffset",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KZonedDateTime",
            type = "KZoneOffset",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val result = unwrappedReceiver.zoneOffset
                result?.let { KZoneOffsetValue(it /* _t = KZoneOffset; t.name = KZoneOffset; t = KZoneOffset */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "pattern",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KDateTimeFormat",
            type = "String",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDateTimeFormat
                val result = unwrappedReceiver.pattern
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "weekDayNames",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KDateTimeFormat",
            type = "List<String>",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDateTimeFormat
                val result = unwrappedReceiver.weekDayNames
                result?.map { StringValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, interpreter.symbolTable().StringType /* _t = List<String>; t.name = List; t = List<String> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = { interpreter, receiver, value, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDateTimeFormat
                val unwrappedValue = (value as KotlinValueHolder<List<*>>).value.map { (it as StringValue).value }
                unwrappedReceiver.weekDayNames = unwrappedValue
            },
        ),

        ExtensionProperty(
            declaredName = "ISO8601_DATETIME",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KDateTimeFormat.Companion",
            type = "KDateTimeFormat",
            getter = { interpreter, receiver, typeArgs ->
        
                val result = KDateTimeFormat.Companion.ISO8601_DATETIME
                result?.let { KDateTimeFormatValue(it /* _t = KDateTimeFormat; t.name = KDateTimeFormat; t = KDateTimeFormat */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "FULL",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KDateTimeFormat.Companion",
            type = "KDateTimeFormat",
            getter = { interpreter, receiver, typeArgs ->
        
                val result = KDateTimeFormat.Companion.FULL
                result?.let { KDateTimeFormatValue(it /* _t = KDateTimeFormat; t.name = KDateTimeFormat; t = KDateTimeFormat */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "ISO8601_FORMATS",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KDateTimeFormat.Companion",
            type = "List<KDateTimeFormat>",
            getter = { interpreter, receiver, typeArgs ->
        
                val result = KDateTimeFormat.Companion.ISO8601_FORMATS
                result?.map { KDateTimeFormatValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, ObjectType(KDateTimeFormatClass.clazz, listOf<DataType>(), superTypes = emptyList()) /* _t = List<KDateTimeFormat>; t.name = List; t = List<KDateTimeFormat> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "IOS_DATE_FORMATS",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KDateTimeFormat.Companion",
            type = "List<KDateTimeFormat>",
            getter = { interpreter, receiver, typeArgs ->
        
                val result = KDateTimeFormat.Companion.IOS_DATE_FORMATS
                result?.map { KDateTimeFormatValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, ObjectType(KDateTimeFormatClass.clazz, listOf<DataType>(), superTypes = emptyList()) /* _t = List<KDateTimeFormat>; t.name = List; t = List<KDateTimeFormat> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "WEEKDAY_NAMES",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "KDateTimeFormat.Companion",
            type = "List<String>",
            getter = { interpreter, receiver, typeArgs ->
        
                val result = KDateTimeFormat.Companion.WEEKDAY_NAMES
                result?.map { StringValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, interpreter.symbolTable().StringType /* _t = List<String>; t.name = List; t = List<String> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

    )
    
    override val globalProperties = emptyList<GlobalProperty>()
    
    override val functions = listOf<CustomFunctionDefinition>(
        CustomFunctionDefinition(
            receiverType = "KInstant",
            functionName = "plus",
            returnType = "KInstant",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "duration", type = "KDuration"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KInstant
                val duration_ = (args[0] as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.plus(duration_)
                result?.let { KInstantValue(it /* _t = KInstant; t.name = KInstant; t = KInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 1, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KInstant",
            functionName = "minus",
            returnType = "KInstant",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "duration", type = "KDuration"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KInstant
                val duration_ = (args[0] as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.minus(duration_)
                result?.let { KInstantValue(it /* _t = KInstant; t.name = KInstant; t = KInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 2, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KInstant",
            functionName = "at",
            returnType = "KZonedInstant",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "zoneOffset", type = "KZoneOffset"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KInstant
                val zoneOffset_ = (args[0] as KotlinValueHolder<*>).value as KZoneOffset
        
                val result = unwrappedReceiver.at(zoneOffset_)
                result?.let { KZonedInstantValue(it /* _t = KZonedInstant; t.name = KZonedInstant; t = KZonedInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 3, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "KInstant",
            functionName = "atZoneOffset",
            returnType = "KZonedInstant",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "zoneOffset", type = "KZoneOffset"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KInstant
                val zoneOffset_ = (args[0] as KotlinValueHolder<*>).value as KZoneOffset
        
                val result = unwrappedReceiver.atZoneOffset(zoneOffset_)
                result?.let { KZonedInstantValue(it /* _t = KZonedInstant; t.name = KZonedInstant; t = KZonedInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 4, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KInstant",
            functionName = "atLocalZoneOffset",
            returnType = "KZonedInstant",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KInstant
        
                val result = unwrappedReceiver.atLocalZoneOffset()
                result?.let { KZonedInstantValue(it /* _t = KZonedInstant; t.name = KZonedInstant; t = KZonedInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 5, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KInstant.Companion",
            functionName = "now",
            returnType = "KInstant",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
        
                val result = KInstant.Companion.now()
                result?.let { KInstantValue(it /* _t = KInstant; t.name = KInstant; t = KInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 6, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KInstant.Companion",
            functionName = "parseFrom",
            returnType = "KInstant",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "input", type = "String"),
                CustomFunctionParameter(name = "formats", type = "List<KDateTimeFormat>"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val input_ = (args[0] as StringValue).value
            val formats_ = (args[1] as KotlinValueHolder<List<*>>).value.map { (it as KotlinValueHolder<*>).value as KDateTimeFormat }
        
                val result = KInstant.Companion.parseFrom(input_, formats_)
                result?.let { KInstantValue(it /* _t = KInstant; t.name = KInstant; t = KInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 7, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDateTimeFormattable",
            functionName = "toMilliseconds",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDateTimeFormattable
        
                val result = unwrappedReceiver.toMilliseconds()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 9, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDateTimeFormattable",
            functionName = "hourPart",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDateTimeFormattable
        
                val result = unwrappedReceiver.hourPart()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 10, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDateTimeFormattable",
            functionName = "minutePart",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDateTimeFormattable
        
                val result = unwrappedReceiver.minutePart()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 11, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDateTimeFormattable",
            functionName = "secondPart",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDateTimeFormattable
        
                val result = unwrappedReceiver.secondPart()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 12, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDateTimeFormattable",
            functionName = "millisecondPart",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDateTimeFormattable
        
                val result = unwrappedReceiver.millisecondPart()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 13, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDateTimeFormattable",
            functionName = "format",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "pattern", type = "String"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDateTimeFormattable
                val pattern_ = (args[0] as StringValue).value
        
                val result = unwrappedReceiver.format(pattern_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 14, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KPointOfTime",
            functionName = "toEpochMilliseconds",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KPointOfTime
        
                val result = unwrappedReceiver.toEpochMilliseconds()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 16, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KPointOfTime",
            functionName = "minus",
            returnType = "KDuration",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "KPointOfTime"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KPointOfTime
                val other_ = (args[0] as KotlinValueHolder<*>).value as KPointOfTime
        
                val result = unwrappedReceiver.minus(other_)
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 17, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KPointOfTime",
            functionName = "toIso8601String",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KPointOfTime
        
                val result = unwrappedReceiver.toIso8601String()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 18, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KPointOfTime",
            functionName = "toIso8601StringWithMilliseconds",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KPointOfTime
        
                val result = unwrappedReceiver.toIso8601StringWithMilliseconds()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 19, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KPointOfTime",
            functionName = "compareTo",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "KPointOfTime"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KPointOfTime
                val other_ = (args[0] as KotlinValueHolder<*>).value as KPointOfTime
        
                val result = unwrappedReceiver.compareTo(other_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 20, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedInstant",
            functionName = "plus",
            returnType = "KZonedInstant",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "duration", type = "KDuration"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedInstant
                val duration_ = (args[0] as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.plus(duration_)
                result?.let { KZonedInstantValue(it /* _t = KZonedInstant; t.name = KZonedInstant; t = KZonedInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 22, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedInstant",
            functionName = "minus",
            returnType = "KZonedInstant",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "duration", type = "KDuration"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedInstant
                val duration_ = (args[0] as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.minus(duration_)
                result?.let { KZonedInstantValue(it /* _t = KZonedInstant; t.name = KZonedInstant; t = KZonedInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 23, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedInstant",
            functionName = "startOfDay",
            returnType = "KZonedInstant",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedInstant
        
                val result = unwrappedReceiver.startOfDay()
                result?.let { KZonedInstantValue(it /* _t = KZonedInstant; t.name = KZonedInstant; t = KZonedInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 24, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedInstant",
            functionName = "dropZoneOffset",
            returnType = "KInstant",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedInstant
        
                val result = unwrappedReceiver.dropZoneOffset()
                result?.let { KInstantValue(it /* _t = KInstant; t.name = KInstant; t = KInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 25, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedInstant.Companion",
            functionName = "nowAtLocalZoneOffset",
            returnType = "KZonedInstant",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
        
                val result = KZonedInstant.Companion.nowAtLocalZoneOffset()
                result?.let { KZonedInstantValue(it /* _t = KZonedInstant; t.name = KZonedInstant; t = KZonedInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 26, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedInstant.Companion",
            functionName = "nowAtZoneOffset",
            returnType = "KZonedInstant",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "zoneOffset", type = "KZoneOffset"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val zoneOffset_ = (args[0] as KotlinValueHolder<*>).value as KZoneOffset
        
                val result = KZonedInstant.Companion.nowAtZoneOffset(zoneOffset_)
                result?.let { KZonedInstantValue(it /* _t = KZonedInstant; t.name = KZonedInstant; t = KZonedInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 27, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedInstant.Companion",
            functionName = "parseFrom",
            returnType = "KZonedInstant",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "input", type = "String"),
                CustomFunctionParameter(name = "formats", type = "List<KDateTimeFormat>"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val input_ = (args[0] as StringValue).value
            val formats_ = (args[1] as KotlinValueHolder<List<*>>).value.map { (it as KotlinValueHolder<*>).value as KDateTimeFormat }
        
                val result = KZonedInstant.Companion.parseFrom(input_, formats_)
                result?.let { KZonedInstantValue(it /* _t = KZonedInstant; t.name = KZonedInstant; t = KZonedInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 28, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedInstant.Companion",
            functionName = "parseFromIso8601String",
            returnType = "KZonedInstant",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "input", type = "String"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val input_ = (args[0] as StringValue).value
        
                val result = KZonedInstant.Companion.parseFromIso8601String(input_)
                result?.let { KZonedInstantValue(it /* _t = KZonedInstant; t.name = KZonedInstant; t = KZonedInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 29, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedInstant",
            functionName = "toKZonedDateTime",
            returnType = "KZonedDateTime",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedInstant
        
                val result = unwrappedReceiver.toKZonedDateTime()
                result?.let { KZonedDateTimeValue(it /* _t = KZonedDateTime; t.name = KZonedDateTime; t = KZonedDateTime */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 30, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZoneOffset",
            functionName = "toMilliseconds",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZoneOffset
        
                val result = unwrappedReceiver.toMilliseconds()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 34, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZoneOffset",
            functionName = "toDisplayString",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZoneOffset
        
                val result = unwrappedReceiver.toDisplayString()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 35, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZoneOffset.Companion",
            functionName = "parseFrom",
            returnType = "KZoneOffset",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "string", type = "String"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val string_ = (args[0] as StringValue).value
        
                val result = KZoneOffset.Companion.parseFrom(string_)
                result?.let { KZoneOffsetValue(it /* _t = KZoneOffset; t.name = KZoneOffset; t = KZoneOffset */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 38, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZoneOffset.Companion",
            functionName = "fromMilliseconds",
            returnType = "KZoneOffset",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "millis", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val millis_ = (args[0] as LongValue).value
        
                val result = KZoneOffset.Companion.fromMilliseconds(millis_)
                result?.let { KZoneOffsetValue(it /* _t = KZoneOffset; t.name = KZoneOffset; t = KZoneOffset */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 39, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZoneOffset.Companion",
            functionName = "local",
            returnType = "KZoneOffset",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
        
                val result = KZoneOffset.Companion.local()
                result?.let { KZoneOffsetValue(it /* _t = KZoneOffset; t.name = KZoneOffset; t = KZoneOffset */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 40, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDuration",
            functionName = "plus",
            returnType = "KDuration",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "KDuration"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDuration
                val other_ = (args[0] as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.plus(other_)
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 42, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KDuration",
            functionName = "minus",
            returnType = "KDuration",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "KDuration"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDuration
                val other_ = (args[0] as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.minus(other_)
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 43, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KDuration",
            functionName = "compareTo",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "KDuration"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDuration
                val other_ = (args[0] as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.compareTo(other_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 44, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KDuration",
            functionName = "toSeconds",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.toSeconds()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 49, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDuration",
            functionName = "toMinutes",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.toMinutes()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 50, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDuration",
            functionName = "toHours",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.toHours()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 51, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDuration",
            functionName = "toDays",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.toDays()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 52, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDuration",
            functionName = "toWeeks",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.toWeeks()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 53, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedDateTime",
            functionName = "toKZonedInstant",
            returnType = "KZonedInstant",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
        
                val result = unwrappedReceiver.toKZonedInstant()
                result?.let { KZonedInstantValue(it /* _t = KZonedInstant; t.name = KZonedInstant; t = KZonedInstant */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 55, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedDateTime",
            functionName = "startOfDay",
            returnType = "KZonedDateTime",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
        
                val result = unwrappedReceiver.startOfDay()
                result?.let { KZonedDateTimeValue(it /* _t = KZonedDateTime; t.name = KZonedDateTime; t = KZonedDateTime */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 57, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedDateTime",
            functionName = "copy",
            returnType = "KZonedDateTime",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "year", type = "Int?", defaultValueExpression = "null"),
                CustomFunctionParameter(name = "month", type = "Int?", defaultValueExpression = "null"),
                CustomFunctionParameter(name = "day", type = "Int?", defaultValueExpression = "null"),
                CustomFunctionParameter(name = "hour", type = "Int?", defaultValueExpression = "null"),
                CustomFunctionParameter(name = "minute", type = "Int?", defaultValueExpression = "null"),
                CustomFunctionParameter(name = "second", type = "Int?", defaultValueExpression = "null"),
                CustomFunctionParameter(name = "millisecond", type = "Int?", defaultValueExpression = "null"),
                CustomFunctionParameter(name = "zoneOffset", type = "KZoneOffset?", defaultValueExpression = "null"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val year_ = (args[0] as? IntValue)?.value
            val month_ = (args[1] as? IntValue)?.value
            val day_ = (args[2] as? IntValue)?.value
            val hour_ = (args[3] as? IntValue)?.value
            val minute_ = (args[4] as? IntValue)?.value
            val second_ = (args[5] as? IntValue)?.value
            val millisecond_ = (args[6] as? IntValue)?.value
            val zoneOffset_ = (args[7] as? KotlinValueHolder<*>)?.value as KZoneOffset?
        
                val result = unwrappedReceiver.copy(year_, month_, day_, hour_, minute_, second_, millisecond_, zoneOffset_)
                result?.let { KZonedDateTimeValue(it /* _t = KZonedDateTime; t.name = KZonedDateTime; t = KZonedDateTime */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 58, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedDateTime",
            functionName = "format",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "pattern", type = "String"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val pattern_ = (args[0] as StringValue).value
        
                val result = unwrappedReceiver.format(pattern_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 68, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedDateTime",
            functionName = "toIso8601String",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
        
                val result = unwrappedReceiver.toIso8601String()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 69, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedDateTime",
            functionName = "toIso8601StringWithMilliseconds",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
        
                val result = unwrappedReceiver.toIso8601StringWithMilliseconds()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 70, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedDateTime",
            functionName = "plus",
            returnType = "KZonedDateTime",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "duration", type = "KDuration"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val duration_ = (args[0] as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.plus(duration_)
                result?.let { KZonedDateTimeValue(it /* _t = KZonedDateTime; t.name = KZonedDateTime; t = KZonedDateTime */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 71, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedDateTime",
            functionName = "minus",
            returnType = "KZonedDateTime",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "duration", type = "KDuration"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val duration_ = (args[0] as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.minus(duration_)
                result?.let { KZonedDateTimeValue(it /* _t = KZonedDateTime; t.name = KZonedDateTime; t = KZonedDateTime */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 72, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedDateTime",
            functionName = "minus",
            returnType = "KDuration",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "dateTime", type = "KZonedDateTime"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
                val dateTime_ = (args[0] as KotlinValueHolder<*>).value as KZonedDateTime
        
                val result = unwrappedReceiver.minus(dateTime_)
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 73, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "KDateTimeFormat",
            functionName = "format",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "datetime", type = "KDateTimeFormattable"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDateTimeFormat
                val datetime_ = (args[0] as KotlinValueHolder<*>).value as KDateTimeFormattable
        
                val result = unwrappedReceiver.format(datetime_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 100, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDateTimeFormat",
            functionName = "parseToKZonedDateTime",
            returnType = "KZonedDateTime",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "input", type = "String"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDateTimeFormat
                val input_ = (args[0] as StringValue).value
        
                val result = unwrappedReceiver.parseToKZonedDateTime(input_)
                result?.let { KZonedDateTimeValue(it /* _t = KZonedDateTime; t.name = KZonedDateTime; t = KZonedDateTime */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 101, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "milliseconds",
            returnType = "KDuration",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
        
                val result = unwrappedReceiver.milliseconds()
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 128, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "milliseconds",
            returnType = "KDuration",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
        
                val result = unwrappedReceiver.milliseconds()
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 129, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "seconds",
            returnType = "KDuration",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
        
                val result = unwrappedReceiver.seconds()
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 130, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "seconds",
            returnType = "KDuration",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
        
                val result = unwrappedReceiver.seconds()
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 131, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "minutes",
            returnType = "KDuration",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
        
                val result = unwrappedReceiver.minutes()
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 132, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "hours",
            returnType = "KDuration",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
        
                val result = unwrappedReceiver.hours()
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 133, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "days",
            returnType = "KDuration",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
        
                val result = unwrappedReceiver.days()
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 134, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "weeks",
            returnType = "KDuration",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
        
                val result = unwrappedReceiver.weeks()
                result?.let { KDurationValue(it /* _t = KDuration; t.name = KDuration; t = KDuration */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 135, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KInstant",
            functionName = "toString",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KInstant
        
                val result = unwrappedReceiver.toString()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 137, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedInstant",
            functionName = "toString",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedInstant
        
                val result = unwrappedReceiver.toString()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 138, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZonedDateTime",
            functionName = "toString",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZonedDateTime
        
                val result = unwrappedReceiver.toString()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 139, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KZoneOffset",
            functionName = "toString",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KZoneOffset
        
                val result = unwrappedReceiver.toString()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 140, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KDuration",
            functionName = "toString",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KDuration
        
                val result = unwrappedReceiver.toString()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "KDateTime", lineNum = 141, col = 1),
        ),

    )
}
