
/** Generated code. DO NOT MODIFY! Changes to this file will be overwritten. **/

package com.sunnychung.lib.multiplatform.kotlite.stdlib

import com.sunnychung.lib.multiplatform.kotlite.model.AnyType
import com.sunnychung.lib.multiplatform.kotlite.model.BooleanValue
import com.sunnychung.lib.multiplatform.kotlite.model.ByteValue
import com.sunnychung.lib.multiplatform.kotlite.model.ComparableRuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionParameter
import com.sunnychung.lib.multiplatform.kotlite.model.CharValue
import com.sunnychung.lib.multiplatform.kotlite.model.DataType
import com.sunnychung.lib.multiplatform.kotlite.model.DelegatedValue
import com.sunnychung.lib.multiplatform.kotlite.model.DoubleValue
import com.sunnychung.lib.multiplatform.kotlite.model.ExtensionProperty
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionModifier
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionBodyFormat
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionType
import com.sunnychung.lib.multiplatform.kotlite.model.GlobalProperty
import com.sunnychung.lib.multiplatform.kotlite.model.IntValue
import com.sunnychung.lib.multiplatform.kotlite.model.IterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorClass
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.KotlinValueHolder
import com.sunnychung.lib.multiplatform.kotlite.model.LambdaValue
import com.sunnychung.lib.multiplatform.kotlite.model.LibraryModule
import com.sunnychung.lib.multiplatform.kotlite.model.ListClass
import com.sunnychung.lib.multiplatform.kotlite.model.ListValue
import com.sunnychung.lib.multiplatform.kotlite.model.LongValue
import com.sunnychung.lib.multiplatform.kotlite.model.NothingType
import com.sunnychung.lib.multiplatform.kotlite.model.NullValue
import com.sunnychung.lib.multiplatform.kotlite.model.ObjectType
import com.sunnychung.lib.multiplatform.kotlite.model.PairClass
import com.sunnychung.lib.multiplatform.kotlite.model.PairValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveType
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveTypeName
import com.sunnychung.lib.multiplatform.kotlite.model.ProvidedClassDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.SourcePosition
import com.sunnychung.lib.multiplatform.kotlite.model.StringValue
import com.sunnychung.lib.multiplatform.kotlite.model.FloatValue
import com.sunnychung.lib.multiplatform.kotlite.model.ShortValue
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameter
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameterType
import com.sunnychung.lib.multiplatform.kotlite.model.RuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.UnitType
import com.sunnychung.lib.multiplatform.kotlite.model.UnitValue
import com.sunnychung.lib.multiplatform.kotlite.util.wrapPrimitiveValueAsRuntimeValue

import kotlin.math.*




abstract class AbstractMathLibModule : LibraryModule("Math") {
    override val classes = emptyList<ProvidedClassDefinition>()

    override val properties = listOf<ExtensionProperty>(
        ExtensionProperty(
            declaredName = "absoluteValue",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "Double",
            type = "Double",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
                val result = unwrappedReceiver.absoluteValue
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "absoluteValue",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "Int",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val result = unwrappedReceiver.absoluteValue
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "absoluteValue",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "Long",
            type = "Long",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val result = unwrappedReceiver.absoluteValue
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "sign",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "Double",
            type = "Double",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
                val result = unwrappedReceiver.sign
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "sign",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "Int",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val result = unwrappedReceiver.sign
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "sign",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "Long",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val result = unwrappedReceiver.sign
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

    )
    
    override val globalProperties = emptyList<GlobalProperty>()
    
    override val functions = listOf<CustomFunctionDefinition>(
        CustomFunctionDefinition(
            receiverType = null,
            functionName = "abs",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = abs(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 9, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "abs",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as IntValue).value
        
                val result = abs(x_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 10, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "abs",
            returnType = "Long",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as LongValue).value
        
                val result = abs(x_)
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 11, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "acos",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = acos(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 12, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "acosh",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = acosh(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 13, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "asin",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = asin(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 14, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "asinh",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = asinh(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 15, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "atan",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = atan(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 16, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "atan2",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "y", type = "Double"),
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val y_ = (args[0] as DoubleValue).value
            val x_ = (args[1] as DoubleValue).value
        
                val result = atan2(y_, x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 17, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "atanh",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = atanh(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 18, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "cbrt",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = cbrt(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 19, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "ceil",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = ceil(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 20, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "cos",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = cos(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 21, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "cosh",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = cosh(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 22, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "exp",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = exp(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 23, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "expm1",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = expm1(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 24, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "floor",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = floor(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 25, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "hypot",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
                CustomFunctionParameter(name = "y", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
            val y_ = (args[1] as DoubleValue).value
        
                val result = hypot(x_, y_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 26, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "ln",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = ln(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 27, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "ln1p",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = ln1p(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 28, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "log",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
                CustomFunctionParameter(name = "base", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
            val base_ = (args[1] as DoubleValue).value
        
                val result = log(x_, base_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 29, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "log10",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = log10(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 30, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "log2",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = log2(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 31, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "max",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "a", type = "Double"),
                CustomFunctionParameter(name = "b", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val a_ = (args[0] as DoubleValue).value
            val b_ = (args[1] as DoubleValue).value
        
                val result = max(a_, b_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 32, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "max",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "a", type = "Int"),
                CustomFunctionParameter(name = "b", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val a_ = (args[0] as IntValue).value
            val b_ = (args[1] as IntValue).value
        
                val result = max(a_, b_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 33, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "max",
            returnType = "Long",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "a", type = "Long"),
                CustomFunctionParameter(name = "b", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val a_ = (args[0] as LongValue).value
            val b_ = (args[1] as LongValue).value
        
                val result = max(a_, b_)
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 34, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "min",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "a", type = "Double"),
                CustomFunctionParameter(name = "b", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val a_ = (args[0] as DoubleValue).value
            val b_ = (args[1] as DoubleValue).value
        
                val result = min(a_, b_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 35, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "min",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "a", type = "Int"),
                CustomFunctionParameter(name = "b", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val a_ = (args[0] as IntValue).value
            val b_ = (args[1] as IntValue).value
        
                val result = min(a_, b_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 36, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "min",
            returnType = "Long",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "a", type = "Long"),
                CustomFunctionParameter(name = "b", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val a_ = (args[0] as LongValue).value
            val b_ = (args[1] as LongValue).value
        
                val result = min(a_, b_)
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 37, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "round",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = round(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 38, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "sign",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = sign(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 39, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "sin",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = sin(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 40, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "sinh",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = sinh(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 41, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "sqrt",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = sqrt(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 42, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "tan",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = tan(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 43, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "tanh",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = tanh(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 44, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "truncate",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val x_ = (args[0] as DoubleValue).value
        
                val result = truncate(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 45, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "nextDown",
            returnType = "Double",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
        
                val result = unwrappedReceiver.nextDown()
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 47, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "nextTowards",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
                val to_ = (args[0] as DoubleValue).value
        
                val result = unwrappedReceiver.nextTowards(to_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 48, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "nextUp",
            returnType = "Double",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
        
                val result = unwrappedReceiver.nextUp()
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 49, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "pow",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "x", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
                val x_ = (args[0] as DoubleValue).value
        
                val result = unwrappedReceiver.pow(x_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 50, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "pow",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.pow(n_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 51, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "roundToInt",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
        
                val result = unwrappedReceiver.roundToInt()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 52, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "roundToLong",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
        
                val result = unwrappedReceiver.roundToLong()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 53, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "withSign",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "sign", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
                val sign_ = (args[0] as DoubleValue).value
        
                val result = unwrappedReceiver.withSign(sign_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 54, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "withSign",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "sign", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
                val sign_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.withSign(sign_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Math", lineNum = 55, col = 1),
        ),

    )
}
