
/** Generated code. DO NOT MODIFY! Changes to this file will be overwritten. **/

package com.sunnychung.lib.multiplatform.kotlite.stdlib

import com.sunnychung.lib.multiplatform.kotlite.model.AnyType
import com.sunnychung.lib.multiplatform.kotlite.model.BooleanValue
import com.sunnychung.lib.multiplatform.kotlite.model.ByteValue
import com.sunnychung.lib.multiplatform.kotlite.model.ComparableRuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionParameter
import com.sunnychung.lib.multiplatform.kotlite.model.CharValue
import com.sunnychung.lib.multiplatform.kotlite.model.DataType
import com.sunnychung.lib.multiplatform.kotlite.model.DelegatedValue
import com.sunnychung.lib.multiplatform.kotlite.model.DoubleValue
import com.sunnychung.lib.multiplatform.kotlite.model.ExtensionProperty
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionModifier
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionBodyFormat
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionType
import com.sunnychung.lib.multiplatform.kotlite.model.GlobalProperty
import com.sunnychung.lib.multiplatform.kotlite.model.IntValue
import com.sunnychung.lib.multiplatform.kotlite.model.IterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorClass
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.KotlinValueHolder
import com.sunnychung.lib.multiplatform.kotlite.model.LambdaValue
import com.sunnychung.lib.multiplatform.kotlite.model.LibraryModule
import com.sunnychung.lib.multiplatform.kotlite.model.ListClass
import com.sunnychung.lib.multiplatform.kotlite.model.ListValue
import com.sunnychung.lib.multiplatform.kotlite.model.LongValue
import com.sunnychung.lib.multiplatform.kotlite.model.NothingType
import com.sunnychung.lib.multiplatform.kotlite.model.NullValue
import com.sunnychung.lib.multiplatform.kotlite.model.ObjectType
import com.sunnychung.lib.multiplatform.kotlite.model.PairClass
import com.sunnychung.lib.multiplatform.kotlite.model.PairValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveType
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveTypeName
import com.sunnychung.lib.multiplatform.kotlite.model.ProvidedClassDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.SourcePosition
import com.sunnychung.lib.multiplatform.kotlite.model.StringValue
import com.sunnychung.lib.multiplatform.kotlite.model.FloatValue
import com.sunnychung.lib.multiplatform.kotlite.model.ShortValue
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameter
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameterType
import com.sunnychung.lib.multiplatform.kotlite.model.RuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.UnitType
import com.sunnychung.lib.multiplatform.kotlite.model.UnitValue
import com.sunnychung.lib.multiplatform.kotlite.util.wrapPrimitiveValueAsRuntimeValue

import com.benasher44.uuid.Uuid
import com.benasher44.uuid.bytes
import com.benasher44.uuid.variant
import com.benasher44.uuid.version
import com.benasher44.uuid.uuidFrom
import com.benasher44.uuid.uuidOf
import com.benasher44.uuid.uuid4
import com.sunnychung.lib.multiplatform.kotlite.stdlib.byte.ByteArrayValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.uuid.UuidValue




abstract class AbstractUuidLibModule : LibraryModule("Uuid") {
    override val classes = emptyList<ProvidedClassDefinition>()

    override val properties = listOf<ExtensionProperty>(
        ExtensionProperty(
            declaredName = "mostSignificantBits",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "Uuid",
            type = "Long",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Uuid
                val result = unwrappedReceiver.mostSignificantBits
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "leastSignificantBits",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "Uuid",
            type = "Long",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Uuid
                val result = unwrappedReceiver.leastSignificantBits
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "bytes",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "Uuid",
            type = "ByteArray",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Uuid
                val result = unwrappedReceiver.bytes
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "variant",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "Uuid",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Uuid
                val result = unwrappedReceiver.variant
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "version",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "Uuid",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Uuid
                val result = unwrappedReceiver.version
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

    )
    
    override val globalProperties = emptyList<GlobalProperty>()
    
    override val functions = listOf<CustomFunctionDefinition>(
        CustomFunctionDefinition(
            receiverType = null,
            functionName = "uuid4",
            returnType = "Uuid",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
        
                val result = uuid4()
                result?.let { UuidValue(it /* _t = Uuid; t.name = Uuid; t = Uuid */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Uuid", lineNum = 1, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "uuidFrom",
            returnType = "Uuid",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "string", type = "String"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val string_ = (args[0] as StringValue).value
        
                val result = uuidFrom(string_)
                result?.let { UuidValue(it /* _t = Uuid; t.name = Uuid; t = Uuid */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Uuid", lineNum = 2, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "uuidOf",
            returnType = "Uuid",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "bytes", type = "ByteArray"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val bytes_ = (args[0] as KotlinValueHolder<*>).value as ByteArray
        
                val result = uuidOf(bytes_)
                result?.let { UuidValue(it /* _t = Uuid; t.name = Uuid; t = Uuid */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Uuid", lineNum = 3, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Uuid",
            functionName = "toString",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Uuid
        
                val result = unwrappedReceiver.toString()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Uuid", lineNum = 11, col = 1),
        ),

    )
}
