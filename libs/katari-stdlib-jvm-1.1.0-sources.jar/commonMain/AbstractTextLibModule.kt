
/** Generated code. DO NOT MODIFY! Changes to this file will be overwritten. **/

package com.sunnychung.lib.multiplatform.kotlite.stdlib

import com.sunnychung.lib.multiplatform.kotlite.model.AnyType
import com.sunnychung.lib.multiplatform.kotlite.model.BooleanValue
import com.sunnychung.lib.multiplatform.kotlite.model.ByteValue
import com.sunnychung.lib.multiplatform.kotlite.model.ComparableRuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionParameter
import com.sunnychung.lib.multiplatform.kotlite.model.CharValue
import com.sunnychung.lib.multiplatform.kotlite.model.DataType
import com.sunnychung.lib.multiplatform.kotlite.model.DelegatedValue
import com.sunnychung.lib.multiplatform.kotlite.model.DoubleValue
import com.sunnychung.lib.multiplatform.kotlite.model.ExtensionProperty
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionModifier
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionBodyFormat
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionType
import com.sunnychung.lib.multiplatform.kotlite.model.GlobalProperty
import com.sunnychung.lib.multiplatform.kotlite.model.IntValue
import com.sunnychung.lib.multiplatform.kotlite.model.IterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorClass
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.KotlinValueHolder
import com.sunnychung.lib.multiplatform.kotlite.model.LambdaValue
import com.sunnychung.lib.multiplatform.kotlite.model.LibraryModule
import com.sunnychung.lib.multiplatform.kotlite.model.ListClass
import com.sunnychung.lib.multiplatform.kotlite.model.ListValue
import com.sunnychung.lib.multiplatform.kotlite.model.LongValue
import com.sunnychung.lib.multiplatform.kotlite.model.NothingType
import com.sunnychung.lib.multiplatform.kotlite.model.NullValue
import com.sunnychung.lib.multiplatform.kotlite.model.ObjectType
import com.sunnychung.lib.multiplatform.kotlite.model.PairClass
import com.sunnychung.lib.multiplatform.kotlite.model.PairValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveType
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveTypeName
import com.sunnychung.lib.multiplatform.kotlite.model.ProvidedClassDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.SourcePosition
import com.sunnychung.lib.multiplatform.kotlite.model.StringValue
import com.sunnychung.lib.multiplatform.kotlite.model.FloatValue
import com.sunnychung.lib.multiplatform.kotlite.model.ShortValue
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameter
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameterType
import com.sunnychung.lib.multiplatform.kotlite.model.RuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.UnitType
import com.sunnychung.lib.multiplatform.kotlite.model.UnitValue
import com.sunnychung.lib.multiplatform.kotlite.util.wrapPrimitiveValueAsRuntimeValue





abstract class AbstractTextLibModule : LibraryModule("Text") {
    override val classes = emptyList<ProvidedClassDefinition>()

    override val properties = listOf<ExtensionProperty>(
        ExtensionProperty(
            declaredName = "length",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "String",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val result = unwrappedReceiver.length
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "lastIndex",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "String",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val result = unwrappedReceiver.lastIndex
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

    )
    
    override val globalProperties = emptyList<GlobalProperty>()
    
    override val functions = listOf<CustomFunctionDefinition>(
        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "all",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.all(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 9, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "any",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.any(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 10, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "commonPrefixWith",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "String"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val other_ = (args[0] as StringValue).value
            val ignoreCase_ = (args[1] as BooleanValue).value
        
                val result = unwrappedReceiver.commonPrefixWith(other_, ignoreCase_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 12, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "commonSuffixWith",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "String"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val other_ = (args[0] as StringValue).value
            val ignoreCase_ = (args[1] as BooleanValue).value
        
                val result = unwrappedReceiver.commonSuffixWith(other_, ignoreCase_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 13, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "compareTo",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "String"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val other_ = (args[0] as StringValue).value
            val ignoreCase_ = (args[1] as BooleanValue).value
        
                val result = unwrappedReceiver.compareTo(other_, ignoreCase_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 14, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "contains",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "String"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val other_ = (args[0] as StringValue).value
            val ignoreCase_ = (args[1] as BooleanValue).value
        
                val result = unwrappedReceiver.contains(other_, ignoreCase_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 15, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "contains",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "Char"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val other_ = (args[0] as CharValue).value
            val ignoreCase_ = (args[1] as BooleanValue).value
        
                val result = unwrappedReceiver.contains(other_, ignoreCase_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 16, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "count",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.count()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 17, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "drop",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.drop(n_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 18, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "dropLast",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.dropLast(n_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 19, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "dropLastWhile",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.dropLastWhile(predicate_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 20, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "dropWhile",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.dropWhile(predicate_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 21, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "endsWith",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "suffix", type = "String"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val suffix_ = (args[0] as StringValue).value
            val ignoreCase_ = (args[1] as BooleanValue).value
        
                val result = unwrappedReceiver.endsWith(suffix_, ignoreCase_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 22, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String?",
            functionName = "equals",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "String?"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as? StringValue)?.value
                val other_ = (args[0] as? StringValue)?.value
            val ignoreCase_ = (args[1] as BooleanValue).value
        
                val result = unwrappedReceiver.equals(other_, ignoreCase_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 23, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "filter",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filter(predicate_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 24, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "filterIndexed",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Int, Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: Char ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filterIndexed(predicate_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 25, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "filterNot",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filterNot(predicate_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 26, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "first",
            returnType = "Char",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.first()
                result?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 27, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "firstOrNull",
            returnType = "Char?",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.firstOrNull()
                result?.let { CharValue(it /* _t = Char?; t.name = Char; t = Char? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 28, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "forEach",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(Char) -> Unit"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    Unit
                } }
        
                val result = unwrappedReceiver.forEach(action_)
                UnitValue
            },
            position = SourcePosition(filename = "Text", lineNum = 31, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "forEachIndexed",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(Int, Char) -> Unit"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: Char ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    Unit
                } }
        
                val result = unwrappedReceiver.forEachIndexed(action_)
                UnitValue
            },
            position = SourcePosition(filename = "Text", lineNum = 32, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "getOrElse",
            returnType = "Char",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
                CustomFunctionParameter(name = "defaultValue", type = "(Int) -> Char"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val index_ = (args[0] as IntValue).value
            val defaultValue_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as CharValue).value
                } }
        
                val result = unwrappedReceiver.getOrElse(index_, defaultValue_)
                result?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 33, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "getOrNull",
            returnType = "Char?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val index_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.getOrNull(index_)
                result?.let { CharValue(it /* _t = Char?; t.name = Char; t = Char? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 34, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "indexOf",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "string", type = "String"),
                CustomFunctionParameter(name = "startIndex", type = "Int", defaultValueExpression = "0"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val string_ = (args[0] as StringValue).value
            val startIndex_ = (args[1] as IntValue).value
            val ignoreCase_ = (args[2] as BooleanValue).value
        
                val result = unwrappedReceiver.indexOf(string_, startIndex_, ignoreCase_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 35, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "indexOfFirst",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.indexOfFirst(predicate_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 36, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "indexOfLast",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.indexOfLast(predicate_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 37, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "isBlank",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.isBlank()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 38, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "isEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.isEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 39, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "isNotBlank",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.isNotBlank()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 40, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "isNotEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.isNotEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 41, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String?",
            functionName = "isNullOrBlank",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as? StringValue)?.value
        
                val result = unwrappedReceiver.isNullOrBlank()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 42, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String?",
            functionName = "isNullOrEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as? StringValue)?.value
        
                val result = unwrappedReceiver.isNullOrEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 43, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "last",
            returnType = "Char",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.last()
                result?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 44, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "lastIndexOf",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "string", type = "String"),
                CustomFunctionParameter(name = "startIndex", type = "Int", defaultValueExpression = "lastIndex"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val string_ = (args[0] as StringValue).value
            val startIndex_ = (args[1] as IntValue).value
            val ignoreCase_ = (args[2] as BooleanValue).value
        
                val result = unwrappedReceiver.lastIndexOf(string_, startIndex_, ignoreCase_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 45, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "lastOrNull",
            returnType = "Char?",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.lastOrNull()
                result?.let { CharValue(it /* _t = Char?; t.name = Char; t = Char? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 46, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "lowercase",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.lowercase()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 48, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "none",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.none(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 53, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String?",
            functionName = "orEmpty",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as? StringValue)?.value
        
                val result = unwrappedReceiver.orEmpty()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 54, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "padEnd",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "length", type = "Int"),
                CustomFunctionParameter(name = "padChar", type = "Char", defaultValueExpression = "' '"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val length_ = (args[0] as IntValue).value
            val padChar_ = (args[1] as CharValue).value
        
                val result = unwrappedReceiver.padEnd(length_, padChar_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 55, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "padStart",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "length", type = "Int"),
                CustomFunctionParameter(name = "padChar", type = "Char", defaultValueExpression = "' '"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val length_ = (args[0] as IntValue).value
            val padChar_ = (args[1] as CharValue).value
        
                val result = unwrappedReceiver.padStart(length_, padChar_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 56, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "prependIndent",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "indent", type = "String", defaultValueExpression = "\" \""),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val indent_ = (args[0] as StringValue).value
        
                val result = unwrappedReceiver.prependIndent(indent_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 57, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "random",
            returnType = "Char",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.random()
                result?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 58, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "randomOrNull",
            returnType = "Char?",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.randomOrNull()
                result?.let { CharValue(it /* _t = Char?; t.name = Char; t = Char? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 59, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "removePrefix",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "prefix", type = "String"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val prefix_ = (args[0] as StringValue).value
        
                val result = unwrappedReceiver.removePrefix(prefix_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 60, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "removeRange",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "startIndex", type = "Int"),
                CustomFunctionParameter(name = "endIndex", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val startIndex_ = (args[0] as IntValue).value
            val endIndex_ = (args[1] as IntValue).value
        
                val result = unwrappedReceiver.removeRange(startIndex_, endIndex_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 61, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "removeSuffix",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "suffix", type = "String"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val suffix_ = (args[0] as StringValue).value
        
                val result = unwrappedReceiver.removeSuffix(suffix_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 62, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "removeSurrounding",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "prefix", type = "String"),
                CustomFunctionParameter(name = "suffix", type = "String"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val prefix_ = (args[0] as StringValue).value
            val suffix_ = (args[1] as StringValue).value
        
                val result = unwrappedReceiver.removeSurrounding(prefix_, suffix_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 63, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "repeat",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.repeat(n_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 64, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "replace",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "oldValue", type = "Char"),
                CustomFunctionParameter(name = "newValue", type = "Char"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val oldValue_ = (args[0] as CharValue).value
            val newValue_ = (args[1] as CharValue).value
            val ignoreCase_ = (args[2] as BooleanValue).value
        
                val result = unwrappedReceiver.replace(oldValue_, newValue_, ignoreCase_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 65, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "replace",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "oldValue", type = "String"),
                CustomFunctionParameter(name = "newValue", type = "String"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val oldValue_ = (args[0] as StringValue).value
            val newValue_ = (args[1] as StringValue).value
            val ignoreCase_ = (args[2] as BooleanValue).value
        
                val result = unwrappedReceiver.replace(oldValue_, newValue_, ignoreCase_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 66, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "replaceAfter",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "delimiter", type = "String"),
                CustomFunctionParameter(name = "replacement", type = "String"),
                CustomFunctionParameter(name = "missingDelimiterValue", type = "String", defaultValueExpression = "this"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val delimiter_ = (args[0] as StringValue).value
            val replacement_ = (args[1] as StringValue).value
            val missingDelimiterValue_ = (args[2] as StringValue).value
        
                val result = unwrappedReceiver.replaceAfter(delimiter_, replacement_, missingDelimiterValue_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 67, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "replaceAfterLast",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "delimiter", type = "String"),
                CustomFunctionParameter(name = "replacement", type = "String"),
                CustomFunctionParameter(name = "missingDelimiterValue", type = "String", defaultValueExpression = "this"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val delimiter_ = (args[0] as StringValue).value
            val replacement_ = (args[1] as StringValue).value
            val missingDelimiterValue_ = (args[2] as StringValue).value
        
                val result = unwrappedReceiver.replaceAfterLast(delimiter_, replacement_, missingDelimiterValue_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 68, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "replaceBefore",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "delimiter", type = "String"),
                CustomFunctionParameter(name = "replacement", type = "String"),
                CustomFunctionParameter(name = "missingDelimiterValue", type = "String", defaultValueExpression = "this"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val delimiter_ = (args[0] as StringValue).value
            val replacement_ = (args[1] as StringValue).value
            val missingDelimiterValue_ = (args[2] as StringValue).value
        
                val result = unwrappedReceiver.replaceBefore(delimiter_, replacement_, missingDelimiterValue_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 69, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "replaceBeforeLast",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "delimiter", type = "String"),
                CustomFunctionParameter(name = "replacement", type = "String"),
                CustomFunctionParameter(name = "missingDelimiterValue", type = "String", defaultValueExpression = "this"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val delimiter_ = (args[0] as StringValue).value
            val replacement_ = (args[1] as StringValue).value
            val missingDelimiterValue_ = (args[2] as StringValue).value
        
                val result = unwrappedReceiver.replaceBeforeLast(delimiter_, replacement_, missingDelimiterValue_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 70, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "replaceFirst",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "oldValue", type = "String"),
                CustomFunctionParameter(name = "newValue", type = "String"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val oldValue_ = (args[0] as StringValue).value
            val newValue_ = (args[1] as StringValue).value
            val ignoreCase_ = (args[2] as BooleanValue).value
        
                val result = unwrappedReceiver.replaceFirst(oldValue_, newValue_, ignoreCase_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 71, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "replaceRange",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "startIndex", type = "Int"),
                CustomFunctionParameter(name = "endIndex", type = "Int"),
                CustomFunctionParameter(name = "replacement", type = "String"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val startIndex_ = (args[0] as IntValue).value
            val endIndex_ = (args[1] as IntValue).value
            val replacement_ = (args[2] as StringValue).value
        
                val result = unwrappedReceiver.replaceRange(startIndex_, endIndex_, replacement_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 72, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "reversed",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.reversed()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 73, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "single",
            returnType = "Char",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.single()
                result?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 74, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "singleOrNull",
            returnType = "Char?",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.singleOrNull()
                result?.let { CharValue(it /* _t = Char?; t.name = Char; t = Char? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 75, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "startsWith",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "prefix", type = "String"),
                CustomFunctionParameter(name = "ignoreCase", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val prefix_ = (args[0] as StringValue).value
            val ignoreCase_ = (args[1] as BooleanValue).value
        
                val result = unwrappedReceiver.startsWith(prefix_, ignoreCase_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 77, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "substring",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "startIndex", type = "Int"),
                CustomFunctionParameter(name = "endIndex", type = "Int", defaultValueExpression = "length"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val startIndex_ = (args[0] as IntValue).value
            val endIndex_ = (args[1] as IntValue).value
        
                val result = unwrappedReceiver.substring(startIndex_, endIndex_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 78, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "substringAfter",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "delimiter", type = "String"),
                CustomFunctionParameter(name = "missingDelimiterValue", type = "String", defaultValueExpression = "this"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val delimiter_ = (args[0] as StringValue).value
            val missingDelimiterValue_ = (args[1] as StringValue).value
        
                val result = unwrappedReceiver.substringAfter(delimiter_, missingDelimiterValue_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 79, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "substringAfterLast",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "delimiter", type = "String"),
                CustomFunctionParameter(name = "missingDelimiterValue", type = "String", defaultValueExpression = "this"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val delimiter_ = (args[0] as StringValue).value
            val missingDelimiterValue_ = (args[1] as StringValue).value
        
                val result = unwrappedReceiver.substringAfterLast(delimiter_, missingDelimiterValue_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 80, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "substringBefore",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "delimiter", type = "String"),
                CustomFunctionParameter(name = "missingDelimiterValue", type = "String", defaultValueExpression = "this"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val delimiter_ = (args[0] as StringValue).value
            val missingDelimiterValue_ = (args[1] as StringValue).value
        
                val result = unwrappedReceiver.substringBefore(delimiter_, missingDelimiterValue_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 81, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "substringBeforeLast",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "delimiter", type = "String"),
                CustomFunctionParameter(name = "missingDelimiterValue", type = "String", defaultValueExpression = "this"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val delimiter_ = (args[0] as StringValue).value
            val missingDelimiterValue_ = (args[1] as StringValue).value
        
                val result = unwrappedReceiver.substringBeforeLast(delimiter_, missingDelimiterValue_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 82, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "take",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.take(n_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 83, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "takeLast",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.takeLast(n_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 84, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "takeLastWhile",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.takeLastWhile(predicate_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 85, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "takeWhile",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Char) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Char ->
                    val wa0 = arg0?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.takeWhile(predicate_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 86, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String?",
            functionName = "toBoolean",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as? StringValue)?.value
        
                val result = unwrappedReceiver.toBoolean()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 87, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "toBooleanStrictOrNull",
            returnType = "Boolean?",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.toBooleanStrictOrNull()
                result?.let { BooleanValue(it /* _t = Boolean?; t.name = Boolean; t = Boolean? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 88, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "toDouble",
            returnType = "Double",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.toDouble()
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 89, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "toDoubleOrNull",
            returnType = "Double?",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.toDoubleOrNull()
                result?.let { DoubleValue(it /* _t = Double?; t.name = Double; t = Double? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 90, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "toInt",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.toInt()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 91, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "toInt",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "radix", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val radix_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.toInt(radix_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 92, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "toIntOrNull",
            returnType = "Int?",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.toIntOrNull()
                result?.let { IntValue(it /* _t = Int?; t.name = Int; t = Int? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 93, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "toIntOrNull",
            returnType = "Int?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "radix", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val radix_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.toIntOrNull(radix_)
                result?.let { IntValue(it /* _t = Int?; t.name = Int; t = Int? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 94, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "trim",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.trim()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 95, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "trimEnd",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.trimEnd()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 96, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "trimStart",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.trimStart()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 97, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "uppercase",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
        
                val result = unwrappedReceiver.uppercase()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 98, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "isDefined",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.isDefined()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 100, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "isDigit",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.isDigit()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 101, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "isHighSurrogate",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.isHighSurrogate()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 102, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "isISOControl",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.isISOControl()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 103, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "isLetter",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.isLetter()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 104, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "isLetterOrDigit",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.isLetterOrDigit()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 105, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "isLowerCase",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.isLowerCase()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 106, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "isLowSurrogate",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.isLowSurrogate()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 107, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "isSurrogate",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.isSurrogate()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 108, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "isUpperCase",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.isUpperCase()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 109, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "isWhitespace",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.isWhitespace()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 110, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "lowercase",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.lowercase()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 111, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "lowercaseChar",
            returnType = "Char",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.lowercaseChar()
                result?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 112, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "uppercase",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.uppercase()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 113, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Char",
            functionName = "uppercaseChar",
            returnType = "Char",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as CharValue).value
        
                val result = unwrappedReceiver.uppercaseChar()
                result?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Text", lineNum = 114, col = 1),
        ),

    )
}
