
/** Generated code. DO NOT MODIFY! Changes to this file will be overwritten. **/

package com.sunnychung.lib.multiplatform.kotlite.stdlib

import com.sunnychung.lib.multiplatform.kotlite.model.AnyType
import com.sunnychung.lib.multiplatform.kotlite.model.BooleanValue
import com.sunnychung.lib.multiplatform.kotlite.model.ByteValue
import com.sunnychung.lib.multiplatform.kotlite.model.ComparableRuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionParameter
import com.sunnychung.lib.multiplatform.kotlite.model.CharValue
import com.sunnychung.lib.multiplatform.kotlite.model.DataType
import com.sunnychung.lib.multiplatform.kotlite.model.DelegatedValue
import com.sunnychung.lib.multiplatform.kotlite.model.DoubleValue
import com.sunnychung.lib.multiplatform.kotlite.model.ExtensionProperty
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionModifier
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionBodyFormat
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionType
import com.sunnychung.lib.multiplatform.kotlite.model.GlobalProperty
import com.sunnychung.lib.multiplatform.kotlite.model.IntValue
import com.sunnychung.lib.multiplatform.kotlite.model.IterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorClass
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.KotlinValueHolder
import com.sunnychung.lib.multiplatform.kotlite.model.LambdaValue
import com.sunnychung.lib.multiplatform.kotlite.model.LibraryModule
import com.sunnychung.lib.multiplatform.kotlite.model.ListClass
import com.sunnychung.lib.multiplatform.kotlite.model.ListValue
import com.sunnychung.lib.multiplatform.kotlite.model.LongValue
import com.sunnychung.lib.multiplatform.kotlite.model.NothingType
import com.sunnychung.lib.multiplatform.kotlite.model.NullValue
import com.sunnychung.lib.multiplatform.kotlite.model.ObjectType
import com.sunnychung.lib.multiplatform.kotlite.model.PairClass
import com.sunnychung.lib.multiplatform.kotlite.model.PairValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveType
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveTypeName
import com.sunnychung.lib.multiplatform.kotlite.model.ProvidedClassDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.SourcePosition
import com.sunnychung.lib.multiplatform.kotlite.model.StringValue
import com.sunnychung.lib.multiplatform.kotlite.model.FloatValue
import com.sunnychung.lib.multiplatform.kotlite.model.ShortValue
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameter
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameterType
import com.sunnychung.lib.multiplatform.kotlite.model.RuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.UnitType
import com.sunnychung.lib.multiplatform.kotlite.model.UnitValue
import com.sunnychung.lib.multiplatform.kotlite.util.wrapPrimitiveValueAsRuntimeValue

import com.sunnychung.lib.multiplatform.kotlite.stdlib.byte.ByteArrayValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.byte.wrap
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.SetValue




abstract class AbstractByteLibModule : LibraryModule("Byte") {
    override val classes = emptyList<ProvidedClassDefinition>()

    override val properties = listOf<ExtensionProperty>(
        ExtensionProperty(
            declaredName = "lastIndex",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "ByteArray",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val result = unwrappedReceiver.lastIndex
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "size",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "ByteArray",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val result = unwrappedReceiver.size
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

    )
    
    override val globalProperties = emptyList<GlobalProperty>()
    
    override val functions = listOf<CustomFunctionDefinition>(
        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "toByte",
            returnType = "Byte",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
        
                val result = unwrappedReceiver.toByte()
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 3, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "toByte",
            returnType = "Byte",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
        
                val result = unwrappedReceiver.toByte()
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 4, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Byte",
            functionName = "toInt",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as ByteValue).value
        
                val result = unwrappedReceiver.toInt()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 6, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Byte",
            functionName = "toLong",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as ByteValue).value
        
                val result = unwrappedReceiver.toLong()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 7, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Byte",
            functionName = "toDouble",
            returnType = "Double",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as ByteValue).value
        
                val result = unwrappedReceiver.toDouble()
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 8, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Byte",
            functionName = "toChar",
            returnType = "Char",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as ByteValue).value
        
                val result = unwrappedReceiver.toChar()
                result?.let { CharValue(it /* _t = Char; t.name = Char; t = Char */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 9, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "byteArrayOf",
            returnType = "ByteArray",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Byte", modifiers = setOf("vararg")),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val elements_ = (args[0] as KotlinValueHolder<List<RuntimeValue>>).value.map { (it as ByteValue).value }
        
                val result = byteArrayOf(*elements_.toByteArray())
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 14, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "asList",
            returnType = "List<Byte>",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.asList()
                result?.map { ByteValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, interpreter.symbolTable().ByteType /* _t = List<Byte>; t.name = List; t = List<Byte> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 16, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "average",
            returnType = "Double",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.average()
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 17, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray?",
            functionName = "contentEquals",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "ByteArray?"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as? KotlinValueHolder<*>)?.value as ByteArray?
                val other_ = (args[0] as? KotlinValueHolder<*>)?.value as ByteArray?
        
                val result = unwrappedReceiver.contentEquals(other_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 18, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray?",
            functionName = "contentToString",
            returnType = "String",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as? KotlinValueHolder<*>)?.value as ByteArray?
        
                val result = unwrappedReceiver.contentToString()
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 19, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "firstOrNull",
            returnType = "Byte?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Byte) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Byte ->
                    val wa0 = arg0?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.firstOrNull(predicate_)
                result?.let { ByteValue(it /* _t = Byte?; t.name = Byte; t = Byte? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 20, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray?",
            functionName = "contentHashCode",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as? KotlinValueHolder<*>)?.value as ByteArray?
        
                val result = unwrappedReceiver.contentHashCode()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 21, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "copyOf",
            returnType = "ByteArray",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.copyOf()
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 22, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "copyOf",
            returnType = "ByteArray",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "newSize", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val newSize_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.copyOf(newSize_)
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 23, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "copyOfRange",
            returnType = "ByteArray",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "fromIndex", type = "Int"),
                CustomFunctionParameter(name = "toIndex", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val fromIndex_ = (args[0] as IntValue).value
            val toIndex_ = (args[1] as IntValue).value
        
                val result = unwrappedReceiver.copyOfRange(fromIndex_, toIndex_)
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 24, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "count",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.count()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 25, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "drop",
            returnType = "List<Byte>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.drop(n_)
                result?.map { ByteValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, interpreter.symbolTable().ByteType /* _t = List<Byte>; t.name = List; t = List<Byte> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 26, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "dropLast",
            returnType = "List<Byte>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.dropLast(n_)
                result?.map { ByteValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, interpreter.symbolTable().ByteType /* _t = List<Byte>; t.name = List; t = List<Byte> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 27, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "fill",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "Byte"),
                CustomFunctionParameter(name = "fromIndex", type = "Int", defaultValueExpression = "0"),
                CustomFunctionParameter(name = "toIndex", type = "Int", defaultValueExpression = "size"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val element_ = (args[0] as ByteValue).value
            val fromIndex_ = (args[1] as IntValue).value
            val toIndex_ = (args[2] as IntValue).value
        
                val result = unwrappedReceiver.fill(element_, fromIndex_, toIndex_)
                UnitValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 28, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "forEach",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(Byte) -> Unit"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: Byte ->
                    val wa0 = arg0?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    Unit
                } }
        
                val result = unwrappedReceiver.forEach(action_)
                UnitValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 29, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "forEachIndexed",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(Int, Byte) -> Unit"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: Byte ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    Unit
                } }
        
                val result = unwrappedReceiver.forEachIndexed(action_)
                UnitValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 30, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "first",
            returnType = "Byte",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.first()
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 31, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "get",
            returnType = "Byte",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val index_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.get(index_)
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 32, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "iterator",
            returnType = "Iterator<Byte>",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.iterator()
                result.let { it.wrap(symbolTable = interpreter.symbolTable()) }?.let { IteratorValue(it, interpreter.symbolTable().ByteType /* _t = Iterator<Byte>; t.name = Iterator; t = Iterator<Byte> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 33, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "getOrElse",
            returnType = "Byte",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
                CustomFunctionParameter(name = "defaultValue", type = "(Int) -> Byte"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val index_ = (args[0] as IntValue).value
            val defaultValue_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as ByteValue).value
                } }
        
                val result = unwrappedReceiver.getOrElse(index_, defaultValue_)
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 34, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "getOrNull",
            returnType = "Byte?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val index_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.getOrNull(index_)
                result?.let { ByteValue(it /* _t = Byte?; t.name = Byte; t = Byte? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 35, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "indexOf",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "Byte"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val element_ = (args[0] as ByteValue).value
        
                val result = unwrappedReceiver.indexOf(element_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 36, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "indexOfFirst",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Byte) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Byte ->
                    val wa0 = arg0?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.indexOfFirst(predicate_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 37, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "indexOfLast",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Byte) -> Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Byte ->
                    val wa0 = arg0?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.indexOfLast(predicate_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 38, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "joinToString",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "separator", type = "String", defaultValueExpression = "\", \""),
                CustomFunctionParameter(name = "prefix", type = "String", defaultValueExpression = "\"\""),
                CustomFunctionParameter(name = "postfix", type = "String", defaultValueExpression = "\"\""),
                CustomFunctionParameter(name = "limit", type = "Int", defaultValueExpression = "-(1)"),
                CustomFunctionParameter(name = "truncated", type = "String", defaultValueExpression = "\"...\""),
                CustomFunctionParameter(name = "transform", type = "((Byte) -> String)?", defaultValueExpression = "null"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val separator_ = (args[0] as StringValue).value
            val prefix_ = (args[1] as StringValue).value
            val postfix_ = (args[2] as StringValue).value
            val limit_ = (args[3] as IntValue).value
            val truncated_ = (args[4] as StringValue).value
            val transform_ = (args[5] as? LambdaValue)?.let { lambda -> { arg0: Byte ->
                    val wa0 = arg0?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as StringValue).value
                } }
        
                val result = unwrappedReceiver.joinToString(separator_, prefix_, postfix_, limit_, truncated_, transform_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 39, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "last",
            returnType = "Byte",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.last()
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 47, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "map",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(Byte) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: Byte ->
                    val wa0 = arg0?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.map(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 48, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "mapIndexed",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(Int, Byte) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: Byte ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.mapIndexed(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 49, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "max",
            returnType = "Byte",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.max()
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 50, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "min",
            returnType = "Byte",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.min()
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 51, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "none",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.none()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 52, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "onEach",
            returnType = "ByteArray",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(Byte) -> Unit"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: Byte ->
                    val wa0 = arg0?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    Unit
                } }
        
                val result = unwrappedReceiver.onEach(action_)
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 53, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "onEachIndexed",
            returnType = "ByteArray",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(Int, Byte) -> Unit"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: Byte ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    Unit
                } }
        
                val result = unwrappedReceiver.onEachIndexed(action_)
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 54, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "plus",
            returnType = "ByteArray",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "Byte"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val element_ = (args[0] as ByteValue).value
        
                val result = unwrappedReceiver.plus(element_)
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 55, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "plus",
            returnType = "ByteArray",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "ByteArray"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val elements_ = (args[0] as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.plus(elements_)
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 56, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "random",
            returnType = "Byte",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.random()
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 57, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "randomOrNull",
            returnType = "Byte?",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.randomOrNull()
                result?.let { ByteValue(it /* _t = Byte?; t.name = Byte; t = Byte? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 58, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "reverse",
            returnType = "Unit",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.reverse()
                UnitValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 59, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "reversed",
            returnType = "List<Byte>",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.reversed()
                result?.map { ByteValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, interpreter.symbolTable().ByteType /* _t = List<Byte>; t.name = List; t = List<Byte> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 60, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "reversedArray",
            returnType = "ByteArray",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.reversedArray()
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 61, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "set",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
                CustomFunctionParameter(name = "value", type = "Byte"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val index_ = (args[0] as IntValue).value
            val value_ = (args[1] as ByteValue).value
        
                val result = unwrappedReceiver.set(index_, value_)
                UnitValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 62, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "single",
            returnType = "Byte",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.single()
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 63, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "singleOrNull",
            returnType = "Byte?",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.singleOrNull()
                result?.let { ByteValue(it /* _t = Byte?; t.name = Byte; t = Byte? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 64, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "sort",
            returnType = "Unit",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.sort()
                UnitValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 65, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "sortDescending",
            returnType = "Unit",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.sortDescending()
                UnitValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 66, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "sorted",
            returnType = "List<Byte>",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.sorted()
                result?.map { ByteValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, interpreter.symbolTable().ByteType /* _t = List<Byte>; t.name = List; t = List<Byte> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 67, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "sortedArray",
            returnType = "ByteArray",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.sortedArray()
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 68, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "sortedArrayDescending",
            returnType = "ByteArray",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.sortedArrayDescending()
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 69, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "sortedDescending",
            returnType = "List<Byte>",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.sortedDescending()
                result?.map { ByteValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, interpreter.symbolTable().ByteType /* _t = List<Byte>; t.name = List; t = List<Byte> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 70, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "sum",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.sum()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 71, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "take",
            returnType = "List<Byte>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.take(n_)
                result?.map { ByteValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, interpreter.symbolTable().ByteType /* _t = List<Byte>; t.name = List; t = List<Byte> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 72, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "takeLast",
            returnType = "List<Byte>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.takeLast(n_)
                result?.map { ByteValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, interpreter.symbolTable().ByteType /* _t = List<Byte>; t.name = List; t = List<Byte> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 73, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Collection<Byte>",
            functionName = "toByteArray",
            returnType = "ByteArray",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Collection<*>>).value.map { (it as ByteValue).value }
        
                val result = unwrappedReceiver.toByteArray()
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 74, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "toList",
            returnType = "List<Byte>",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.toList()
                result?.map { ByteValue(it, symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, interpreter.symbolTable().ByteType /* _t = List<Byte>; t.name = List; t = List<Byte> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 75, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "toSet",
            returnType = "Set<Byte>",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
        
                val result = unwrappedReceiver.toSet()
                result?.map { ByteValue(it, symbolTable = interpreter.symbolTable()) }?.toSet()?.let { SetValue(it, interpreter.symbolTable().ByteType /* _t = Set<Byte>; t.name = Set; t = Set<Byte> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 76, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "ByteArray",
            functionName = "decodeToString",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "startIndex", type = "Int", defaultValueExpression = "0"),
                CustomFunctionParameter(name = "endIndex", type = "Int", defaultValueExpression = "this.size"),
                CustomFunctionParameter(name = "throwOnInvalidSequence", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ByteArray
                val startIndex_ = (args[0] as IntValue).value
            val endIndex_ = (args[1] as IntValue).value
            val throwOnInvalidSequence_ = (args[2] as BooleanValue).value
        
                val result = unwrappedReceiver.decodeToString(startIndex_, endIndex_, throwOnInvalidSequence_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 79, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "String",
            functionName = "encodeToByteArray",
            returnType = "ByteArray",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "startIndex", type = "Int", defaultValueExpression = "0"),
                CustomFunctionParameter(name = "endIndex", type = "Int", defaultValueExpression = "this.length"),
                CustomFunctionParameter(name = "throwOnInvalidSequence", type = "Boolean", defaultValueExpression = "false"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as StringValue).value
                val startIndex_ = (args[0] as IntValue).value
            val endIndex_ = (args[1] as IntValue).value
            val throwOnInvalidSequence_ = (args[2] as BooleanValue).value
        
                val result = unwrappedReceiver.encodeToByteArray(startIndex_, endIndex_, throwOnInvalidSequence_)
                result?.let { ByteArrayValue(it /* _t = ByteArray; t.name = ByteArray; t = ByteArray */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Byte", lineNum = 85, col = 1),
        ),

    )
}
