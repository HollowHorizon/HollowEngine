
/** Generated code. DO NOT MODIFY! Changes to this file will be overwritten. **/

package com.sunnychung.lib.multiplatform.kotlite.stdlib

import com.sunnychung.lib.multiplatform.kotlite.model.AnyType
import com.sunnychung.lib.multiplatform.kotlite.model.BooleanValue
import com.sunnychung.lib.multiplatform.kotlite.model.ByteValue
import com.sunnychung.lib.multiplatform.kotlite.model.ComparableRuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionParameter
import com.sunnychung.lib.multiplatform.kotlite.model.CharValue
import com.sunnychung.lib.multiplatform.kotlite.model.DataType
import com.sunnychung.lib.multiplatform.kotlite.model.DelegatedValue
import com.sunnychung.lib.multiplatform.kotlite.model.DoubleValue
import com.sunnychung.lib.multiplatform.kotlite.model.ExtensionProperty
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionModifier
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionBodyFormat
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionType
import com.sunnychung.lib.multiplatform.kotlite.model.GlobalProperty
import com.sunnychung.lib.multiplatform.kotlite.model.IntValue
import com.sunnychung.lib.multiplatform.kotlite.model.IterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorClass
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.KotlinValueHolder
import com.sunnychung.lib.multiplatform.kotlite.model.LambdaValue
import com.sunnychung.lib.multiplatform.kotlite.model.LibraryModule
import com.sunnychung.lib.multiplatform.kotlite.model.ListClass
import com.sunnychung.lib.multiplatform.kotlite.model.ListValue
import com.sunnychung.lib.multiplatform.kotlite.model.LongValue
import com.sunnychung.lib.multiplatform.kotlite.model.NothingType
import com.sunnychung.lib.multiplatform.kotlite.model.NullValue
import com.sunnychung.lib.multiplatform.kotlite.model.ObjectType
import com.sunnychung.lib.multiplatform.kotlite.model.PairClass
import com.sunnychung.lib.multiplatform.kotlite.model.PairValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveType
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveTypeName
import com.sunnychung.lib.multiplatform.kotlite.model.ProvidedClassDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.SourcePosition
import com.sunnychung.lib.multiplatform.kotlite.model.StringValue
import com.sunnychung.lib.multiplatform.kotlite.model.FloatValue
import com.sunnychung.lib.multiplatform.kotlite.model.ShortValue
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameter
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameterType
import com.sunnychung.lib.multiplatform.kotlite.model.RuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.UnitType
import com.sunnychung.lib.multiplatform.kotlite.model.UnitValue
import com.sunnychung.lib.multiplatform.kotlite.util.wrapPrimitiveValueAsRuntimeValue





abstract class AbstractCoreLibModule : LibraryModule("Core") {
    override val classes = emptyList<ProvidedClassDefinition>()

    override val properties = listOf<ExtensionProperty>(
    )
    
    override val globalProperties = emptyList<GlobalProperty>()
    
    override val functions = listOf<CustomFunctionDefinition>(
        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "isFinite",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
        
                val result = unwrappedReceiver.isFinite()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 1, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "isInfinite",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
        
                val result = unwrappedReceiver.isInfinite()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 2, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "isNaN",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
        
                val result = unwrappedReceiver.isNaN()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 3, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "toLong",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
        
                val result = unwrappedReceiver.toLong()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 5, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "toDouble",
            returnType = "Double",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
        
                val result = unwrappedReceiver.toDouble()
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 6, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "toInt",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
        
                val result = unwrappedReceiver.toInt()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 7, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "toDouble",
            returnType = "Double",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
        
                val result = unwrappedReceiver.toDouble()
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 8, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "toInt",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
        
                val result = unwrappedReceiver.toInt()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 9, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "toLong",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
        
                val result = unwrappedReceiver.toLong()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 10, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Pair<T, T>",
            functionName = "toList",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.toList()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 12, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "repeat",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "times", type = "Int"),
                CustomFunctionParameter(name = "action", type = "(Int) -> Unit"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.inline),
            inlineFunctionBody = "{\n    var index = 0\n    while (index < times) {\n        action(index)\n        ++index\n    }\n}",
            inlineFunctionBodyFormat = FunctionBodyFormat.Block,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val times_ = (args[0] as IntValue).value
            val action_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    Unit
                } }
        
                val result = repeat(times_, action_)
                UnitValue
            },
            position = SourcePosition(filename = "Core", lineNum = 14, col = 8),
        ),

        CustomFunctionDefinition(
            receiverType = "T",
            functionName = "takeIf",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = receiver as RuntimeValue
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.takeIf(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 21, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "T",
            functionName = "takeUnless",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = receiver as RuntimeValue
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.takeUnless(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 22, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "TODO",
            returnType = "Nothing",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
        
                val result = TODO()
                result?.let { it } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 23, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "check",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val value_ = (args[0] as BooleanValue).value
        
                val result = check(value_)
                UnitValue
            },
            position = SourcePosition(filename = "Core", lineNum = 24, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "check",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "Boolean"),
                CustomFunctionParameter(name = "lazyMessage", type = "() -> Any"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val value_ = (args[0] as BooleanValue).value
            val lazyMessage_ = (args[1] as LambdaValue).let { lambda -> {  
        
        
                    val result = lambda.execute(arrayOf())
                    result as RuntimeValue
                } }
        
                val result = check(value_, lazyMessage_)
                UnitValue
            },
            position = SourcePosition(filename = "Core", lineNum = 25, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "checkNotNull",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "T?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val value_ = (args[0] as RuntimeValue).toNullable()
        
                val result = checkNotNull(value_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 26, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "checkNotNull",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "T?"),
                CustomFunctionParameter(name = "lazyMessage", type = "() -> Any"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val value_ = (args[0] as RuntimeValue).toNullable()
            val lazyMessage_ = (args[1] as LambdaValue).let { lambda -> {  
        
        
                    val result = lambda.execute(arrayOf())
                    result as RuntimeValue
                } }
        
                val result = checkNotNull(value_, lazyMessage_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 27, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "require",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "Boolean"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val value_ = (args[0] as BooleanValue).value
        
                val result = require(value_)
                UnitValue
            },
            position = SourcePosition(filename = "Core", lineNum = 28, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "require",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "Boolean"),
                CustomFunctionParameter(name = "lazyMessage", type = "() -> Any"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val value_ = (args[0] as BooleanValue).value
            val lazyMessage_ = (args[1] as LambdaValue).let { lambda -> {  
        
        
                    val result = lambda.execute(arrayOf())
                    result as RuntimeValue
                } }
        
                val result = require(value_, lazyMessage_)
                UnitValue
            },
            position = SourcePosition(filename = "Core", lineNum = 29, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "requireNotNull",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "T?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val value_ = (args[0] as RuntimeValue).toNullable()
        
                val result = requireNotNull(value_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 30, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "requireNotNull",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "T?"),
                CustomFunctionParameter(name = "lazyMessage", type = "() -> Any"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val value_ = (args[0] as RuntimeValue).toNullable()
            val lazyMessage_ = (args[1] as LambdaValue).let { lambda -> {  
        
        
                    val result = lambda.execute(arrayOf())
                    result as RuntimeValue
                } }
        
                val result = requireNotNull(value_, lazyMessage_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Core", lineNum = 31, col = 11),
        ),

    )
}
