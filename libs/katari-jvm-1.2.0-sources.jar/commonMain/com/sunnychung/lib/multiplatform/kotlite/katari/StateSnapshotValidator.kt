package com.sunnychung.lib.multiplatform.kotlite.katari

class StateSnapshotValidationException(
    val diagnostics: List<StateSnapshotDiagnostic>,
) : IllegalArgumentException(diagnostics.joinToString(separator = "\n") { it.message })

data class StateSnapshotDiagnostic(
    val path: String,
    val message: String,
)

object StateSnapshotValidator {
    fun validate(snapshot: KatariStateSnapshot) {
        val diagnostics = buildList {
            validateValueIds(snapshot)
            validateTasks(snapshot)
        }
        if (diagnostics.isNotEmpty()) {
            throw StateSnapshotValidationException(diagnostics)
        }
    }

    private fun MutableList<StateSnapshotDiagnostic>.validateValueIds(snapshot: KatariStateSnapshot) {
        snapshot.tasks.forEachIndexed { taskIndex, task ->
            task.variableRefs.forEach { (name, ref) ->
                validateValueRef(
                    path = "tasks[$taskIndex].variableRefs[$name]",
                    ref = ref,
                    values = snapshot.values,
                )
            }
            task.resultRef?.let { ref ->
                validateValueRef(
                    path = "tasks[$taskIndex].resultRef",
                    ref = ref,
                    values = snapshot.values,
                )
            }
            task.callFrames.forEachIndexed { frameIndex, frame ->
                frame.variableRefs.forEach { (name, ref) ->
                    validateValueRef(
                        path = "tasks[$taskIndex].callFrames[$frameIndex].variableRefs[$name]",
                        ref = ref,
                        values = snapshot.values,
                    )
                }
            }
            task.xmlBuilders.forEachIndexed { builderIndex, builder ->
                builder.attributes.forEachIndexed { attributeIndex, attribute ->
                    validateValueRef(
                        path = "tasks[$taskIndex].xmlBuilders[$builderIndex].attributes[$attributeIndex].valueRef",
                        ref = attribute.valueRef,
                        values = snapshot.values,
                    )
                }
                builder.children.forEachIndexed { childIndex, ref ->
                    validateValueRef(
                        path = "tasks[$taskIndex].xmlBuilders[$builderIndex].children[$childIndex]",
                        ref = ref,
                        values = snapshot.values,
                    )
                }
            }
        }
        snapshot.values.forEach { (valueId, value) ->
            validateNestedValueRefs(
                path = "values[$valueId]",
                value = value,
                values = snapshot.values,
            )
        }
    }

    private fun MutableList<StateSnapshotDiagnostic>.validateNestedValueRefs(
        path: String,
        value: ValueSnapshot,
        values: Map<Int, ValueSnapshot>,
    ) {
        when (value) {
            is LambdaValueSnapshot -> value.capturedVariableRefs.forEach { (name, ref) ->
                validateValueRef(
                    path = "$path.capturedVariableRefs[$name]",
                    ref = ref,
                    values = values,
                )
            }
            is KatariTaskValueSnapshot -> value.capturedVariableRefs.forEach { (name, ref) ->
                validateValueRef(
                    path = "$path.capturedVariableRefs[$name]",
                    ref = ref,
                    values = values,
                )
            }
            is XmlValueSnapshot -> {
                value.attributes.forEachIndexed { index, attribute ->
                    validateValueRef(
                        path = "$path.attributes[$index].valueRef",
                        ref = attribute.valueRef,
                        values = values,
                    )
                }
                value.children.forEachIndexed { index, ref ->
                    validateValueRef(
                        path = "$path.children[$index]",
                        ref = ref,
                        values = values,
                    )
                }
            }
            is StructValueSnapshot -> value.fields.forEach { (name, ref) ->
                validateValueRef(
                    path = "$path.fields[$name]",
                    ref = ref,
                    values = values,
                )
            }
            is StructArrayValueSnapshot -> value.elements.forEachIndexed { index, ref ->
                validateValueRef(
                    path = "$path.elements[$index]",
                    ref = ref,
                    values = values,
                )
            }
            else -> Unit
        }
    }

    private fun MutableList<StateSnapshotDiagnostic>.validateValueRef(
        path: String,
        ref: ValueReferenceSnapshot,
        values: Map<Int, ValueSnapshot>,
    ) {
        if (ref.valueId !in values) {
            add(
                StateSnapshotDiagnostic(
                    path = path,
                    message = "$path references missing snapshot value `${ref.valueId}`",
                )
            )
        }
    }

    private fun MutableList<StateSnapshotDiagnostic>.validateTasks(snapshot: KatariStateSnapshot) {
        val taskIds = mutableSetOf<String>()
        snapshot.tasks.forEachIndexed { taskIndex, task ->
            val taskPath = "tasks[$taskIndex]"
            if (!taskIds.add(task.id)) {
                add(
                    StateSnapshotDiagnostic(
                        path = "$taskPath.id",
                        message = "$taskPath.id duplicates task id `${task.id}`",
                    )
                )
            }
            if (task.parentTaskId == task.id) {
                add(
                    StateSnapshotDiagnostic(
                        path = "$taskPath.parentTaskId",
                        message = "$taskPath.parentTaskId cannot reference the task itself",
                    )
                )
            }
            validateCallFrames(taskPath, task)
        }
    }

    private fun MutableList<StateSnapshotDiagnostic>.validateCallFrames(
        taskPath: String,
        task: TaskSnapshot,
    ) {
        val frameIds = mutableSetOf<Int>()
        task.callFrames.forEachIndexed { frameIndex, frame ->
            val framePath = "$taskPath.callFrames[$frameIndex]"
            if (!frameIds.add(frame.id)) {
                add(
                    StateSnapshotDiagnostic(
                        path = "$framePath.id",
                        message = "$framePath.id duplicates call frame id `${frame.id}` in task `${task.id}`",
                    )
                )
            }
        }
        task.callFrames.forEachIndexed { frameIndex, frame ->
            val framePath = "$taskPath.callFrames[$frameIndex]"
            val parentId = frame.lexicalParentFrameId
            if (parentId != null && parentId !in frameIds) {
                add(
                    StateSnapshotDiagnostic(
                        path = "$framePath.lexicalParentFrameId",
                        message = "$framePath.lexicalParentFrameId references missing call frame `$parentId`",
                    )
                )
            }
        }
        val maxFrameId = frameIds.maxOrNull() ?: ROOT_CALL_FRAME_ID
        if (task.nextCallFrameId <= maxFrameId) {
            add(
                StateSnapshotDiagnostic(
                    path = "$taskPath.nextCallFrameId",
                    message = "$taskPath.nextCallFrameId must be greater than existing frame id `$maxFrameId`",
                )
            )
        }
    }
}
