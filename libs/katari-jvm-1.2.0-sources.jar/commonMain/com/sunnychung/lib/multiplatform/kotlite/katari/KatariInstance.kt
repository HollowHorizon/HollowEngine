package com.sunnychung.lib.multiplatform.kotlite.katari

import com.sunnychung.lib.multiplatform.kotlite.model.BooleanValue
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionParameter
import com.sunnychung.lib.multiplatform.kotlite.model.DataType
import com.sunnychung.lib.multiplatform.kotlite.model.DefaultArgumentMarker
import com.sunnychung.lib.multiplatform.kotlite.model.DoubleValue
import com.sunnychung.lib.multiplatform.kotlite.model.EnumEntriesIteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.ExecutionEnvironment
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionResponse
import com.sunnychung.lib.multiplatform.kotlite.model.IntValue
import com.sunnychung.lib.multiplatform.kotlite.model.KatariTaskValue
import com.sunnychung.lib.multiplatform.kotlite.model.KotlinValueHolder
import com.sunnychung.lib.multiplatform.kotlite.model.NarrativeCallContext
import com.sunnychung.lib.multiplatform.kotlite.model.NarrativeCallDispatchContext
import com.sunnychung.lib.multiplatform.kotlite.model.NarrativeCallResult
import com.sunnychung.lib.multiplatform.kotlite.model.NarrativeCallable
import com.sunnychung.lib.multiplatform.kotlite.model.NarrativeEnumEntriesValue
import com.sunnychung.lib.multiplatform.kotlite.model.NarrativeEnumValue
import com.sunnychung.lib.multiplatform.kotlite.model.NarrativeHostValue
import com.sunnychung.lib.multiplatform.kotlite.model.NarrativeLambdaValue
import com.sunnychung.lib.multiplatform.kotlite.model.NullValue
import com.sunnychung.lib.multiplatform.kotlite.model.RuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.RuntimeValueAccessor
import com.sunnychung.lib.multiplatform.kotlite.model.SourcePosition
import com.sunnychung.lib.multiplatform.kotlite.model.StringValue
import com.sunnychung.lib.multiplatform.kotlite.model.StructArrayValue
import com.sunnychung.lib.multiplatform.kotlite.model.StructValue
import com.sunnychung.lib.multiplatform.kotlite.model.SymbolTable
import com.sunnychung.lib.multiplatform.kotlite.model.UnitValue
import com.sunnychung.lib.multiplatform.kotlite.model.XmlAttributeValue
import com.sunnychung.lib.multiplatform.kotlite.model.XML_TEXT_NODE_NAME
import com.sunnychung.lib.multiplatform.kotlite.model.XML_TEXT_VALUE_ATTRIBUTE
import com.sunnychung.lib.multiplatform.kotlite.model.XmlValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class KatariInstance(
    private val program: KatariProgram,
    initialState: KatariState = KatariState(
        programVersion = program.version,
        tasks = listOf(TaskState(id = program.entryTaskId)),
    ),
    private val executionEnvironment: ExecutionEnvironment = ExecutionEnvironment(),
    private val snapshotCodec: StateSnapshotCodec = StateSnapshotCodec(executionEnvironment = executionEnvironment),
    coroutineScope: CoroutineScope? = null,
) {
    companion object {
        private const val SLOT_VARIABLE_PREFIX = "__narrative_slot_"
    }

    private val ownsScope = coroutineScope == null
    private val scope = coroutineScope ?: CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutex = Mutex()
    private val completion = CompletableDeferred<Unit>()
    private val inFlightTasks = mutableSetOf<String>()
    private var currentState: KatariState = initialState
    private var taskIdCounter = nextTaskIdCounter(initialState)
    private var executionJob: Job? = null
    private var cancelled = false

    fun start() {
        if (cancelled || completion.isCompleted) return
        scope.launch {
            val pending = mutex.withLock {
                val requests = collectUndispatchedSuspensionsLocked()
                if (executionJob?.isActive != true) {
                    executionJob = launchExecutionLocked()
                }
                requests
            }
            pending.forEach { dispatchSuspendedCall(it) }
        }
    }

    fun cancel() {
        cancelled = true
        executionJob?.cancel()
        if (ownsScope) {
            scope.cancel()
        }
        if (!completion.isCompleted) {
            completion.complete(Unit)
        }
    }

    suspend fun join() {
        completion.await()
    }

    suspend fun serializeState(): KatariStateSnapshot {
        return mutex.withLock {
            val compacted = currentState.copy(tasks = currentState.tasks.map { compactTaskForSnapshot(it) })
            snapshotCodec.serialize(compacted)
        }
    }

    suspend fun currentState(): KatariState {
        return mutex.withLock { currentState }
    }

    private fun launchExecutionLocked(): Job {
        return scope.launch {
            try {
                runExecutionLoop()
            } finally {
                mutex.withLock {
                    if (executionJob === this@launch) {
                        executionJob = null
                    }
                }
            }
        }
    }

    private suspend fun runExecutionLoop() {
        while (!cancelled) {
            var nextEffectToDispatch: FunctionDispatchRequest? = null
            var pendingSuspensions: List<FunctionDispatchRequest> = emptyList()
            var shouldReturn = false
            mutex.withLock {
                wakeWaitingTasksLocked()
                val taskIndex = currentState.tasks.indexOfFirst { it.status == TaskStatus.Ready }
                if (taskIndex < 0) {
                    pendingSuspensions = collectUndispatchedSuspensionsLocked()
                    if (currentState.tasks.all { isTaskFinal(it.status) } && !completion.isCompleted) {
                        completion.complete(Unit)
                    }
                    shouldReturn = true
                    return@withLock
                }

                val task = normalizeTask(currentState.tasks[taskIndex])
                if (task.instructionPointer >= program.instructions.size) {
                    currentState = currentState.completeTask(taskIndex, null)
                } else {
                    val instruction = program.instructions[task.instructionPointer]
                    try {
                        when (instruction) {
                            is CallFunctionInstruction -> nextEffectToDispatch = executeFunctionCallLocked(taskIndex, task, instruction)
                            is SetVariableInstruction -> {
                                val referencedSlots = collectReferencedSlots(instruction.expression)
                                currentState = currentState.updateTask(
                                    index = taskIndex,
                                    task = cleanupSlots(
                                        task = applySetVariableInstruction(task, instruction),
                                        slotsToRemove = referencedSlots,
                                    ),
                                )
                            }
                            is SetResultInstruction -> {
                                val referencedSlots = collectReferencedSlots(instruction.expression)
                                currentState = currentState.updateTask(
                                    index = taskIndex,
                                    task = cleanupSlots(
                                        task = applyExpressionResultTarget(
                                            task = task,
                                            resultTarget = instruction.target,
                                            expression = instruction.expression,
                                            nextInstructionPointer = task.instructionPointer + 1,
                                        ),
                                        slotsToRemove = referencedSlots,
                                    ),
                                )
                            }
                            is ConditionalJumpInstruction -> {
                                val referencedSlots = collectReferencedSlots(instruction.condition)
                                val isTrue = evaluateExpression(currentState, task, instruction.condition).asBoolean()
                                currentState = currentState.updateTask(
                                    index = taskIndex,
                                    task = cleanupSlots(
                                        task = task.copy(
                                            instructionPointer = if (isTrue) task.instructionPointer + 1 else instruction.falseTarget,
                                        ),
                                        slotsToRemove = referencedSlots,
                                    ),
                                )
                            }
                            is JumpInstruction -> {
                                currentState = currentState.updateTask(
                                    index = taskIndex,
                                    task = task.copy(instructionPointer = instruction.target),
                                )
                            }
                            is EndInstruction -> {
                                currentState = currentState.completeTask(taskIndex, null)
                            }
                            is CreateAsyncTaskInstruction -> {
                                currentState = currentState.updateTask(
                                    index = taskIndex,
                                    task = applyCreateAsyncTaskInstruction(task, instruction),
                                )
                            }
                            is TaskControlInstruction -> {
                                currentState = applyTaskControlInstruction(taskIndex, task, instruction)
                            }
                            is StartRaceInstruction -> {
                                currentState = applyStartRaceInstruction(taskIndex, task, instruction)
                            }
                            is CompleteTaskInstruction -> {
                                val result = instruction.resultExpression?.let { evaluateExpression(currentState, task, it) }
                                currentState = currentState.completeTask(taskIndex, result)
                            }
                            is EnterCallFrameInstruction -> {
                                val updated = applyEnterCallFrameInstruction(task, instruction)
                                currentState = currentState.updateTask(index = taskIndex, task = syncTopLocals(updated))
                            }
                            is ExitCallFrameInstruction -> {
                                val returnValue = instruction.returnExpression?.let { evaluateExpression(currentState, task, it) }
                                    ?: NullValue
                                currentState = currentState.updateTask(
                                    index = taskIndex,
                                    task = applyExitCallFrameInstruction(task, instruction, returnValue),
                                )
                            }
                is RemoveVariablesInstruction -> {
                    val frame = currentCallFrame(task)
                    val names = instruction.names.toSet()
                    val updatedFrame = frame.copy(localVariables = frame.localVariables - names)
                    val nextTask = syncTopLocals(
                                    task.copy(
                                        instructionPointer = task.instructionPointer + 1,
                                        callFrames = task.callFrames.replaceLast(updatedFrame),
                                        slots = task.slots.filterValues { slotValue ->
                                            slotValue !is SlotValue.VariableReference ||
                                                slotValue.frameId != frame.id || slotValue.name !in names
                                        },
                                    )
                   )
                   currentState = currentState.updateTask(index = taskIndex, task = nextTask)
               }
                is BeginXmlNodeInstruction -> {
                    currentState = currentState.updateTask(
                        index = taskIndex,
                        task = beginXmlNode(task, instruction),
                    )
                }
                is AppendXmlChildrenInstruction -> {
                    val referencedSlots = collectReferencedSlots(instruction.expression)
                    currentState = currentState.updateTask(
                        index = taskIndex,
                        task = cleanupSlots(
                            task = appendXmlChildren(task, instruction),
                            slotsToRemove = referencedSlots,
                        ),
                    )
                }
                is EndXmlNodeInstruction -> {
                    currentState = currentState.updateTask(
                        index = taskIndex,
                        task = endXmlNode(task, instruction),
                    )
                }
           }
                    } catch (e: Throwable) {
                        if (e is CancellationException) {
                            throw e
                        }
                        val message = buildRuntimeErrorMessage(instruction.position, e)
                        currentState = currentState.updateTask(
                            index = taskIndex,
                            task = task.copy(status = TaskStatus.Failed(message = message)),
                        )
                    }
                }
            }

            pendingSuspensions.forEach { dispatchSuspendedCall(it) }
            if (shouldReturn) {
                return
            }
            nextEffectToDispatch?.let { request ->
                dispatchSuspendedCall(request)
            }
        }
    }

    private suspend fun executeFunctionCallLocked(
        taskIndex: Int,
        task: TaskState,
        instruction: CallFunctionInstruction,
    ): FunctionDispatchRequest? {
        val resolved = resolveNarrativeCall(instruction.functionId, instruction, task)
        val referencedSlots = collectReferencedSlots(instruction.arguments)
        val definition = resolved.callable
        val arguments = resolved.arguments
        return when (val result = definition.startCall(
            arguments,
            KatariCallContextImpl(snapshotCodec.symbolTable(), currentState, task, resolved.typeArguments),
        )) {
            is NarrativeCallResult.Returned -> {
                currentState = currentState.updateTask(
                    index = taskIndex,
                    task = cleanupSlots(
                        task = applyResultTarget(
                            task = task,
                            resultTarget = instruction.resultTarget,
                            value = result.value,
                            nextInstructionPointer = task.instructionPointer + 1,
                        ),
                        slotsToRemove = referencedSlots,
                    ),
                )
                null
            }
            NarrativeCallResult.Suspended -> {
                val suspendedStatus = TaskStatus.SuspendedCall(
                    resultTarget = instruction.resultTarget,
                    nextInstructionPointer = task.instructionPointer + 1,
                )
                currentState = currentState.updateTask(
                    index = taskIndex,
                    task = task.copy(status = suspendedStatus),
                )
                FunctionDispatchRequest(task.id)
            }
        }
    }

    private fun resolveNarrativeCall(
        functionId: String,
        instruction: CallFunctionInstruction,
        task: TaskState,
    ): ResolvedCall {
        val argumentNames = instruction.argumentNames.takeIf { it.isNotEmpty() }
            ?: List(instruction.arguments.size) { null }
        require(argumentNames.size == instruction.arguments.size) {
            "Call `$functionId` has ${instruction.arguments.size} arguments but ${argumentNames.size} argument names"
        }
        val args = instruction.arguments.map { evaluateExpression(currentState, task, it) }
        val (callable, normalizedArgs) = executionEnvironment.resolveNarrativeCallable(functionId, args, argumentNames)
        val typeArguments = callable.typeParameters
            .zip(instruction.typeArguments)
            .associate { (parameter, type) -> parameter.name to snapshotCodec.symbolTable().assertToDataType(type) }
        return ResolvedCall(callable = callable, arguments = normalizedArgs, typeArguments = typeArguments)
    }

    private suspend fun dispatchSuspendedCall(request: FunctionDispatchRequest) {
        val dispatchData = mutex.withLock {
            if (request.taskId in inFlightTasks) return
            val task = currentState.tasks.firstOrNull { currentTask ->
                currentTask.id == request.taskId && currentTask.status is TaskStatus.SuspendedCall
            }?.let { normalizeTask(it) } ?: return
            inFlightTasks += request.taskId
            val instruction = resolveSuspendedCallInstruction(task)
            val resolved = resolveNarrativeCall(instruction.functionId, instruction, task)
            DispatchData(
                taskId = task.id,
                arguments = resolved.arguments,
                definition = resolved.callable,
                context = KatariCallContextImpl(snapshotCodec.symbolTable(), currentState, task, resolved.typeArguments),
            )
        }

        try {
            dispatchData.definition.dispatch(
                arguments = dispatchData.arguments,
                context = dispatchData.context,
                resume = { response ->
                    val activeJob = executionJob
                    scope.launch {
                        activeJob?.join()
                        handleResume(dispatchData.taskId, response)
                    }
                },
            )
        } catch (e: Throwable) {
            if (e is CancellationException) {
                throw e
            }
            markTaskAsFailed(
                taskId = dispatchData.taskId,
                message = buildRuntimeErrorMessage(null, e),
            )
        }
    }

    private suspend fun handleResume(
        taskId: String,
        response: FunctionResponse?,
    ) {
        val pending: List<FunctionDispatchRequest>
        mutex.withLock {
            inFlightTasks -= taskId
            val taskIndex = currentState.tasks.indexOfFirst {
                it.id == taskId && (
                    it.status is TaskStatus.SuspendedCall ||
                        (it.status as? TaskStatus.Paused)?.innerStatus is TaskStatus.SuspendedCall
                    )
            }
            if (taskIndex < 0 || cancelled) return

            val task = normalizeTask(currentState.tasks[taskIndex])
            val pausedStatus = task.status as? TaskStatus.Paused
            val status = (pausedStatus?.innerStatus ?: task.status) as TaskStatus.SuspendedCall
            val instruction = resolveSuspendedCallInstruction(task)
            val resolved = resolveNarrativeCall(instruction.functionId, instruction, task)
            val referencedSlots = collectReferencedSlots(instruction.arguments)
            val definition = resolved.callable
            val arguments = resolved.arguments
            try {
                when (val result = definition.resumeCall(
                    arguments = arguments,
                    response = response,
                    context = KatariCallContextImpl(snapshotCodec.symbolTable(), currentState, task, resolved.typeArguments),
                )) {
                    is NarrativeCallResult.Returned -> {
                        val resumedTask = cleanupSlots(
                            task = applyResultTarget(
                                task = task.copy(status = TaskStatus.Ready),
                                resultTarget = status.resultTarget,
                                value = result.value,
                                nextInstructionPointer = status.nextInstructionPointer,
                            ),
                            slotsToRemove = referencedSlots,
                        )
                        currentState = currentState.updateTask(
                            index = taskIndex,
                            task = if (pausedStatus == null) resumedTask else resumedTask.copy(status = TaskStatus.Paused(TaskStatus.Ready)),
                        )
                    }
                    NarrativeCallResult.Suspended -> {
                        currentState = currentState.updateTask(
                            index = taskIndex,
                            task = task,
                        )
                    }
                }
            } catch (e: Throwable) {
                if (e is CancellationException) {
                    throw e
                }
                currentState = currentState.updateTask(
                    index = taskIndex,
                    task = task.copy(status = TaskStatus.Failed(message = buildRuntimeErrorMessage(null, e))),
                )
            }

            pending = collectUndispatchedSuspensionsLocked()
            if (currentState.tasks.all { isTaskFinal(it.status) } && !completion.isCompleted) {
                completion.complete(Unit)
            } else if (executionJob?.isActive != true && !completion.isCompleted) {
                executionJob = launchExecutionLocked()
            }
            Unit
        }
        pending.forEach { request ->
            scope.launch { dispatchSuspendedCall(request) }
        }
    }

    private fun collectUndispatchedSuspensionsLocked(): List<FunctionDispatchRequest> {
        return currentState.tasks.mapNotNull { task ->
            if (task.status !is TaskStatus.SuspendedCall || task.id in inFlightTasks) {
                null
            } else {
                FunctionDispatchRequest(task.id)
            }
        }
    }

    private fun applySetVariableInstruction(
        task: TaskState,
        instruction: SetVariableInstruction,
    ): TaskState {
        val value = evaluateExpression(currentState, task, instruction.expression)
        val frame = currentCallFrame(task)
        if (!instruction.declaresLocal) {
            findComputedGlobalAccessor(instruction.name)?.let { accessor ->
                accessor.assign(value = value)
                return task.copy(
                    instructionPointer = task.instructionPointer + 1,
                    slots = if (instruction.expression is SlotExpression) task.slots - instruction.expression.slot else task.slots,
                )
            }
        }
        val updated = frame.copy(localVariables = frame.localVariables + (instruction.name to value))
        return syncTopLocals(
            task.copy(
                instructionPointer = task.instructionPointer + 1,
                callFrames = task.callFrames.replaceLast(updated),
                slots = if (instruction.expression is SlotExpression) task.slots - instruction.expression.slot else task.slots,
            )
        )
    }

    private fun applyCreateAsyncTaskInstruction(
        task: TaskState,
        instruction: CreateAsyncTaskInstruction,
    ): TaskState {
        val taskValue = KatariTaskValue(
            taskId = allocateTaskId(),
            entryPointer = instruction.entryPointer,
            rootFrameId = instruction.rootFrameId,
            capturedVariables = visibleLocalVariables(task),
            started = false,
            symbolTable = snapshotCodec.symbolTable(),
        )
        return applyResultTarget(
            task = task,
            resultTarget = instruction.resultTarget,
            value = taskValue,
            nextInstructionPointer = task.instructionPointer + 1,
        )
    }

    private fun applyTaskControlInstruction(
        taskIndex: Int,
        task: TaskState,
        instruction: TaskControlInstruction,
    ): KatariState {
        val taskValue = evaluateExpression(currentState, task, instruction.task) as? KatariTaskValue
            ?: throw IllegalArgumentException("Katari task operation `${instruction.operation}` expects KatariTask receiver")
        return when (instruction.operation) {
            TaskControlOperation.Start -> {
                startAsyncTask(taskValue, parentTaskId = task.id)
                currentState.updateTask(
                    index = taskIndex,
                    task = applyResultTarget(task, instruction.resultTarget, NullValue, task.instructionPointer + 1),
                )
            }
            TaskControlOperation.Stop -> {
                stopTask(taskValue.taskId)
                currentState.updateTask(
                    index = taskIndex,
                    task = applyResultTarget(task, instruction.resultTarget, NullValue, task.instructionPointer + 1),
                )
            }
            TaskControlOperation.Pause -> {
                pauseTask(taskValue.taskId)
                currentState.updateTask(
                    index = taskIndex,
                    task = applyResultTarget(task, instruction.resultTarget, NullValue, task.instructionPointer + 1),
                )
            }
            TaskControlOperation.Resume -> {
                resumeTask(taskValue.taskId)
                currentState.updateTask(
                    index = taskIndex,
                    task = applyResultTarget(task, instruction.resultTarget, NullValue, task.instructionPointer + 1),
                )
            }
            TaskControlOperation.Join -> {
                val joined = currentState.tasks.firstOrNull { it.id == taskValue.taskId }
                if (joined != null && isTaskFinal(joined.status)) {
                    val value = joined.result ?: NullValue
                    currentState.updateTask(
                        index = taskIndex,
                        task = applyResultTarget(task, instruction.resultTarget, value, task.instructionPointer + 1),
                    )
                } else {
                    currentState.updateTask(
                        index = taskIndex,
                        task = task.copy(
                            status = TaskStatus.WaitingTaskJoin(
                                taskId = taskValue.taskId,
                                resultTarget = instruction.resultTarget,
                                nextInstructionPointer = task.instructionPointer + 1,
                            )
                        ),
                    )
                }
            }
        }
    }

    private fun applyStartRaceInstruction(
        taskIndex: Int,
        task: TaskState,
        instruction: StartRaceInstruction,
    ): KatariState {
        val branchTasks = instruction.entries.mapIndexed { index, entry ->
            val capturedVariables = visibleLocalVariables(task)
            val rootFrame = CallFrameState(
                id = entry.rootFrameId,
                functionId = ROOT_CALL_FRAME_FUNCTION_ID,
                lexicalParentFrameId = null,
                localVariables = capturedVariables,
            )
            TaskState(
                id = "${instruction.raceId}_$index",
                instructionPointer = entry.entryPointer,
                localVariables = capturedVariables,
                callFrames = listOf(rootFrame),
                nextCallFrameId = maxOf(entry.rootFrameId + 1, ROOT_CALL_FRAME_ID + 1),
                status = TaskStatus.Ready,
                raceGroupId = instruction.raceId,
                parentTaskId = task.id,
            )
        }
        return currentState.copy(
            tasks = currentState.tasks.mapIndexed { index, currentTask ->
                if (index == taskIndex) {
                    syncTopLocals(
                        task.copy(
                            status = TaskStatus.WaitingRace(
                                raceId = instruction.raceId,
                                resultTarget = instruction.resultTarget,
                                nextInstructionPointer = task.instructionPointer + 1,
                            )
                        )
                    )
                } else {
                    currentTask
                }
            } + branchTasks
        )
    }

    private fun startAsyncTask(
        taskValue: KatariTaskValue,
        parentTaskId: String?,
    ) {
        if (currentState.tasks.any { it.id == taskValue.taskId }) {
            taskValue.started = true
            return
        }
        val capturedVariables = taskValue.capturedVariables.toMap()
        val rootFrame = CallFrameState(
            id = taskValue.rootFrameId,
            functionId = ROOT_CALL_FRAME_FUNCTION_ID,
            lexicalParentFrameId = null,
            localVariables = capturedVariables,
        )
        currentState = currentState.copy(
            tasks = currentState.tasks + TaskState(
                id = taskValue.taskId,
                instructionPointer = taskValue.entryPointer,
                localVariables = capturedVariables,
                callFrames = listOf(rootFrame),
                nextCallFrameId = maxOf(taskValue.rootFrameId + 1, ROOT_CALL_FRAME_ID + 1),
                status = TaskStatus.Ready,
                parentTaskId = parentTaskId,
            )
        )
        taskValue.started = true
    }

    private fun stopTask(taskId: String) {
        currentState.tasks
            .filter { it.parentTaskId == taskId && !isTaskFinal(it.status) }
            .map { it.id }
            .forEach { stopTask(it) }
        val index = currentState.tasks.indexOfFirst { it.id == taskId }
        if (index < 0) return
        inFlightTasks -= taskId
        currentState = currentState.updateTask(
            index = index,
            task = currentState.tasks[index].copy(status = TaskStatus.Stopped),
        )
    }

    private fun pauseTask(taskId: String) {
        val index = currentState.tasks.indexOfFirst { it.id == taskId }
        if (index < 0) return
        val target = currentState.tasks[index]
        if (target.status is TaskStatus.Paused || isTaskFinal(target.status)) return
        currentState = currentState.updateTask(
            index = index,
            task = target.copy(status = TaskStatus.Paused(target.status)),
        )
    }

    private fun resumeTask(taskId: String) {
        val index = currentState.tasks.indexOfFirst { it.id == taskId }
        if (index < 0) return
        val paused = currentState.tasks[index].status as? TaskStatus.Paused ?: return
        currentState = currentState.updateTask(
            index = index,
            task = currentState.tasks[index].copy(status = paused.innerStatus),
        )
    }

    private fun allocateTaskId(): String {
        while ("__katari_task_$taskIdCounter" in collectKnownTaskIds(currentState)) {
            ++taskIdCounter
        }
        return "__katari_task_${taskIdCounter++}"
    }

    private fun applyResultTarget(
        task: TaskState,
        resultTarget: ResultTarget?,
        value: RuntimeValue,
        nextInstructionPointer: Int,
    ): TaskState {
        return when (resultTarget) {
            null -> task.copy(instructionPointer = nextInstructionPointer)
            is ResultTarget.Variable -> {
                if (!resultTarget.declaresLocal) {
                    findComputedGlobalAccessor(resultTarget.name)?.let { accessor ->
                        accessor.assign(value = value)
                        return task.copy(instructionPointer = nextInstructionPointer)
                    }
                }
                val frame = currentCallFrame(task)
                val updated = frame.copy(localVariables = frame.localVariables + (resultTarget.name to value))
                syncTopLocals(task.copy(instructionPointer = nextInstructionPointer, callFrames = task.callFrames.replaceLast(updated)))
            }
            is ResultTarget.Slot -> {
                val frame = currentCallFrame(task)
                val slotVariableName = slotVariableName(resultTarget.slot)
                val updated = frame.copy(localVariables = frame.localVariables + (slotVariableName to value))
                syncTopLocals(
                    task.copy(
                        instructionPointer = nextInstructionPointer,
                        callFrames = task.callFrames.replaceLast(updated),
                        slots = task.slots + (
                            resultTarget.slot to SlotValue.VariableReference(name = slotVariableName, frameId = frame.id)
                        ),
                    )
                )
            }
        }
    }

    private fun applyExpressionResultTarget(
        task: TaskState,
        resultTarget: ResultTarget,
        expression: KatariExpression,
        nextInstructionPointer: Int,
    ): TaskState {
        return when (resultTarget) {
            is ResultTarget.Variable -> applyResultTarget(
                task = task,
                resultTarget = resultTarget,
                value = evaluateExpression(currentState, task, expression),
                nextInstructionPointer = nextInstructionPointer,
            )
            is ResultTarget.Slot -> {
                val reference = evaluateSlotReference(currentState, task, expression)
                if (reference != null) {
                    task.copy(
                        instructionPointer = nextInstructionPointer,
                        slots = task.slots + (resultTarget.slot to reference),
                    )
                } else {
                    val frame = currentCallFrame(task)
                    val slotVariableName = slotVariableName(resultTarget.slot)
                    val value = evaluateExpression(currentState, task, expression)
                    val updated = frame.copy(localVariables = frame.localVariables + (slotVariableName to value))
                    syncTopLocals(
                        task.copy(
                            instructionPointer = nextInstructionPointer,
                            callFrames = task.callFrames.replaceLast(updated),
                            slots = task.slots + (
                                resultTarget.slot to SlotValue.VariableReference(name = slotVariableName, frameId = frame.id)
                            ),
                        )
                    )
                }
            }
        }
    }

    private fun beginXmlNode(task: TaskState, instruction: BeginXmlNodeInstruction): TaskState {
        val attributes = instruction.attributes.map { attribute ->
            XmlAttributeValue(
                name = attribute.name,
                value = evaluateExpression(currentState, task, attribute.value),
            )
        }
        return task.copy(
            instructionPointer = task.instructionPointer + 1,
            xmlBuilders = task.xmlBuilders + XmlBuilderState(
                name = instruction.name,
                attributes = attributes,
            ),
        )
    }

    private fun appendXmlChildren(task: TaskState, instruction: AppendXmlChildrenInstruction): TaskState {
        require(task.xmlBuilders.isNotEmpty()) {
            "XML child expression requires an outer XML literal"
        }
        val children = evaluateExpression(currentState, task, instruction.expression).asXmlChildren()
        if (children.isEmpty()) {
            return task.copy(instructionPointer = task.instructionPointer + 1)
        }
        val builders = task.xmlBuilders.toMutableList()
        builders[builders.lastIndex] = builders.last().copy(children = builders.last().children + children)
        return task.copy(instructionPointer = task.instructionPointer + 1, xmlBuilders = builders)
    }

    private fun endXmlNode(task: TaskState, instruction: EndXmlNodeInstruction): TaskState {
        val builder = task.xmlBuilders.lastOrNull()
            ?: throw IllegalStateException("Cannot close XML literal because no XML builder is active")
        val node = XmlValue(
            name = builder.name,
            attributes = builder.attributes,
            children = builder.children,
            symbolTable = snapshotCodec.symbolTable(),
        )
        val remainingBuilders = task.xmlBuilders.dropLast(1)
        if (instruction.resultTarget == null) {
            require(remainingBuilders.isNotEmpty()) {
                "XML literal statement requires an outer XML literal"
            }
            val builders = remainingBuilders.toMutableList()
            builders[builders.lastIndex] = builders.last().copy(children = builders.last().children + node)
            return task.copy(
                instructionPointer = task.instructionPointer + 1,
                xmlBuilders = builders,
            )
        }
        return applyResultTarget(
            task = task.copy(xmlBuilders = remainingBuilders),
            resultTarget = instruction.resultTarget,
            value = node,
            nextInstructionPointer = task.instructionPointer + 1,
        )
    }

    private fun evaluateSlotReference(
        state: KatariState,
        task: TaskState,
        expression: KatariExpression,
    ): SlotValue.VariableReference? {
        return when (expression) {
            is VariableExpression -> resolveVariableReference(state, task, expression.name)
            is SlotExpression -> task.slots[expression.slot] as? SlotValue.VariableReference
                ?: throw IllegalArgumentException("Slot `${expression.slot}` is not defined")
            else -> null
        }
    }

    private fun resolveSuspendedCallInstruction(task: TaskState): CallFunctionInstruction {
        return program.instructions.getOrNull(task.instructionPointer) as? CallFunctionInstruction
            ?: throw IllegalStateException("Task `${task.id}` is suspended at instruction ${task.instructionPointer}, but no function call exists there")
    }

    private fun wakeWaitingTasksLocked() {
        currentState.tasks.forEachIndexed { index, task ->
            when (val status = task.status) {
                is TaskStatus.WaitingTaskJoin -> {
                    val joined = currentState.tasks.firstOrNull { it.id == status.taskId } ?: return@forEachIndexed
                    if (!isTaskFinal(joined.status)) return@forEachIndexed
                    val nextTask = if (joined.status is TaskStatus.Failed) {
                        task.copy(status = TaskStatus.Failed(joined.status.message))
                    } else {
                        applyResultTarget(
                            task = task.copy(status = TaskStatus.Ready),
                            resultTarget = status.resultTarget,
                            value = joined.result ?: NullValue,
                            nextInstructionPointer = status.nextInstructionPointer,
                        )
                    }
                    currentState = currentState.updateTask(index, nextTask)
                }
                is TaskStatus.WaitingRace -> {
                    val winner = currentState.tasks.firstOrNull {
                        it.raceGroupId == status.raceId && it.status == TaskStatus.Completed
                    } ?: return@forEachIndexed
                    val nextTask = applyResultTarget(
                        task = task.copy(status = TaskStatus.Ready),
                        resultTarget = status.resultTarget,
                        value = winner.result ?: NullValue,
                        nextInstructionPointer = status.nextInstructionPointer,
                    )
                    currentState.tasks
                        .filter { it.raceGroupId == status.raceId && !isTaskFinal(it.status) }
                        .forEach { stopTask(it.id) }
                    currentState = currentState.updateTask(index, nextTask)
                }
                else -> Unit
            }
        }
    }

    private fun evaluateExpression(
        state: KatariState,
        task: TaskState,
        expression: KatariExpression,
    ): RuntimeValue {
        try {
            return when (expression) {
                is LiteralExpression -> expression.value
                is VariableExpression -> resolveVariableValue(state, task, expression.name)
                is SlotExpression -> resolveSlotValue(state, task, expression.slot)
                is LambdaLiteralExpression -> NarrativeLambdaValue(
                    lambdaId = expression.lambdaId,
                    capturedVariables = visibleLocalVariables(task),
                    symbolTable = snapshotCodec.symbolTable(),
                )
                is EnumEntryExpression -> program.enumDefinitions.getValue(expression.typeId).entry(expression.entryName)
                is EnumEntriesExpression -> {
                    val definition = program.enumDefinitions.getValue(expression.typeId)
                    NarrativeEnumEntriesValue(typeId = expression.typeId, entries = definition.entries, symbolTable = snapshotCodec.symbolTable())
                }
                is EnumValueOfExpression -> {
                    val entryName = evaluateExpression(state, task, expression.entryName) as? StringValue
                        ?: throw IllegalArgumentException("Enum valueOf expects String argument")
                    program.enumDefinitions.getValue(expression.typeId).entry(entryName.value)
                }
                is EnumPropertyExpression -> {
                    val receiver = evaluateExpression(state, task, expression.receiver) as? NarrativeEnumValue
                        ?: throw IllegalArgumentException("Enum property `${expression.propertyName}` expects enum receiver")
                    when (expression.propertyName) {
                        "name" -> StringValue(receiver.entryName, snapshotCodec.symbolTable())
                        "ordinal" -> IntValue(receiver.ordinal, snapshotCodec.symbolTable())
                        else -> receiver.properties[expression.propertyName]
                            ?: throw IllegalArgumentException(
                                "Enum `${receiver.typeId}` has no property `${expression.propertyName}`"
                            )
                    }
                }
                is XmlNodeExpression -> XmlValue(
                    name = expression.name,
                    attributes = expression.attributes.map { attribute ->
                        XmlAttributeValue(
                            name = attribute.name,
                            value = evaluateExpression(state, task, attribute.value),
                        )
                    },
                    children = expression.children.flatMap { child ->
                        evaluateExpression(state, task, child).asXmlChildren()
                    },
                    symbolTable = snapshotCodec.symbolTable(),
                )
                is StructExpression -> StructValue(
                    fields = expression.fields.associate { field ->
                        field.key to evaluateExpression(state, task, field.value)
                    },
                    symbolTable = snapshotCodec.symbolTable(),
                )
                is StructArrayExpression -> StructArrayValue(
                    elements = expression.elements.map { evaluateExpression(state, task, it) },
                    symbolTable = snapshotCodec.symbolTable(),
                )
                is UnaryExpression -> {
                    val operand = evaluateExpression(state, task, expression.operand)
                    when (expression.operator) {
                        UnaryOperator.Plus -> operand
                        UnaryOperator.Minus -> operand.negateNumeric()
                        UnaryOperator.Not -> BooleanValue(!operand.asBoolean(), snapshotCodec.symbolTable())
                    }
                }
                is BinaryExpression -> {
                    val left = evaluateExpression(state, task, expression.left)
                    when (expression.operator) {
                        BinaryOperator.Add -> {
                            val right = evaluateExpression(state, task, expression.right)
                            if (left is StringValue || right is StringValue) {
                                StringValue(left.asString() + right.asString(), snapshotCodec.symbolTable())
                            } else if (left is DoubleValue || right is DoubleValue) {
                                DoubleValue(left.asDouble() + right.asDouble(), snapshotCodec.symbolTable())
                            } else {
                                IntValue(left.asInt() + right.asInt(), snapshotCodec.symbolTable())
                            }
                        }
                        BinaryOperator.Subtract -> {
                            val right = evaluateExpression(state, task, expression.right)
                            if (left is DoubleValue || right is DoubleValue) {
                                DoubleValue(left.asDouble() - right.asDouble(), snapshotCodec.symbolTable())
                            } else {
                                IntValue(left.asInt() - right.asInt(), snapshotCodec.symbolTable())
                            }
                        }
                        BinaryOperator.Multiply -> {
                            val right = evaluateExpression(state, task, expression.right)
                            if (left is DoubleValue || right is DoubleValue) {
                                DoubleValue(left.asDouble() * right.asDouble(), snapshotCodec.symbolTable())
                            } else {
                                IntValue(left.asInt() * right.asInt(), snapshotCodec.symbolTable())
                            }
                        }
                        BinaryOperator.Divide -> {
                            val right = evaluateExpression(state, task, expression.right)
                            if (left is DoubleValue || right is DoubleValue) {
                                DoubleValue(left.asDouble() / right.asDouble(), snapshotCodec.symbolTable())
                            } else {
                                IntValue(left.asInt() / right.asInt(), snapshotCodec.symbolTable())
                            }
                        }
                        BinaryOperator.Remainder -> {
                            val right = evaluateExpression(state, task, expression.right)
                            if (left is DoubleValue || right is DoubleValue) {
                                DoubleValue(left.asDouble() % right.asDouble(), snapshotCodec.symbolTable())
                            } else {
                                IntValue(left.asInt() % right.asInt(), snapshotCodec.symbolTable())
                            }
                        }
                        BinaryOperator.LessThan -> {
                            val right = evaluateExpression(state, task, expression.right)
                            if (left is DoubleValue || right is DoubleValue) {
                                BooleanValue(left.asDouble() < right.asDouble(), snapshotCodec.symbolTable())
                            } else {
                                BooleanValue(left.asInt() < right.asInt(), snapshotCodec.symbolTable())
                            }
                        }
                        BinaryOperator.LessThanOrEquals -> {
                            val right = evaluateExpression(state, task, expression.right)
                            if (left is DoubleValue || right is DoubleValue) {
                                BooleanValue(left.asDouble() <= right.asDouble(), snapshotCodec.symbolTable())
                            } else {
                                BooleanValue(left.asInt() <= right.asInt(), snapshotCodec.symbolTable())
                            }
                        }
                        BinaryOperator.GreaterThan -> {
                            val right = evaluateExpression(state, task, expression.right)
                            if (left is DoubleValue || right is DoubleValue) {
                                BooleanValue(left.asDouble() > right.asDouble(), snapshotCodec.symbolTable())
                            } else {
                                BooleanValue(left.asInt() > right.asInt(), snapshotCodec.symbolTable())
                            }
                        }
                        BinaryOperator.GreaterThanOrEquals -> {
                            val right = evaluateExpression(state, task, expression.right)
                            if (left is DoubleValue || right is DoubleValue) {
                                BooleanValue(left.asDouble() >= right.asDouble(), snapshotCodec.symbolTable())
                            } else {
                                BooleanValue(left.asInt() >= right.asInt(), snapshotCodec.symbolTable())
                            }
                        }
                        BinaryOperator.Equals -> BooleanValue(left == evaluateExpression(state, task, expression.right), snapshotCodec.symbolTable())
                        BinaryOperator.NotEquals -> BooleanValue(left != evaluateExpression(state, task, expression.right), snapshotCodec.symbolTable())
                        BinaryOperator.And -> BooleanValue(left.asBoolean() && evaluateExpression(state, task, expression.right).asBoolean(), snapshotCodec.symbolTable())
                        BinaryOperator.Or -> BooleanValue(left.asBoolean() || evaluateExpression(state, task, expression.right).asBoolean(), snapshotCodec.symbolTable())
                    }
                }
                is TypeCheckExpression -> {
                    val value = evaluateExpression(state, task, expression.subject)
                    val type = snapshotCodec.symbolTable().assertToDataType(expression.type)
                    val result = type.isAssignableFrom(value.type())
                    BooleanValue(if (expression.isNegated) !result else result, snapshotCodec.symbolTable())
                }
            }
        } catch (e: Throwable) {
            if (e is CancellationException) {
                throw e
            }
            if (e is KatariExpressionEvaluationException) {
                if (e.position != null || expression.position == null) {
                    throw e
                }
                throw KatariExpressionEvaluationException(expression.position, e.cause ?: e)
            }
            throw KatariExpressionEvaluationException(expression.position, e)
        }
    }

    private fun resolveVariableValue(state: KatariState, task: TaskState, name: String): RuntimeValue {
        val frameValue = findFrameVariable(task, currentCallFrame(task).id, name)
        if (frameValue != null) {
            return frameValue.second
        }
        findComputedGlobalAccessor(name)?.let {
            return it.read()
        }
        return state.globals[name]
            ?: throw IllegalArgumentException("Variable `$name` is not defined")
    }

    private fun findComputedGlobalAccessor(name: String): RuntimeValueAccessor? {
        if (name in currentState.globals) return null
        val symbolTable = snapshotCodec.symbolTable()
        val property = executionEnvironment
            .getGlobalProperties(symbolTable)
            .firstOrNull { it.declaredName == name }
            ?: return null
        val transformedName = symbolTable.findTransformedNameByDeclaredName(property.declaredName)
        return symbolTable.getPropertyHolder(transformedName)
    }

    private fun resolveVariableReference(
        state: KatariState,
        task: TaskState,
        name: String,
    ): SlotValue.VariableReference {
        val frameValue = findFrameVariable(task, currentCallFrame(task).id, name)
        if (frameValue != null) {
            return SlotValue.VariableReference(name = name, frameId = frameValue.first.id)
        }
        if (name in state.globals) {
            return SlotValue.VariableReference(name = name, frameId = null)
        }
        throw IllegalArgumentException("Variable `$name` is not defined")
    }

    private fun resolveSlotValue(state: KatariState, task: TaskState, slot: Int): RuntimeValue {
        val reference = task.slots[slot] as? SlotValue.VariableReference
            ?: throw IllegalArgumentException("Slot `$slot` is not defined")
        return resolveReferenceValue(state, task, reference)
    }

    private fun resolveReferenceValue(
        state: KatariState,
        task: TaskState,
        reference: SlotValue.VariableReference,
    ): RuntimeValue {
        return if (reference.frameId == null) {
            state.globals[reference.name]
                ?: throw IllegalArgumentException("Global variable `${reference.name}` is not defined")
        } else {
            findFrameById(task, reference.frameId)
                ?.localVariables
                ?.get(reference.name)
                ?: throw IllegalArgumentException("Frame variable `${reference.name}` is not defined for frame `${reference.frameId}`")
        }
    }

    private fun findFrameVariable(task: TaskState, frameId: Int, name: String): Pair<CallFrameState, RuntimeValue>? {
        val frame = findFrameById(task, frameId) ?: return null
        val value = frame.localVariables[name]
        if (value != null) {
            return frame to value
        }
        val lexicalParent = frame.lexicalParentFrameId ?: return null
        return findFrameVariable(task, lexicalParent, name)
    }

    private fun findFrameById(task: TaskState, frameId: Int): CallFrameState? {
        return task.callFrames.firstOrNull { it.id == frameId }
    }

    private fun visibleLocalVariables(task: TaskState): Map<String, RuntimeValue> {
        val variables = linkedMapOf<String, RuntimeValue>()
        fun collect(frameId: Int) {
            val frame = findFrameById(task, frameId) ?: return
            frame.lexicalParentFrameId?.let { collect(it) }
            variables += frame.localVariables
        }
        collect(currentCallFrame(task).id)
        return variables.filterKeys { !isInternalSlotVariable(it) }
    }

    private fun applyEnterCallFrameInstruction(
        task: TaskState,
        instruction: EnterCallFrameInstruction,
    ): TaskState {
        var callFrames = task.callFrames
        var nextCallFrameId = task.nextCallFrameId
        val lexicalParentFrameId = instruction.closureExpression?.let { expression ->
            val closure = evaluateExpression(currentState, task, expression) as? NarrativeLambdaValue
                ?: throw IllegalArgumentException("Lambda call `${instruction.functionId}` expects lambda receiver")
            val closureFrameId = nextCallFrameId++
            callFrames = callFrames + CallFrameState(
                id = closureFrameId,
                functionId = "${instruction.functionId}#closure",
                lexicalParentFrameId = instruction.lexicalParentFrameId,
                localVariables = closure.capturedVariables,
                isClosure = true,
            )
            closureFrameId
        } ?: instruction.lexicalParentFrameId
        val nextFrame = CallFrameState(
            id = nextCallFrameId,
            functionId = instruction.functionId,
            lexicalParentFrameId = lexicalParentFrameId,
        )
        return task.copy(
            instructionPointer = task.instructionPointer + 1,
            callFrames = callFrames + nextFrame,
            nextCallFrameId = nextCallFrameId + 1,
        )
    }

    private fun applyExitCallFrameInstruction(
        task: TaskState,
        instruction: ExitCallFrameInstruction,
        returnValue: RuntimeValue,
    ): TaskState {
        require(task.callFrames.size > 1) { "Cannot exit root call frame" }
        val exitingFrame = currentCallFrame(task)
        val closureFrame = task.callFrames.dropLast(1).lastOrNull()?.takeIf { it.isClosure }
        val exitingFrameIds = setOfNotNull(exitingFrame.id, closureFrame?.id)
        val popped = task.copy(
            callFrames = if (closureFrame != null) task.callFrames.dropLast(2) else task.callFrames.dropLast(1),
            instructionPointer = task.instructionPointer + 1,
            slots = task.slots.filterValues { ref ->
                (ref as? SlotValue.VariableReference)?.frameId !in exitingFrameIds
            },
        )
        val nextTask = applyResultTarget(
            task = syncTopLocals(popped),
            resultTarget = instruction.resultTarget,
            value = returnValue,
            nextInstructionPointer = popped.instructionPointer,
        )
        return syncTopLocals(nextTask)
    }

    private fun cleanupSlots(task: TaskState, slotsToRemove: Set<Int>): TaskState {
        if (slotsToRemove.isEmpty()) {
            return task
        }

        val removedReferences = slotsToRemove.mapNotNull { slot ->
            task.slots[slot] as? SlotValue.VariableReference
        }
        val remainingSlots = task.slots - slotsToRemove
        val remainingReferences = remainingSlots.values
            .mapNotNull { it as? SlotValue.VariableReference }
            .map { it.frameId to it.name }
            .toSet()

        var nextTask = task.copy(slots = remainingSlots)
        removedReferences.forEach { removed ->
            val key = removed.frameId to removed.name
            if (isInternalSlotVariable(removed.name) && key !in remainingReferences && removed.frameId != null) {
                nextTask = removeFrameLocal(nextTask, removed.frameId, removed.name)
            }
        }
        return syncTopLocals(nextTask)
    }

    private fun removeFrameLocal(task: TaskState, frameId: Int, name: String): TaskState {
        val index = task.callFrames.indexOfFirst { it.id == frameId }
        if (index < 0) return task
        val frame = task.callFrames[index]
        if (name !in frame.localVariables) return task
        val updated = frame.copy(localVariables = frame.localVariables - name)
        val frames = task.callFrames.toMutableList()
        frames[index] = updated
        return task.copy(callFrames = frames)
    }

    private fun collectReferencedSlots(expressions: List<KatariExpression>): Set<Int> {
        return expressions.flatMapTo(linkedSetOf()) { collectReferencedSlots(it) }
    }

    private fun collectReferencedSlots(expression: KatariExpression): Set<Int> {
        return when (expression) {
            is LiteralExpression -> emptySet()
            is VariableExpression -> emptySet()
            is SlotExpression -> setOf(expression.slot)
            is LambdaLiteralExpression -> emptySet()
            is EnumEntryExpression -> emptySet()
            is EnumEntriesExpression -> emptySet()
            is EnumValueOfExpression -> collectReferencedSlots(expression.entryName)
            is EnumPropertyExpression -> collectReferencedSlots(expression.receiver)
            is XmlNodeExpression ->
                expression.attributes.flatMapTo(linkedSetOf()) { collectReferencedSlots(it.value) } +
                    expression.children.flatMapTo(linkedSetOf()) { collectReferencedSlots(it) }
            is StructExpression -> expression.fields.flatMapTo(linkedSetOf()) { collectReferencedSlots(it.value) }
            is StructArrayExpression -> expression.elements.flatMapTo(linkedSetOf()) { collectReferencedSlots(it) }
            is UnaryExpression -> collectReferencedSlots(expression.operand)
            is BinaryExpression -> collectReferencedSlots(expression.left) + collectReferencedSlots(expression.right)
            is TypeCheckExpression -> collectReferencedSlots(expression.subject)
        }
    }

    private fun KatariState.updateTask(index: Int, task: TaskState): KatariState {
        return copy(tasks = tasks.mapIndexed { currentIndex, currentTask ->
            if (currentIndex == index) syncTopLocals(normalizeTask(task)) else currentTask
        })
    }

    private fun KatariState.completeTask(index: Int, result: RuntimeValue?): KatariState {
        return updateTask(index, tasks[index].copy(status = TaskStatus.Completed, result = result))
    }

    private fun isTaskFinal(status: TaskStatus): Boolean {
        return status == TaskStatus.Completed || status == TaskStatus.Stopped || status is TaskStatus.Failed
    }

    private fun buildRuntimeErrorMessage(position: Any?, error: Throwable): String {
        var resolvedPosition = position
        var resolvedError: Throwable = error
        if (error is KatariExpressionEvaluationException) {
            if (error.position != null) {
                resolvedPosition = error.position
            }
            resolvedError = error.cause ?: error
        }
        val base = resolvedError.message ?: resolvedError::class.simpleName ?: "Unknown Katari runtime error"
        return when (resolvedPosition) {
            null -> base
            is SourcePosition -> "$resolvedPosition $base"
            else -> "[$resolvedPosition] $base"
        }
    }

    private suspend fun markTaskAsFailed(taskId: String, message: String) {
        mutex.withLock {
            val taskIndex = currentState.tasks.indexOfFirst { it.id == taskId }
            if (taskIndex < 0) return
            val task = normalizeTask(currentState.tasks[taskIndex])
            currentState = currentState.updateTask(
                index = taskIndex,
                task = task.copy(status = TaskStatus.Failed(message = message)),
            )
            if (currentState.tasks.all { isTaskFinal(it.status) } && !completion.isCompleted) {
                completion.complete(Unit)
            }
            Unit
        }
    }

    private fun normalizeTask(task: TaskState): TaskState {
        if (task.callFrames.isNotEmpty()) {
            return syncTopLocals(task)
        }
        return task.copy(
            callFrames = listOf(
                CallFrameState(
                    id = ROOT_CALL_FRAME_ID,
                    functionId = ROOT_CALL_FRAME_FUNCTION_ID,
                    lexicalParentFrameId = null,
                    localVariables = task.localVariables,
                )
            ),
            nextCallFrameId = maxOf(task.nextCallFrameId, ROOT_CALL_FRAME_ID + 1),
        )
    }

    private fun syncTopLocals(task: TaskState): TaskState {
        val top = task.callFrames.lastOrNull() ?: return task
        return task.copy(localVariables = top.localVariables)
    }

    private fun currentCallFrame(task: TaskState): CallFrameState {
        return task.callFrames.lastOrNull()
            ?: CallFrameState(
                id = ROOT_CALL_FRAME_ID,
                functionId = ROOT_CALL_FRAME_FUNCTION_ID,
                lexicalParentFrameId = null,
                localVariables = task.localVariables,
            )
    }

    private fun compactTaskForSnapshot(task: TaskState): TaskState {
        val normalized = normalizeTask(task)
        val existingFrameIds = normalized.callFrames.map { it.id }.toSet()
        val filteredSlots = normalized.slots.filterValues { value ->
            val ref = value as SlotValue.VariableReference
            ref.frameId == null || ref.frameId in existingFrameIds
        }
        val liveRefs = filteredSlots.values
            .map { it as SlotValue.VariableReference }
            .map { it.frameId to it.name }
            .toSet()

        val compactedFrames = normalized.callFrames.map { frame ->
            val locals = frame.localVariables.filterKeys { name ->
                !isInternalSlotVariable(name) || (frame.id to name) in liveRefs
            }
            frame.copy(localVariables = locals)
        }

        return syncTopLocals(
            normalized.copy(
                callFrames = compactedFrames,
                slots = filteredSlots,
            )
        )
    }

    private fun RuntimeValue.asBoolean(): Boolean {
        return when (this) {
            is BooleanValue -> value
            else -> throw IllegalArgumentException("Expected boolean value but got $this")
        }
    }

    private fun RuntimeValue.asInt(): Int {
        return when (this) {
            is IntValue -> value
            else -> throw IllegalArgumentException("Expected int value but got $this")
        }
    }

    private fun RuntimeValue.asDouble(): Double {
        return when (this) {
            is IntValue -> value.toDouble()
            is DoubleValue -> value
            else -> throw IllegalArgumentException("Expected numeric value but got $this")
        }
    }

    private fun RuntimeValue.negateNumeric(): RuntimeValue {
        return when (this) {
            is IntValue -> IntValue(-value, snapshotCodec.symbolTable())
            is DoubleValue -> DoubleValue(-value, snapshotCodec.symbolTable())
            else -> throw IllegalArgumentException("Expected numeric value but got $this")
        }
    }

    private fun RuntimeValue.asString(): String {
        return convertToString()
    }

    private fun RuntimeValue.asXmlChildren(): List<XmlValue> {
        return when (this) {
            is XmlValue -> listOf(this)
            is StringValue -> listOf(toXmlTextValue())
            is StructArrayValue -> elements.flatMap { it.asXmlChildren() }
            is NullValue, UnitValue -> emptyList()
            is KotlinValueHolder<*> -> {
                val iterable = value as? Iterable<*> ?: return emptyList()
                iterable.flatMap { element ->
                    (element as? RuntimeValue)?.asXmlChildren().orEmpty()
                }
            }
            else -> emptyList()
        }
    }

    private fun StringValue.toXmlTextValue() = XmlValue(
        name = XML_TEXT_NODE_NAME,
        attributes = listOf(XmlAttributeValue(XML_TEXT_VALUE_ATTRIBUTE, this)),
        children = emptyList(),
        symbolTable = snapshotCodec.symbolTable(),
    )

    private fun slotVariableName(slot: Int): String = "$SLOT_VARIABLE_PREFIX$slot"

    private fun isInternalSlotVariable(name: String): Boolean = name.startsWith(SLOT_VARIABLE_PREFIX)

    private fun List<CallFrameState>.replaceLast(frame: CallFrameState): List<CallFrameState> {
        if (isEmpty()) return this
        val list = toMutableList()
        list[list.lastIndex] = frame
        return list
    }
}

private data class FunctionDispatchRequest(
    val taskId: String,
)

private fun nextTaskIdCounter(state: KatariState): Int {
    return collectKnownTaskIds(state)
        .mapNotNull { KATARI_TASK_ID_REGEX.matchEntire(it)?.groupValues?.get(1)?.toIntOrNull() }
        .maxOrNull()
        ?.plus(1)
        ?: 0
}

private fun collectKnownTaskIds(state: KatariState): Set<String> {
    val ids = linkedSetOf<String>()
    state.tasks.forEach { task ->
        ids += task.id
        task.localVariables.values.forEach { ids.collectTaskId(it) }
        task.callFrames.forEach { frame ->
            frame.localVariables.values.forEach { ids.collectTaskId(it) }
        }
        task.result?.let { ids.collectTaskId(it) }
    }
    state.globals.values.forEach { ids.collectTaskId(it) }
    return ids
}

private fun MutableSet<String>.collectTaskId(value: RuntimeValue) {
    when (value) {
        is KatariTaskValue -> {
            this += value.taskId
            value.capturedVariables.values.forEach { collectTaskId(it) }
        }
        is NarrativeLambdaValue -> value.capturedVariables.values.forEach { collectTaskId(it) }
        else -> Unit
    }
}

private val KATARI_TASK_ID_REGEX = Regex("__katari_task_(\\d+)")

private data class DispatchData(
    val taskId: String,
    val arguments: List<RuntimeValue>,
    val definition: NarrativeCallable,
    val context: NarrativeCallDispatchContext,
)

private data class ResolvedCall(
    val callable: NarrativeCallable,
    val arguments: List<RuntimeValue>,
    val typeArguments: Map<String, DataType>,
)

private class KatariCallContextImpl(
    override val symbolTable: SymbolTable,
    override val state: Any,
    override val task: Any,
    override val typeArguments: Map<String, DataType>,
) : NarrativeCallContext, NarrativeCallDispatchContext

private class KatariExpressionEvaluationException(
    val position: SourcePosition?,
    cause: Throwable,
) : RuntimeException(cause.message, cause)
