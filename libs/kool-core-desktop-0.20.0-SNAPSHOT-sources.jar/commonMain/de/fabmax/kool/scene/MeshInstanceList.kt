package de.fabmax.kool.scene

import de.fabmax.kool.pipeline.Attribute
import de.fabmax.kool.pipeline.GpuType
import de.fabmax.kool.pipeline.backend.GpuInstances
import de.fabmax.kool.scene.geometry.Usage
import de.fabmax.kool.util.*

@Deprecated("Use a layout struct instead of specifying instance attributes individually")
fun MeshInstanceList(instanceAttributes: List<Attribute>, initialSize: Int = 100): MeshInstanceList<*> {
    val layout = DynamicStruct("InstanceLayout", MemoryLayout.TightlyPacked) {
        instanceAttributes.forEach {
            when (it.type) {
                GpuType.Float1 -> float1(it.name)
                GpuType.Float2 -> float2(it.name)
                GpuType.Float3 -> float3(it.name)
                GpuType.Float4 -> float4(it.name)
                GpuType.Int1 -> int1(it.name)
                GpuType.Int2 -> int2(it.name)
                GpuType.Int3 -> int3(it.name)
                GpuType.Int4 -> int4(it.name)
                GpuType.Mat2 -> mat2(it.name)
                GpuType.Mat3 -> mat3(it.name)
                GpuType.Mat4 -> mat4(it.name)
                else -> error("${it.type} (${it.name}) not supported here")
            }
        }
    }
    return MeshInstanceList(layout, initialSize)
}

@Suppress("DEPRECATION")
@Deprecated("Use a layout struct instead of specifying instance attributes individually")
fun MeshInstanceList(initialSize: Int, vararg instanceAttributes: Attribute): MeshInstanceList<*> =
    MeshInstanceList(listOf(*instanceAttributes), initialSize)

class MeshInstanceList<Layout: Struct>(val layout: Layout, initialSize: Int = 100, val isResizable: Boolean = true) : BaseReleasable() {
    var instanceData = StructBuffer(layout, capacity = initialSize)
        private set

    /**
     * Expected usage of data in this instance list: STATIC if attributes are expected to change very infrequently /
     * never, DYNAMIC (the default value) if they will be updated often.
     */
    var usage = Usage.DYNAMIC

    /**
     * Number of instances.
     */
    var numInstances: Int
        get() = instanceData.limit
        set(value) {
            instanceData.limit = value
            incrementModCount()
        }
    val maxInstances: Int get() = instanceData.capacity

    val modCount = ModCounter()

    var gpuInstances: GpuInstances? = null

    fun incrementModCount() = modCount.increment()

    @PublishedApi
    internal fun checkBufferSize(reqSpace: Int) {
        if (reqSpace <= 0 || layout.structSize == 0) return
        val remaining = maxInstances - numInstances
        if (remaining < reqSpace) {
            check(isResizable) { "Maximum buffer size exceeded and instance buffer is not resizable" }
            val newSize = increaseBufferSize(instanceData.capacity, reqSpace - remaining, layout.structSize)
            val newData = StructBuffer(layout, newSize)
            newData.put(instanceData)
            instanceData = newData
        }
    }

    inline fun addInstances(numInstances: Int, block: (StructBuffer<Layout>) -> Unit) {
        checkBufferSize(numInstances)
        block(instanceData)
        incrementModCount()
    }

    inline fun addInstance(block: MutableStructBufferView<Layout>.(Layout) -> Unit) {
        addInstances(1) { buf -> buf.put(block) }
    }

    fun clear() {
        if (numInstances == 0) {
            return
        }
        instanceData.clear()
        incrementModCount()
    }

    /**
     * Replaces all content by the content of [source]. The given source buffer must have the same instance layout.
     * This instance list's [modCount] is set to the [modCount] value of the source instance list.
     */
    internal fun set(source: MeshInstanceList<*>) {
        require(source.layout == layout) { "Source instance layout does not match this instance layout" }
        clear()
        checkBufferSize(source.instanceData.limit)
        @Suppress("UNCHECKED_CAST")
        instanceData.put(source.instanceData as StructBuffer<Layout>)
        usage = source.usage
        modCount.reset(source.modCount)
        numInstances = source.numInstances
    }

    override fun doRelease() {
        gpuInstances?.releaseDelayed(1)
    }
}