
package de.fabmax.kool.pipeline.deferred

import de.fabmax.kool.math.MutableVec4f
import de.fabmax.kool.modules.ksl.KslShaderListener
import de.fabmax.kool.modules.ksl.lang.*
import de.fabmax.kool.pipeline.*
import de.fabmax.kool.util.MemoryLayout
import de.fabmax.kool.util.Struct

context(program: KslProgram)
fun deferredCameraData(): DeferredCamData {
    return (program.dataBlocks.find { it is DeferredCamData } as? DeferredCamData) ?: DeferredCamData(program)
}

class DeferredCamData(program: KslProgram) : KslDataBlock("DeferredCamData", program), KslShaderListener {
    private val camUniform = uniformStruct("uDeferredCameraData", DeferredCamDataStruct, BindGroupScope.VIEW)

    val position: KslExprFloat3 get() = camUniform[DeferredCamDataStruct.position]
    val projMat: KslExprMat4 get() = camUniform[DeferredCamDataStruct.proj]
    val invViewMat: KslExprMat4 get() = camUniform[DeferredCamDataStruct.invView]
    val viewport: KslExprFloat4 get() = camUniform[DeferredCamDataStruct.viewport]

    private var structLayout: UniformBufferLayout<DeferredCamDataStruct>? = null
    private val viewportVec = MutableVec4f()

    init {
        program.shaderListeners += this
        program.dataBlocks += this
    }

    override fun onShaderCreated(shader: ShaderBase<*>) {
        val (_, binding) = shader.createdPipeline!!.getUniformBufferLayout<DeferredCamDataStruct>()
        structLayout = binding
    }

    override fun onUpdateDrawData(cmd: DrawCommand) {
        val layout = structLayout ?: return
        cmd.queue.view.viewPipelineData.updatePipelineData(cmd.pipeline, layout.bindingIndex) { viewData ->
            val binding = viewData.uniformStructBindingData(layout)
            val q = cmd.queue
            val vp = q.view.viewport
            val cam = q.view.camera
            binding.set {
                set(it.proj, q.projMat)
                set(it.invView, q.invViewMatF)
                set(it.viewport, viewportVec.set(vp.x.toFloat(), vp.y.toFloat(), vp.width.toFloat(), vp.height.toFloat()))
                set(it.position, cam.globalPos)
            }
        }
    }

    object DeferredCamDataStruct : Struct("DeferredCameraData", MemoryLayout.Std140) {
        val proj = mat4("projMat")
        val invView = mat4("invView")
        val viewport = float4("viewport")
        val position = float3("position")
    }
}
