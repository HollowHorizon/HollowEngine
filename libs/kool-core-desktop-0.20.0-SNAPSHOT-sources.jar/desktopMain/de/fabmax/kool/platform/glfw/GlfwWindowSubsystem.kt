package de.fabmax.kool.platform.glfw

import de.fabmax.kool.KoolSystem
import de.fabmax.kool.configJvm
import de.fabmax.kool.platform.*
import de.fabmax.kool.util.logD
import de.fabmax.kool.util.logE
import de.fabmax.kool.util.logI
import kotlinx.coroutines.runBlocking
import org.lwjgl.glfw.GLFW.*
import org.lwjgl.glfw.GLFWErrorCallback
import org.lwjgl.glfw.GLFWVulkan
import org.lwjgl.system.MemoryUtil

object GlfwWindowSubsystem : WindowSubsystem {
    private val _monitors: MutableList<MonitorSpec> = mutableListOf()
    val monitors: List<MonitorSpec> get() = _monitors
    var primaryMonitor: MonitorSpec? = null; private set
    private var glCallbacks: GlWindowCallbacks? = null

    var primaryWindow: GlfwWindow? = null
        private set

    var platform: GlfwPlatform = GlfwPlatform.Unknown
        private set

    override val isCloseRequested: Boolean
        get() = primaryWindow?.let { glfwWindowShouldClose(it.windowHandle) } ?: false

    override val input: GlfwInput
        get() = requireNotNull(primaryWindow?.input)

    override fun queryRequiredVkExtensions(): List<String> {
        val glfwExtensions = checkNotNull(GLFWVulkan.glfwGetRequiredInstanceExtensions()) {
            "glfwGetRequiredInstanceExtensions failed to find the platform surface extensions."
        }
        return buildList {
            for (i in 0 until glfwExtensions.limit()) {
                add(MemoryUtil.memASCII(glfwExtensions[i]))
            }
        }
    }

    override fun createWindow(clientApi: ClientApi, glCallbacks: GlWindowCallbacks?, ctx: Lwjgl3Context): GlfwWindow {
        this.glCallbacks = glCallbacks
        if (clientApi == ClientApi.UNMANAGED) {
            // tell GLFW to not initialize default OpenGL API before we create the window
            check(GLFWVulkan.glfwVulkanSupported()) { "Cannot find a compatible Vulkan installable client driver (ICD)" }
            glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API)
        } else {
            // do basic GLFW configuration before we create the window
            glfwDefaultWindowHints()
            glfwWindowHint(GLFW_SAMPLES, KoolSystem.configJvm.numSamples)
        }

        val window = GlfwWindow(clientApi, ctx)
        if (primaryWindow == null) {
            primaryWindow = window
        } else {
            error("Multi-window operation is still not implemented")
        }

        if (clientApi == ClientApi.OPEN_GL) {
            glfwMakeContextCurrent(window.windowHandle)
            glfwSwapInterval(if (KoolSystem.configJvm.isVsync) 1 else 0)
            requireNotNull(glCallbacks).initGl()
        }
        return window
    }

    override fun onEarlyInit() {
        // on macOS, AWT clashes with GLFW, because GLFW also has to run on the first thread enabling AWT
        // headless-mode somewhat mitigates this problem.
        // This has to happen before *any* AWT class (BufferedImage, etc.) is loaded.
        val osName = System.getProperty("os.name", "unknown").lowercase()
        if ("mac os" in osName || "darwin" in osName || "osx" in osName) {
            logD { "Detected macOS. Enabling AWT headless mode to mitigate AWT / GLFW compatibility issues" }
            System.setProperty("java.awt.headless", "true")
        }

        GLFWErrorCallback.createPrint(System.err).set()
        check(glfwInit()) { "Unable to initialize GLFW" }

        val glfwPlatform = glfwGetPlatform()
        platform = GlfwPlatform.entries.find { it.value == glfwPlatform } ?: GlfwPlatform.Unknown.also {
            logE { "Unknown GLFW platform: $glfwPlatform" }
        }

        val primMonId = glfwGetPrimaryMonitor()
        val mons = glfwGetMonitors()!!
        var primMon = MonitorSpec(mons[0])
        for (i in 0 until mons.limit()) {
            val spec = MonitorSpec(mons[i])
            _monitors += spec
            if (mons[i] == primMonId) {
                primMon = spec
            }
        }
        primaryMonitor = primMon
    }

    override fun onBackendCreated(ctx: Lwjgl3Context) {
        input.onContextCreated(ctx)
    }

    override fun runRenderLoop() {
        val ctx = KoolSystem.requireContext() as Lwjgl3Context
        runBlocking {
            logI { "Starting GLFW render loop" }
            val window = primaryWindow!!
            while (!isCloseRequested) {
                window.pollEvents()

                if (!window.flags.isMinimized) {
                    val cb = glCallbacks
                    if (cb != null) {
                        cb.drawFrame()
                    } else {
                        ctx.renderFrame()
                    }
                } else {
                    Thread.sleep(10)
                }
            }
        }
        shutdown()
    }
}

enum class GlfwPlatform(val value: Int) {
    Windows(GLFW_PLATFORM_WIN32),
    MacOs(GLFW_PLATFORM_COCOA),
    LinuxX11(GLFW_PLATFORM_X11),
    LinuxWayland(GLFW_PLATFORM_WAYLAND),
    Unknown(GLFW_PLATFORM_UNAVAILABLE),
}
