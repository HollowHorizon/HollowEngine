package de.fabmax.kool.pipeline.backend.vk

import org.lwjgl.PointerBuffer
import org.lwjgl.system.MemoryStack
import org.lwjgl.vulkan.EXTDebugReport.VK_ERROR_VALIDATION_FAILED_EXT
import org.lwjgl.vulkan.EXTFullScreenExclusive.VK_ERROR_FULL_SCREEN_EXCLUSIVE_MODE_LOST_EXT
import org.lwjgl.vulkan.EXTImageDrmFormatModifier.VK_ERROR_INVALID_DRM_FORMAT_MODIFIER_PLANE_LAYOUT_EXT
import org.lwjgl.vulkan.KHRDeferredHostOperations.*
import org.lwjgl.vulkan.KHRDisplaySwapchain.VK_ERROR_INCOMPATIBLE_DISPLAY_KHR
import org.lwjgl.vulkan.KHRSurface.VK_ERROR_NATIVE_WINDOW_IN_USE_KHR
import org.lwjgl.vulkan.KHRSurface.VK_ERROR_SURFACE_LOST_KHR
import org.lwjgl.vulkan.KHRSwapchain.VK_ERROR_OUT_OF_DATE_KHR
import org.lwjgl.vulkan.KHRSwapchain.VK_SUBOPTIMAL_KHR
import org.lwjgl.vulkan.KHRVideoQueue.*
import org.lwjgl.vulkan.NVGLSLShader.VK_ERROR_INVALID_SHADER_NV
import org.lwjgl.vulkan.VK10.*
import org.lwjgl.vulkan.VK11.VK_ERROR_INVALID_EXTERNAL_HANDLE
import org.lwjgl.vulkan.VK11.VK_ERROR_OUT_OF_POOL_MEMORY
import org.lwjgl.vulkan.VK12.VK_ERROR_FRAGMENTATION
import org.lwjgl.vulkan.VK12.VK_ERROR_INVALID_OPAQUE_CAPTURE_ADDRESS
import org.lwjgl.vulkan.VK13.VK_PIPELINE_COMPILE_REQUIRED
import java.nio.LongBuffer

@PublishedApi
internal fun vkCheck(code: Int, msg: (String) -> String = { "Vulkan operation failed (error: $code)" }) {
    check(code == VK_SUCCESS) { msg("${VK_ERROR_CODES[code] ?: "unknown"} ($code)") }
}

internal inline fun MemoryStack.checkCreateLongPtr(block: MemoryStack.(LongBuffer) -> Int): Long {
    val lp = mallocLong(1)
    vkCheck(block(lp))
    return lp[0]
}

internal inline fun MemoryStack.checkCreatePointer(block: MemoryStack.(PointerBuffer) -> Int): Long {
    val lp = mallocPointer(1)
    vkCheck(block(lp))
    return lp[0]
}

internal val VK_ERROR_CODES = mapOf(

    VK_ERROR_INVALID_SHADER_NV to "VK_ERROR_INVALID_SHADER_NV",


)