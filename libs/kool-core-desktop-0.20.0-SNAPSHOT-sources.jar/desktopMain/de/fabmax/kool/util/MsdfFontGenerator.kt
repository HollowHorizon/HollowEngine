package de.fabmax.kool.util

import org.lwjgl.stb.STBTruetype.*


sealed interface GeneratorGlyphSet {
    fun getCodepoints(predicate: (Int) -> Boolean): Set<Int>

    data class FromString(val str: String) : GeneratorGlyphSet {
        override fun getCodepoints(predicate: (Int) -> Boolean): Set<Int> =
            str.map { it.code }.filter(predicate).toSet()
    }

    data class FromRanges(val ranges: List<IntRange>) : GeneratorGlyphSet {
        override fun getCodepoints(predicate: (Int) -> Boolean): Set<Int> = buildSet {
            ranges.forEach { range ->
                range.asSequence().filter(predicate).forEach { add(it) }
            }
        }
    }

    companion object {
        val LATIN_SMALL = FromRanges(listOf(32..0xFF))
        val ALL_BASIC = FromRanges(listOf(32..0xFFFF))
        val ALL = FromRanges(listOf(32..0x10FFFF))
    }
}
