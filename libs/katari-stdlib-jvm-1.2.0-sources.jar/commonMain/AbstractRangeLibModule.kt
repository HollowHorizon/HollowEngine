
/** Generated code. DO NOT MODIFY! Changes to this file will be overwritten. **/

package com.sunnychung.lib.multiplatform.kotlite.stdlib

import com.sunnychung.lib.multiplatform.kotlite.model.AnyType
import com.sunnychung.lib.multiplatform.kotlite.model.BooleanValue
import com.sunnychung.lib.multiplatform.kotlite.model.ByteValue
import com.sunnychung.lib.multiplatform.kotlite.model.ComparableRuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionParameter
import com.sunnychung.lib.multiplatform.kotlite.model.CharValue
import com.sunnychung.lib.multiplatform.kotlite.model.DataType
import com.sunnychung.lib.multiplatform.kotlite.model.DelegatedValue
import com.sunnychung.lib.multiplatform.kotlite.model.DoubleValue
import com.sunnychung.lib.multiplatform.kotlite.model.ExtensionProperty
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionModifier
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionBodyFormat
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionType
import com.sunnychung.lib.multiplatform.kotlite.model.GlobalProperty
import com.sunnychung.lib.multiplatform.kotlite.model.IntValue
import com.sunnychung.lib.multiplatform.kotlite.model.IterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorClass
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.KotlinValueHolder
import com.sunnychung.lib.multiplatform.kotlite.model.LambdaValue
import com.sunnychung.lib.multiplatform.kotlite.model.LibraryModule
import com.sunnychung.lib.multiplatform.kotlite.model.ListClass
import com.sunnychung.lib.multiplatform.kotlite.model.ListValue
import com.sunnychung.lib.multiplatform.kotlite.model.LongValue
import com.sunnychung.lib.multiplatform.kotlite.model.NothingType
import com.sunnychung.lib.multiplatform.kotlite.model.NullValue
import com.sunnychung.lib.multiplatform.kotlite.model.ObjectType
import com.sunnychung.lib.multiplatform.kotlite.model.PairClass
import com.sunnychung.lib.multiplatform.kotlite.model.PairValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveType
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveTypeName
import com.sunnychung.lib.multiplatform.kotlite.model.ProvidedClassDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.SourcePosition
import com.sunnychung.lib.multiplatform.kotlite.model.StringValue
import com.sunnychung.lib.multiplatform.kotlite.model.FloatValue
import com.sunnychung.lib.multiplatform.kotlite.model.ShortValue
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameter
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameterType
import com.sunnychung.lib.multiplatform.kotlite.model.RuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.UnitType
import com.sunnychung.lib.multiplatform.kotlite.model.UnitValue
import com.sunnychung.lib.multiplatform.kotlite.util.wrapPrimitiveValueAsRuntimeValue

import kotlin.ranges.random
import com.sunnychung.lib.multiplatform.kotlite.stdlib.range.ClosedRangeValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.range.OpenEndRangeValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.range.IntProgressionValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.range.IntRangeValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.range.LongProgressionValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.range.LongRangeValue




abstract class AbstractRangeLibModule : LibraryModule("Range") {
    override val classes = emptyList<ProvidedClassDefinition>()

    override val properties = listOf<ExtensionProperty>(
        ExtensionProperty(
            declaredName = "start",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
                ),
            receiver = "ClosedRange<T>",
            type = "T",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ClosedRange<ComparableRuntimeValue<Comparable<Any>, Any>>
                val result = unwrappedReceiver.start
                result ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "endInclusive",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
                ),
            receiver = "ClosedRange<T>",
            type = "T",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ClosedRange<ComparableRuntimeValue<Comparable<Any>, Any>>
                val result = unwrappedReceiver.endInclusive
                result ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "start",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
                ),
            receiver = "OpenEndRange<T>",
            type = "T",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as OpenEndRange<ComparableRuntimeValue<Comparable<Any>, Any>>
                val result = unwrappedReceiver.start
                result ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "endExclusive",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
                ),
            receiver = "OpenEndRange<T>",
            type = "T",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as OpenEndRange<ComparableRuntimeValue<Comparable<Any>, Any>>
                val result = unwrappedReceiver.endExclusive
                result ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "first",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "IntProgression",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as IntProgression
                val result = unwrappedReceiver.first
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "last",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "IntProgression",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as IntProgression
                val result = unwrappedReceiver.last
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "step",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "IntProgression",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as IntProgression
                val result = unwrappedReceiver.step
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "first",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "LongProgression",
            type = "Long",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as LongProgression
                val result = unwrappedReceiver.first
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "last",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "LongProgression",
            type = "Long",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as LongProgression
                val result = unwrappedReceiver.last
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "step",
            typeParameters = listOf<TypeParameter>(
                ),
            receiver = "LongProgression",
            type = "Long",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as LongProgression
                val result = unwrappedReceiver.step
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

    )
    
    override val globalProperties = emptyList<GlobalProperty>()
    
    override val functions = listOf<CustomFunctionDefinition>(
        CustomFunctionDefinition(
            receiverType = "ClosedRange<T>",
            functionName = "contains",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ClosedRange<ComparableRuntimeValue<Comparable<Any>, Any>>
                val value_ = args[0] as ComparableRuntimeValue<Comparable<Any>, Any>
        
                val result = unwrappedReceiver.contains(value_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 4, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "ClosedRange<T>",
            functionName = "isEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as ClosedRange<ComparableRuntimeValue<Comparable<Any>, Any>>
        
                val result = unwrappedReceiver.isEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 5, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "OpenEndRange<T>",
            functionName = "contains",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as OpenEndRange<ComparableRuntimeValue<Comparable<Any>, Any>>
                val value_ = args[0] as ComparableRuntimeValue<Comparable<Any>, Any>
        
                val result = unwrappedReceiver.contains(value_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 10, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "OpenEndRange<T>",
            functionName = "isEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as OpenEndRange<ComparableRuntimeValue<Comparable<Any>, Any>>
        
                val result = unwrappedReceiver.isEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 11, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "T",
            functionName = "rangeTo",
            returnType = "ClosedRange<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "that", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = receiver as ComparableRuntimeValue<Comparable<Any>, Any>
                val that_ = args[0] as ComparableRuntimeValue<Comparable<Any>, Any>
        
                val result = unwrappedReceiver.rangeTo(that_)
                result?.let { ClosedRangeValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = ClosedRange<T>; t.name = ClosedRange; t = ClosedRange<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 13, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "T",
            functionName = "rangeUntil",
            returnType = "OpenEndRange<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "that", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = receiver as ComparableRuntimeValue<Comparable<Any>, Any>
                val that_ = args[0] as ComparableRuntimeValue<Comparable<Any>, Any>
        
                val result = unwrappedReceiver.rangeUntil(that_)
                result?.let { OpenEndRangeValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = OpenEndRange<T>; t.name = OpenEndRange; t = OpenEndRange<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 14, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "T",
            functionName = "coerceAtLeast",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = receiver as ComparableRuntimeValue<Comparable<Any>, Any>
                val minimumValue_ = args[0] as ComparableRuntimeValue<Comparable<Any>, Any>
        
                val result = unwrappedReceiver.coerceAtLeast(minimumValue_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 15, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "T",
            functionName = "coerceAtMost",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "maximumValue", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = receiver as ComparableRuntimeValue<Comparable<Any>, Any>
                val maximumValue_ = args[0] as ComparableRuntimeValue<Comparable<Any>, Any>
        
                val result = unwrappedReceiver.coerceAtMost(maximumValue_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 16, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "T",
            functionName = "coerceIn",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "T?"),
                CustomFunctionParameter(name = "maximumValue", type = "T?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = receiver as ComparableRuntimeValue<Comparable<Any>, Any>
                val minimumValue_ = args[0] as? ComparableRuntimeValue<Comparable<Any>, Any>
            val maximumValue_ = args[1] as? ComparableRuntimeValue<Comparable<Any>, Any>
        
                val result = unwrappedReceiver.coerceIn(minimumValue_, maximumValue_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 17, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "T",
            functionName = "coerceIn",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "range", type = "ClosedRange<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = receiver as ComparableRuntimeValue<Comparable<Any>, Any>
                val range_ = (args[0] as KotlinValueHolder<*>).value as ClosedRange<ComparableRuntimeValue<Comparable<Any>, Any>>
        
                val result = unwrappedReceiver.coerceIn(range_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 18, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Byte",
            functionName = "coerceIn",
            returnType = "Byte",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Byte"),
                CustomFunctionParameter(name = "maximumValue", type = "Byte"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as ByteValue).value
                val minimumValue_ = (args[0] as ByteValue).value
            val maximumValue_ = (args[1] as ByteValue).value
        
                val result = unwrappedReceiver.coerceIn(minimumValue_, maximumValue_)
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 19, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Short",
            functionName = "coerceIn",
            returnType = "Short",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Short"),
                CustomFunctionParameter(name = "maximumValue", type = "Short"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Short
                val minimumValue_ = (args[0] as KotlinValueHolder<*>).value as Short
            val maximumValue_ = (args[1] as KotlinValueHolder<*>).value as Short
        
                val result = unwrappedReceiver.coerceIn(minimumValue_, maximumValue_)
                result?.let { ShortValue(it /* _t = Short; t.name = Short; t = Short */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 20, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "coerceIn",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Int"),
                CustomFunctionParameter(name = "maximumValue", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val minimumValue_ = (args[0] as IntValue).value
            val maximumValue_ = (args[1] as IntValue).value
        
                val result = unwrappedReceiver.coerceIn(minimumValue_, maximumValue_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 21, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "coerceIn",
            returnType = "Long",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Long"),
                CustomFunctionParameter(name = "maximumValue", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val minimumValue_ = (args[0] as LongValue).value
            val maximumValue_ = (args[1] as LongValue).value
        
                val result = unwrappedReceiver.coerceIn(minimumValue_, maximumValue_)
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 22, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Float",
            functionName = "coerceIn",
            returnType = "Float",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Float"),
                CustomFunctionParameter(name = "maximumValue", type = "Float"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Float
                val minimumValue_ = (args[0] as KotlinValueHolder<*>).value as Float
            val maximumValue_ = (args[1] as KotlinValueHolder<*>).value as Float
        
                val result = unwrappedReceiver.coerceIn(minimumValue_, maximumValue_)
                result?.let { FloatValue(it /* _t = Float; t.name = Float; t = Float */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 23, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "coerceIn",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Double"),
                CustomFunctionParameter(name = "maximumValue", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
                val minimumValue_ = (args[0] as DoubleValue).value
            val maximumValue_ = (args[1] as DoubleValue).value
        
                val result = unwrappedReceiver.coerceIn(minimumValue_, maximumValue_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 24, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Byte",
            functionName = "coerceAtLeast",
            returnType = "Byte",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Byte"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as ByteValue).value
                val minimumValue_ = (args[0] as ByteValue).value
        
                val result = unwrappedReceiver.coerceAtLeast(minimumValue_)
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 25, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Short",
            functionName = "coerceAtLeast",
            returnType = "Short",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Short"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Short
                val minimumValue_ = (args[0] as KotlinValueHolder<*>).value as Short
        
                val result = unwrappedReceiver.coerceAtLeast(minimumValue_)
                result?.let { ShortValue(it /* _t = Short; t.name = Short; t = Short */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 26, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "coerceAtLeast",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val minimumValue_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.coerceAtLeast(minimumValue_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 27, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "coerceAtLeast",
            returnType = "Long",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val minimumValue_ = (args[0] as LongValue).value
        
                val result = unwrappedReceiver.coerceAtLeast(minimumValue_)
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 28, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Float",
            functionName = "coerceAtLeast",
            returnType = "Float",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Float"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Float
                val minimumValue_ = (args[0] as KotlinValueHolder<*>).value as Float
        
                val result = unwrappedReceiver.coerceAtLeast(minimumValue_)
                result?.let { FloatValue(it /* _t = Float; t.name = Float; t = Float */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 29, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "coerceAtLeast",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "minimumValue", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
                val minimumValue_ = (args[0] as DoubleValue).value
        
                val result = unwrappedReceiver.coerceAtLeast(minimumValue_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 30, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Byte",
            functionName = "coerceAtMost",
            returnType = "Byte",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "maximumValue", type = "Byte"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as ByteValue).value
                val maximumValue_ = (args[0] as ByteValue).value
        
                val result = unwrappedReceiver.coerceAtMost(maximumValue_)
                result?.let { ByteValue(it /* _t = Byte; t.name = Byte; t = Byte */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 31, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Short",
            functionName = "coerceAtMost",
            returnType = "Short",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "maximumValue", type = "Short"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Short
                val maximumValue_ = (args[0] as KotlinValueHolder<*>).value as Short
        
                val result = unwrappedReceiver.coerceAtMost(maximumValue_)
                result?.let { ShortValue(it /* _t = Short; t.name = Short; t = Short */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 32, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "coerceAtMost",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "maximumValue", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val maximumValue_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.coerceAtMost(maximumValue_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 33, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "coerceAtMost",
            returnType = "Long",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "maximumValue", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val maximumValue_ = (args[0] as LongValue).value
        
                val result = unwrappedReceiver.coerceAtMost(maximumValue_)
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 34, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Float",
            functionName = "coerceAtMost",
            returnType = "Float",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "maximumValue", type = "Float"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Float
                val maximumValue_ = (args[0] as KotlinValueHolder<*>).value as Float
        
                val result = unwrappedReceiver.coerceAtMost(maximumValue_)
                result?.let { FloatValue(it /* _t = Float; t.name = Float; t = Float */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 35, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Double",
            functionName = "coerceAtMost",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "maximumValue", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as DoubleValue).value
                val maximumValue_ = (args[0] as DoubleValue).value
        
                val result = unwrappedReceiver.coerceAtMost(maximumValue_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 36, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "IntProgression",
            functionName = "isEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as IntProgression
        
                val result = unwrappedReceiver.isEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 54, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "IntProgression",
            functionName = "reversed",
            returnType = "IntProgression",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as IntProgression
        
                val result = unwrappedReceiver.reversed()
                result?.let { IntProgressionValue(it /* _t = IntProgression; t.name = IntProgression; t = IntProgression */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 55, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "IntProgression",
            functionName = "step",
            returnType = "IntProgression",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "step", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as IntProgression
                val step_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.step(step_)
                result?.let { IntProgressionValue(it /* _t = IntProgression; t.name = IntProgression; t = IntProgression */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 56, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "IntRange",
            functionName = "contains",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "Int?"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as IntRange
                val element_ = (args[0] as? IntValue)?.value
        
                val result = unwrappedReceiver.contains(element_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 57, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "IntRange",
            functionName = "random",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as IntRange
        
                val result = unwrappedReceiver.random()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 58, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "IntRange",
            functionName = "random",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "random", type = "KRandom"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as IntRange
                val random_ = (args[0] as KotlinValueHolder<*>).value as KRandom
        
                val result = unwrappedReceiver.random(random_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 59, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "IntRange",
            functionName = "randomOrNull",
            returnType = "Int?",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as IntRange
        
                val result = unwrappedReceiver.randomOrNull()
                result?.let { IntValue(it /* _t = Int?; t.name = Int; t = Int? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 60, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "downTo",
            returnType = "IntProgression",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Byte"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val to_ = (args[0] as ByteValue).value
        
                val result = unwrappedReceiver.downTo(to_)
                result?.let { IntProgressionValue(it /* _t = IntProgression; t.name = IntProgression; t = IntProgression */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 61, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "downTo",
            returnType = "IntProgression",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val to_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.downTo(to_)
                result?.let { IntProgressionValue(it /* _t = IntProgression; t.name = IntProgression; t = IntProgression */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 62, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "downTo",
            returnType = "LongProgression",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val to_ = (args[0] as LongValue).value
        
                val result = unwrappedReceiver.downTo(to_)
                result?.let { LongProgressionValue(it /* _t = LongProgression; t.name = LongProgression; t = LongProgression */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 63, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "until",
            returnType = "IntRange",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Byte"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val to_ = (args[0] as ByteValue).value
        
                val result = unwrappedReceiver.until(to_)
                result?.let { IntRangeValue(it /* _t = IntRange; t.name = IntRange; t = IntRange */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 64, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "until",
            returnType = "IntRange",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val to_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.until(to_)
                result?.let { IntRangeValue(it /* _t = IntRange; t.name = IntRange; t = IntRange */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 65, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "until",
            returnType = "LongRange",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val to_ = (args[0] as LongValue).value
        
                val result = unwrappedReceiver.until(to_)
                result?.let { LongRangeValue(it /* _t = LongRange; t.name = LongRange; t = LongRange */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 66, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "rangeTo",
            returnType = "IntRange",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "that", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val that_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.rangeTo(that_)
                result?.let { IntRangeValue(it /* _t = IntRange; t.name = IntRange; t = IntRange */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 67, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Int",
            functionName = "rangeUntil",
            returnType = "IntRange",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "that", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as IntValue).value
                val that_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.rangeUntil(that_)
                result?.let { IntRangeValue(it /* _t = IntRange; t.name = IntRange; t = IntRange */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 68, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "LongProgression",
            functionName = "isEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as LongProgression
        
                val result = unwrappedReceiver.isEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 73, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "LongProgression",
            functionName = "reversed",
            returnType = "LongProgression",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as LongProgression
        
                val result = unwrappedReceiver.reversed()
                result?.let { LongProgressionValue(it /* _t = LongProgression; t.name = LongProgression; t = LongProgression */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 74, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "LongProgression",
            functionName = "step",
            returnType = "LongProgression",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "step", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as LongProgression
                val step_ = (args[0] as LongValue).value
        
                val result = unwrappedReceiver.step(step_)
                result?.let { LongProgressionValue(it /* _t = LongProgression; t.name = LongProgression; t = LongProgression */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 75, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "LongRange",
            functionName = "contains",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "Long?"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as LongRange
                val element_ = (args[0] as? LongValue)?.value
        
                val result = unwrappedReceiver.contains(element_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 76, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "LongRange",
            functionName = "random",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as LongRange
        
                val result = unwrappedReceiver.random()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 77, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "LongRange",
            functionName = "random",
            returnType = "Long",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "random", type = "KRandom"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as LongRange
                val random_ = (args[0] as KotlinValueHolder<*>).value as KRandom
        
                val result = unwrappedReceiver.random(random_)
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 78, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "LongRange",
            functionName = "randomOrNull",
            returnType = "Long?",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as LongRange
        
                val result = unwrappedReceiver.randomOrNull()
                result?.let { LongValue(it /* _t = Long?; t.name = Long; t = Long? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 79, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "downTo",
            returnType = "LongProgression",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Byte"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val to_ = (args[0] as ByteValue).value
        
                val result = unwrappedReceiver.downTo(to_)
                result?.let { LongProgressionValue(it /* _t = LongProgression; t.name = LongProgression; t = LongProgression */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 80, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "downTo",
            returnType = "LongProgression",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val to_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.downTo(to_)
                result?.let { LongProgressionValue(it /* _t = LongProgression; t.name = LongProgression; t = LongProgression */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 81, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "downTo",
            returnType = "LongProgression",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val to_ = (args[0] as LongValue).value
        
                val result = unwrappedReceiver.downTo(to_)
                result?.let { LongProgressionValue(it /* _t = LongProgression; t.name = LongProgression; t = LongProgression */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 82, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "until",
            returnType = "LongRange",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Byte"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val to_ = (args[0] as ByteValue).value
        
                val result = unwrappedReceiver.until(to_)
                result?.let { LongRangeValue(it /* _t = LongRange; t.name = LongRange; t = LongRange */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 83, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "until",
            returnType = "LongRange",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val to_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.until(to_)
                result?.let { LongRangeValue(it /* _t = LongRange; t.name = LongRange; t = LongRange */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 84, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "until",
            returnType = "LongRange",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "to", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val to_ = (args[0] as LongValue).value
        
                val result = unwrappedReceiver.until(to_)
                result?.let { LongRangeValue(it /* _t = LongRange; t.name = LongRange; t = LongRange */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 85, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "rangeTo",
            returnType = "LongRange",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "that", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val that_ = (args[0] as LongValue).value
        
                val result = unwrappedReceiver.rangeTo(that_)
                result?.let { LongRangeValue(it /* _t = LongRange; t.name = LongRange; t = LongRange */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 86, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Long",
            functionName = "rangeUntil",
            returnType = "LongRange",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "that", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as LongValue).value
                val that_ = (args[0] as LongValue).value
        
                val result = unwrappedReceiver.rangeUntil(that_)
                result?.let { LongRangeValue(it /* _t = LongRange; t.name = LongRange; t = LongRange */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Range", lineNum = 87, col = 10),
        ),

    )
}
