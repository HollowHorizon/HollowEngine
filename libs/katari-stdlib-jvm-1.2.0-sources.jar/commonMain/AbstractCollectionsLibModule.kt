
/** Generated code. DO NOT MODIFY! Changes to this file will be overwritten. **/

package com.sunnychung.lib.multiplatform.kotlite.stdlib

import com.sunnychung.lib.multiplatform.kotlite.model.AnyType
import com.sunnychung.lib.multiplatform.kotlite.model.BooleanValue
import com.sunnychung.lib.multiplatform.kotlite.model.ByteValue
import com.sunnychung.lib.multiplatform.kotlite.model.ComparableRuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionParameter
import com.sunnychung.lib.multiplatform.kotlite.model.CharValue
import com.sunnychung.lib.multiplatform.kotlite.model.DataType
import com.sunnychung.lib.multiplatform.kotlite.model.DelegatedValue
import com.sunnychung.lib.multiplatform.kotlite.model.DoubleValue
import com.sunnychung.lib.multiplatform.kotlite.model.ExtensionProperty
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionModifier
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionBodyFormat
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionType
import com.sunnychung.lib.multiplatform.kotlite.model.GlobalProperty
import com.sunnychung.lib.multiplatform.kotlite.model.IntValue
import com.sunnychung.lib.multiplatform.kotlite.model.IterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorClass
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.KotlinValueHolder
import com.sunnychung.lib.multiplatform.kotlite.model.LambdaValue
import com.sunnychung.lib.multiplatform.kotlite.model.LibraryModule
import com.sunnychung.lib.multiplatform.kotlite.model.ListClass
import com.sunnychung.lib.multiplatform.kotlite.model.ListValue
import com.sunnychung.lib.multiplatform.kotlite.model.LongValue
import com.sunnychung.lib.multiplatform.kotlite.model.NothingType
import com.sunnychung.lib.multiplatform.kotlite.model.NullValue
import com.sunnychung.lib.multiplatform.kotlite.model.ObjectType
import com.sunnychung.lib.multiplatform.kotlite.model.PairClass
import com.sunnychung.lib.multiplatform.kotlite.model.PairValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveType
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveTypeName
import com.sunnychung.lib.multiplatform.kotlite.model.ProvidedClassDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.SourcePosition
import com.sunnychung.lib.multiplatform.kotlite.model.StringValue
import com.sunnychung.lib.multiplatform.kotlite.model.FloatValue
import com.sunnychung.lib.multiplatform.kotlite.model.ShortValue
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameter
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameterType
import com.sunnychung.lib.multiplatform.kotlite.model.RuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.UnitType
import com.sunnychung.lib.multiplatform.kotlite.model.UnitValue
import com.sunnychung.lib.multiplatform.kotlite.util.wrapPrimitiveValueAsRuntimeValue

import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.MutableListValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.MapValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.MutableMapValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.MapEntryValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.SetValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.MutableSetValue
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.wrap
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.MutableListClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.MapClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.MutableMapClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.MapEntryClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.SetClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.collections.MutableSetClass
import kotlin.collections.random


typealias MapEntry<K, V> = Map.Entry<K, V>


abstract class AbstractCollectionsLibModule : LibraryModule("Collections") {
    override val classes = emptyList<ProvidedClassDefinition>()

    override val properties = listOf<ExtensionProperty>(
        ExtensionProperty(
            declaredName = "size",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "T", typeUpperBound = null),
                ),
            receiver = "List<T>",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val result = unwrappedReceiver.size
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "lastIndex",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "T", typeUpperBound = null),
                ),
            receiver = "List<T>",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val result = unwrappedReceiver.lastIndex
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "size",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                ),
            receiver = "Map<K, V>",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val result = unwrappedReceiver.size
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "keys",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                ),
            receiver = "Map<K, V>",
            type = "Collection<K>",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val result = unwrappedReceiver.keys
                result.toList()?.let { ListValue(it, typeArgs["K"]!!.copyOf(isNullable = false) /* _t = Collection<K>; t.name = Collection; t = Collection<K> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "values",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                ),
            receiver = "Map<K, V>",
            type = "Collection<V>",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val result = unwrappedReceiver.values
                result.toList()?.let { ListValue(it, typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Collection<V>; t.name = Collection; t = Collection<V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "key",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                ),
            receiver = "MapEntry<K, V>",
            type = "K",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MapEntry<RuntimeValue, RuntimeValue>
                val result = unwrappedReceiver.key
                result?.let { it as RuntimeValue } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "value",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                ),
            receiver = "MapEntry<K, V>",
            type = "V",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MapEntry<RuntimeValue, RuntimeValue>
                val result = unwrappedReceiver.value
                result?.let { it as RuntimeValue } ?: NullValue
            },
            setter = null,
        ),

        ExtensionProperty(
            declaredName = "size",
            typeParameters = listOf<TypeParameter>(
                TypeParameter(name = "T", typeUpperBound = null),
                ),
            receiver = "Set<T>",
            type = "Int",
            getter = { interpreter, receiver, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Set<RuntimeValue>
                val result = unwrappedReceiver.size
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            setter = null,
        ),

    )
    
    override val globalProperties = emptyList<GlobalProperty>()
    
    override val functions = listOf<CustomFunctionDefinition>(
        CustomFunctionDefinition(
            receiverType = null,
            functionName = "listOf",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "T", modifiers = setOf("vararg")),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val elements_ = (args[0] as KotlinValueHolder<List<RuntimeValue>>).value.map { it as RuntimeValue }
        
                val result = listOf(*elements_.toTypedArray())
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 9, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "mutableListOf",
            returnType = "MutableList<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "T", modifiers = setOf("vararg")),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val elements_ = (args[0] as KotlinValueHolder<List<RuntimeValue>>).value.map { it as RuntimeValue }
        
                val result = mutableListOf(*elements_.toTypedArray())
                result?.toMutableList()?.let { MutableListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = MutableList<T>; t.name = MutableList; t = MutableList<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 10, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "listOfNotNull",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "T?", modifiers = setOf("vararg")),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val elements_ = (args[0] as KotlinValueHolder<List<RuntimeValue>>).value.map { (it as RuntimeValue).toNullable() }
        
                val result = listOfNotNull(*elements_.toTypedArray())
                result?.map { it.toRuntimeValue() }?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 12, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "List",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "size", type = "Int"),
                CustomFunctionParameter(name = "init", type = "(Int) -> T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val size_ = (args[0] as IntValue).value
            val init_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = List(size_, init_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 13, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "MutableList",
            returnType = "MutableList<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "size", type = "Int"),
                CustomFunctionParameter(name = "init", type = "(Int) -> T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val size_ = (args[0] as IntValue).value
            val init_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = MutableList(size_, init_)
                result?.toMutableList()?.let { MutableListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = MutableList<T>; t.name = MutableList; t = MutableList<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 14, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableCollection<T>",
            functionName = "add",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableCollection<RuntimeValue>
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.add(element_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 16, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableCollection<T>",
            functionName = "addAll",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Iterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableCollection<RuntimeValue>
                val elements_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.addAll(elements_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 17, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "all",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.all(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 18, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "any",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.any(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 19, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "asReversed",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.asReversed()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 20, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T?>",
            functionName = "binarySearch",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T?"),
                CustomFunctionParameter(name = "fromIndex", type = "Int", defaultValueExpression = "0"),
                CustomFunctionParameter(name = "toIndex", type = "Int", defaultValueExpression = "size"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as? ComparableRuntimeValue<Comparable<Any>, Any> }
                val element_ = args[0] as? ComparableRuntimeValue<Comparable<Any>, Any>
            val fromIndex_ = (args[1] as IntValue).value
            val toIndex_ = (args[2] as IntValue).value
        
                val result = unwrappedReceiver.binarySearch(element_, fromIndex_, toIndex_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 21, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "binarySearch",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "fromIndex", type = "Int", defaultValueExpression = "0"),
                CustomFunctionParameter(name = "toIndex", type = "Int", defaultValueExpression = "size"),
                CustomFunctionParameter(name = "comparison", type = "(T) -> Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val fromIndex_ = (args[0] as IntValue).value
            val toIndex_ = (args[1] as IntValue).value
            val comparison_ = (args[2] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as IntValue).value
                } }
        
                val result = unwrappedReceiver.binarySearch(fromIndex_, toIndex_, comparison_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 26, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "binarySearchBy",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K?"),
                CustomFunctionParameter(name = "fromIndex", type = "Int", defaultValueExpression = "0"),
                CustomFunctionParameter(name = "toIndex", type = "Int", defaultValueExpression = "size"),
                CustomFunctionParameter(name = "selector", type = "(T) -> K?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "K", typeUpperBound = "Comparable<K>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val key_ = args[0] as? ComparableRuntimeValue<Comparable<Any>, Any>
            val fromIndex_ = (args[1] as IntValue).value
            val toIndex_ = (args[2] as IntValue).value
            val selector_ = (args[3] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as? ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.binarySearchBy(key_, fromIndex_, toIndex_, selector_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 31, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "chunked",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "size", type = "Int"),
                CustomFunctionParameter(name = "transform", type = "(List<T>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val size_ = (args[0] as IntValue).value
            val transform_ = (args[1] as LambdaValue).let { lambda -> { arg0: List<RuntimeValue> ->
                    val wa0 = arg0?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.chunked(size_, transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 38, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "contains",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.contains(element_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 39, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "containsAll",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "List<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val elements_ = (args[0] as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.containsAll(elements_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 40, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableCollection<T>",
            functionName = "clear",
            returnType = "Unit",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableCollection<RuntimeValue>
        
                val result = unwrappedReceiver.clear()
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 41, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "count",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.count(predicate_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 42, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "count",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.count()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 43, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "distinct",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.distinct()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 44, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "distinctBy",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "K", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.distinctBy(selector_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 45, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "drop",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.drop(n_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 46, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "dropLast",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.dropLast(n_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 47, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "dropLastWhile",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.dropLastWhile(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 48, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "dropWhile",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.dropWhile(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 49, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "elementAt",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val index_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.elementAt(index_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 50, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "elementAtOrElse",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
                CustomFunctionParameter(name = "defaultValue", type = "(Int) -> T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val index_ = (args[0] as IntValue).value
            val defaultValue_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.elementAtOrElse(index_, defaultValue_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 51, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "elementAtOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val index_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.elementAtOrNull(index_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 52, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "fill",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
                val value_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.fill(value_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 53, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "filter",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filter(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 54, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "filterIndexed",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Int, T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filterIndexed(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 55, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "filterNot",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filterNot(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 57, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T?>",
            functionName = "filterNotNull",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { (it as RuntimeValue).toNullable() }
        
                val result = unwrappedReceiver.filterNotNull()
                result?.map { it.toRuntimeValue() }?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 58, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "find",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.find(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 59, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "findLast",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.findLast(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 60, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "first",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.first()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 61, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "first",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.first(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 62, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "firstNotNullOf",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { (it as RuntimeValue).toNullable() }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue? ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as RuntimeValue).toNullable()
                } }
        
                val result = unwrappedReceiver.firstNotNullOf(transform_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 63, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "firstNotNullOfOrNull",
            returnType = "R?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { (it as RuntimeValue).toNullable() }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue? ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as RuntimeValue).toNullable()
                } }
        
                val result = unwrappedReceiver.firstNotNullOfOrNull(transform_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 66, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "firstOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.firstOrNull()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 69, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "firstOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.firstOrNull(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 70, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "flatMap",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> Iterable<R>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                } }
        
                val result = unwrappedReceiver.flatMap(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 71, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "flatMapIndexed",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(Int, T) -> Iterable<R>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    (result as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                } }
        
                val result = unwrappedReceiver.flatMapIndexed(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 74, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "fold",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "initial", type = "R"),
                CustomFunctionParameter(name = "operation", type = "(R, T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val initial_ = args[0] as RuntimeValue
            val operation_ = (args[1] as LambdaValue).let { lambda -> { arg0: RuntimeValue, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.fold(initial_, operation_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 78, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "foldIndexed",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "initial", type = "R"),
                CustomFunctionParameter(name = "operation", type = "(Int, R, T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val initial_ = args[0] as RuntimeValue
            val operation_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue, arg2: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
                    val wa2 = arg2?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1, wa2))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.foldIndexed(initial_, operation_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 82, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "foldRight",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "initial", type = "R"),
                CustomFunctionParameter(name = "operation", type = "(T, R) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val initial_ = args[0] as RuntimeValue
            val operation_ = (args[1] as LambdaValue).let { lambda -> { arg0: RuntimeValue, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.foldRight(initial_, operation_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 86, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "foldRightIndexed",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "initial", type = "R"),
                CustomFunctionParameter(name = "operation", type = "(Int, T, R) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val initial_ = args[0] as RuntimeValue
            val operation_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue, arg2: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
                    val wa2 = arg2?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1, wa2))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.foldRightIndexed(initial_, operation_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 90, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "forEach",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(T) -> Unit"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.inline),
            inlineFunctionBody = "{\n    for (element in this) {\n        action(element)\n    }\n}",
            inlineFunctionBodyFormat = FunctionBodyFormat.Block,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    Unit
                } }
        
                val result = unwrappedReceiver.forEach(action_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 94, col = 8),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "forEachIndexed",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(Int, T) -> Unit"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    Unit
                } }
        
                val result = unwrappedReceiver.forEachIndexed(action_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 99, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "get",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val index_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.get(index_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 100, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "getOrElse",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
                CustomFunctionParameter(name = "defaultValue", type = "(Int) -> T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val index_ = (args[0] as IntValue).value
            val defaultValue_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.getOrElse(index_, defaultValue_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 101, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "getOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val index_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.getOrNull(index_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 105, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "indexOf",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.indexOf(element_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 107, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "indexOfFirst",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.indexOfFirst(predicate_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 108, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "indexOfLast",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.indexOfLast(predicate_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 109, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "isEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.isEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 110, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "isNotEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.isNotEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 111, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>?",
            functionName = "isNullOrEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.isNullOrEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 112, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "joinToString",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "separator", type = "String", defaultValueExpression = "\", \""),
                CustomFunctionParameter(name = "prefix", type = "String", defaultValueExpression = "\"\""),
                CustomFunctionParameter(name = "postfix", type = "String", defaultValueExpression = "\"\""),
                CustomFunctionParameter(name = "limit", type = "Int", defaultValueExpression = "-(1)"),
                CustomFunctionParameter(name = "truncated", type = "String", defaultValueExpression = "\"...\""),
                CustomFunctionParameter(name = "transform", type = "((T) -> String)?", defaultValueExpression = "null"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val separator_ = (args[0] as StringValue).value
            val prefix_ = (args[1] as StringValue).value
            val postfix_ = (args[2] as StringValue).value
            val limit_ = (args[3] as IntValue).value
            val truncated_ = (args[4] as StringValue).value
            val transform_ = (args[5] as? LambdaValue)?.let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as StringValue).value
                } }
        
                val result = unwrappedReceiver.joinToString(separator_, prefix_, postfix_, limit_, truncated_, transform_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 113, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "last",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.last()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 121, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "last",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.last(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 122, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "lastIndexOf",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.lastIndexOf(element_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 123, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "lastOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.lastOrNull()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 124, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "lastOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.lastOrNull(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 125, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "map",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.inline),
            inlineFunctionBody = "{\n    val result = mutableListOf<R>()\n    for (element in this) {\n        result.add(transform(element))\n    }\n    return result\n}",
            inlineFunctionBodyFormat = FunctionBodyFormat.Block,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.map(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 126, col = 8),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "mapIndexed",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(Int, T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.mapIndexed(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 133, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "mapIndexedNotNull",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(Int, T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { (it as RuntimeValue).toNullable() }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue? ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    (result as RuntimeValue).toNullable()
                } }
        
                val result = unwrappedReceiver.mapIndexedNotNull(transform_)
                result?.map { it.toRuntimeValue() }?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 134, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "mapNotNull",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { (it as RuntimeValue).toNullable() }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue? ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as RuntimeValue).toNullable()
                } }
        
                val result = unwrappedReceiver.mapNotNull(transform_)
                result?.map { it.toRuntimeValue() }?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 135, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "max",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.max()
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 136, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "maxBy",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxBy(selector_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 137, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "maxByOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxByOrNull(selector_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 138, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "maxOf",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxOf(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 139, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "maxOfOrNull",
            returnType = "R?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxOfOrNull(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 140, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "maxOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.maxOrNull()
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 141, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "min",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.min()
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 142, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "minBy",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minBy(selector_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 143, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "minByOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minByOrNull(selector_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 144, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "minOf",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minOf(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 145, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "minOfOrNull",
            returnType = "R?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minOfOrNull(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 146, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "minOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.minOrNull()
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 147, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "minus",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.minus(element_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 148, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "minus",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Iterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val elements_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.minus(elements_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 149, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableCollection<T>",
            functionName = "minusAssign",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableCollection<RuntimeValue>
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.minusAssign(element_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 150, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableCollection<T>",
            functionName = "minusAssign",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Iterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableCollection<RuntimeValue>
                val elements_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.minusAssign(elements_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 151, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "minusElement",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.minusElement(element_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 152, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "none",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.none(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 153, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "none",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.none()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 154, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "C",
            functionName = "onEach",
            returnType = "C",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(T) -> Unit"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "C", typeUpperBound = "Iterable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Iterable<RuntimeValue>
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    Unit
                } }
        
                val result = unwrappedReceiver.onEach(action_)
                result?.let { DelegatedValue<Iterable<RuntimeValue>>(it, (receiver.type() as ObjectType).clazz, listOf<DataType>(typeArgs["T"]!!.copyOf(isNullable = false) /* _t = C; t.name = Iterable; t = Iterable<T> */), symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 155, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "onEachIndexed",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(Int, T) -> Unit"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    Unit
                } }
        
                val result = unwrappedReceiver.onEachIndexed(action_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 156, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>?",
            functionName = "orEmpty",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.orEmpty()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 157, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "partition",
            returnType = "Pair<List<T>, List<T>>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.partition(predicate_)
                result.let { ListValue(it.first, typeArgs["T"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) to ListValue(it.second, typeArgs["T"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) }?.let { PairValue(it, ObjectType(ListClass.clazz, listOf<DataType>(typeArgs["T"]!!.copyOf(isNullable = false)), superTypes = emptyList()), ObjectType(ListClass.clazz, listOf<DataType>(typeArgs["T"]!!.copyOf(isNullable = false)), superTypes = emptyList()) /* _t = Pair<List<T>, List<T>>; t.name = Pair; t = Pair<List<T>, List<T>> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 158, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "plus",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.plus(element_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 159, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "plus",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "List<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val elements_ = (args[0] as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.plus(elements_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 160, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableCollection<T>",
            functionName = "plusAssign",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableCollection<RuntimeValue>
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.plusAssign(element_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 161, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableCollection<T>",
            functionName = "plusAssign",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Iterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableCollection<RuntimeValue>
                val elements_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.plusAssign(elements_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 162, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "plusElement",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.plusElement(element_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 163, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "random",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.random()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 164, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Collection<T>",
            functionName = "random",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "random", type = "KRandom"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Collection<*>>).value.map { it as RuntimeValue }
                val random_ = (args[0] as KotlinValueHolder<*>).value as KRandom
        
                val result = unwrappedReceiver.random(random_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 165, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "randomOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.randomOrNull()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 166, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableCollection<T>",
            functionName = "remove",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableCollection<RuntimeValue>
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.remove(element_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 167, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableCollection<T>",
            functionName = "removeAll",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Collection<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableCollection<RuntimeValue>
                val elements_ = (args[0] as KotlinValueHolder<Collection<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.removeAll(elements_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 168, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "removeAll",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.removeAll(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 169, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "removeAt",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
                val index_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.removeAt(index_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 170, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "removeFirst",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
        
                val result = unwrappedReceiver.removeFirst()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 171, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "removeFirstOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
        
                val result = unwrappedReceiver.removeFirstOrNull()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 172, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "removeLast",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
        
                val result = unwrappedReceiver.removeLast()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 173, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "removeLastOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
        
                val result = unwrappedReceiver.removeLastOrNull()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 174, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableCollection<T>",
            functionName = "retainAll",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Collection<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableCollection<RuntimeValue>
                val elements_ = (args[0] as KotlinValueHolder<Collection<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.retainAll(elements_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 175, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "retainAll",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.retainAll(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 176, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "reversed",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.reversed()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 177, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "scan",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "initial", type = "R"),
                CustomFunctionParameter(name = "operation", type = "(R, T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val initial_ = args[0] as RuntimeValue
            val operation_ = (args[1] as LambdaValue).let { lambda -> { arg0: RuntimeValue, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.scan(initial_, operation_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 178, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "scanIndexed",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "initial", type = "R"),
                CustomFunctionParameter(name = "operation", type = "(Int, R, T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val initial_ = args[0] as RuntimeValue
            val operation_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue, arg2: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
                    val wa2 = arg2?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1, wa2))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.scanIndexed(initial_, operation_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 179, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "set",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
                val index_ = (args[0] as IntValue).value
            val element_ = args[1] as RuntimeValue
        
                val result = unwrappedReceiver.set(index_, element_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 180, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "shuffle",
            returnType = "Unit",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
        
                val result = unwrappedReceiver.shuffle()
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 181, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "shuffled",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.shuffled()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 182, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "single",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.single()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 183, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "single",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.single(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 184, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "singleOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.singleOrNull()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 185, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "singleOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.singleOrNull(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 186, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "sort",
            returnType = "Unit",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<ComparableRuntimeValue<Comparable<Any>, Any>>
        
                val result = unwrappedReceiver.sort()
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 188, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "sortBy",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as? ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.sortBy(selector_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 189, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "sortByDescending",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<RuntimeValue>
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as? ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.sortByDescending(selector_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 190, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableList<T>",
            functionName = "sortDescending",
            returnType = "Unit",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableList<ComparableRuntimeValue<Comparable<Any>, Any>>
        
                val result = unwrappedReceiver.sortDescending()
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 191, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "sorted",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.sorted()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 192, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "sortedBy",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as? ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.sortedBy(selector_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 193, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "sortedByDescending",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as? ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.sortedByDescending(selector_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 194, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "sortedDescending",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.sortedDescending()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 195, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "subList",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "fromIndex", type = "Int"),
                CustomFunctionParameter(name = "toIndex", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val fromIndex_ = (args[0] as IntValue).value
            val toIndex_ = (args[1] as IntValue).value
        
                val result = unwrappedReceiver.subList(fromIndex_, toIndex_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 196, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "take",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.take(n_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 200, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "takeLast",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.takeLast(n_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 201, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "List<T>",
            functionName = "takeLastWhile",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.takeLastWhile(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 202, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "takeWhile",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.takeWhile(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 203, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "toList",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.toList()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 204, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "toMutableList",
            returnType = "MutableList<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.toMutableList()
                result?.toMutableList()?.let { MutableListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = MutableList<T>; t.name = MutableList; t = MutableList<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 205, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<Pair<T, R>>",
            functionName = "unzip",
            returnType = "Pair<List<T>, List<R>>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { (it as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue> }
        
                val result = unwrappedReceiver.unzip()
                result.let { ListValue(it.first, typeArgs["T"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) to ListValue(it.second, typeArgs["R"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) }?.let { PairValue(it, ObjectType(ListClass.clazz, listOf<DataType>(typeArgs["T"]!!.copyOf(isNullable = false)), superTypes = emptyList()), ObjectType(ListClass.clazz, listOf<DataType>(typeArgs["R"]!!.copyOf(isNullable = false)), superTypes = emptyList()) /* _t = Pair<List<T>, List<R>>; t.name = Pair; t = Pair<List<T>, List<R>> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 206, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "windowed",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "size", type = "Int"),
                CustomFunctionParameter(name = "step", type = "Int", defaultValueExpression = "1"),
                CustomFunctionParameter(name = "partialWindows", type = "Boolean", defaultValueExpression = "false"),
                CustomFunctionParameter(name = "transform", type = "(List<T>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val size_ = (args[0] as IntValue).value
            val step_ = (args[1] as IntValue).value
            val partialWindows_ = (args[2] as BooleanValue).value
            val transform_ = (args[3] as LambdaValue).let { lambda -> { arg0: List<RuntimeValue> ->
                    val wa0 = arg0?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.windowed(size_, step_, partialWindows_, transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 212, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "zip",
            returnType = "List<Pair<T, R>>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "Iterable<R>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val other_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.zip(other_)
                result?.map { PairValue(it, typeArgs["T"]!!.copyOf(isNullable = false), typeArgs["R"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, ObjectType(PairClass.clazz, listOf<DataType>(typeArgs["T"]!!.copyOf(isNullable = false), typeArgs["R"]!!.copyOf(isNullable = false)), superTypes = emptyList()) /* _t = List<Pair<T, R>>; t.name = List; t = List<Pair<T, R>> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 218, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "zip",
            returnType = "List<V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "Iterable<R>"),
                CustomFunctionParameter(name = "transform", type = "(T, R) -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val other_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
            val transform_ = (args[1] as LambdaValue).let { lambda -> { arg0: RuntimeValue, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.zip(other_, transform_)
                result?.let { ListValue(it, typeArgs["V"]!!.copyOf(isNullable = false) /* _t = List<V>; t.name = List; t = List<V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 221, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "mapOf",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "pairs", type = "Pair<K, V>", modifiers = setOf("vararg")),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val pairs_ = (args[0] as KotlinValueHolder<List<RuntimeValue>>).value.map { (it as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue> }
        
                val result = mapOf(*pairs_.toTypedArray())
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 241, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "mutableMapOf",
            returnType = "MutableMap<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "pairs", type = "Pair<K, V>", modifiers = setOf("vararg")),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val pairs_ = (args[0] as KotlinValueHolder<List<RuntimeValue>>).value.map { (it as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue> }
        
                val result = mutableMapOf(*pairs_.toTypedArray())
                result?.let { MutableMapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MutableMap<K, V>; t.name = MutableMap; t = MutableMap<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 242, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "contains",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val key_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.contains(key_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 244, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, *>",
            functionName = "containsKey",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val key_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.containsKey(key_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 245, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "containsValue",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "value", type = "V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val value_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.containsValue(value_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 246, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "iterator",
            returnType = "Iterator<MapEntry<K, V>>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.iterator()
                result.let { it.wrap(typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) }?.let { IteratorValue(it, ObjectType(MapEntryClass.clazz, listOf<DataType>(typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false)), superTypes = emptyList()) /* _t = Iterator<MapEntry<K, V>>; t.name = Iterator; t = Iterator<MapEntry<K, V>> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 248, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "all",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(MapEntry<K, V>) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.all(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 250, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "any",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.any()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 254, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "any",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(MapEntry<K, V>) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.any(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 255, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "associate",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> Pair<K, V>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue>
                } }
        
                val result = unwrappedReceiver.associate(transform_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 261, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "associateBy",
            returnType = "Map<K, T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "keySelector", type = "(T) -> K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "K", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val keySelector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.associateBy(keySelector_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Map<K, T>; t.name = Map; t = Map<K, T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 265, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<K>",
            functionName = "associateBy",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "valueSelector", type = "(K) -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val valueSelector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.associateBy(valueSelector_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 269, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<K>",
            functionName = "associateWith",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "valueSelector", type = "(K) -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val valueSelector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.associateWith(valueSelector_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 273, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "clear",
            returnType = "Unit",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.clear()
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 277, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "count",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.count()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 278, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "count",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(MapEntry<K, V>) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.count(predicate_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 279, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "filter",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(MapEntry<K, V>) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filter(predicate_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 281, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "filterKeys",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(K) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filterKeys(predicate_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 282, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "filterNot",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(MapEntry<K, V>) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filterNot(predicate_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 283, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "filterValues",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(V) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filterValues(predicate_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 284, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "firstNotNullOf",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(MapEntry<K, V>) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue?, RuntimeValue?>
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue?, RuntimeValue?> ->
                    val wa0 = arg0?.toRuntimeValue()?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as RuntimeValue).toNullable()
                } }
        
                val result = unwrappedReceiver.firstNotNullOf(transform_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 285, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "firstNotNullOfOrNull",
            returnType = "R?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(MapEntry<K, V>) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue?, RuntimeValue?>
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue?, RuntimeValue?> ->
                    val wa0 = arg0?.toRuntimeValue()?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as RuntimeValue).toNullable()
                } }
        
                val result = unwrappedReceiver.firstNotNullOfOrNull(transform_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 288, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "flatMap",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(MapEntry<K, V>) -> Iterable<R>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                } }
        
                val result = unwrappedReceiver.flatMap(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 291, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "forEach",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(MapEntry<K, V>) -> Unit"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.inline),
            inlineFunctionBody = "{\n    for (entry in this) {\n        action(entry)\n    }\n}",
            inlineFunctionBodyFormat = FunctionBodyFormat.Block,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    Unit
                } }
        
                val result = unwrappedReceiver.forEach(action_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 294, col = 8),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "get",
            returnType = "V?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val key_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.get(key_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 299, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "getOrElse",
            returnType = "V",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K"),
                CustomFunctionParameter(name = "defaultValue", type = "() -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val key_ = args[0] as RuntimeValue
            val defaultValue_ = (args[1] as LambdaValue).let { lambda -> {  
        
        
                    val result = lambda.execute(arrayOf())
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.getOrElse(key_, defaultValue_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 300, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "getOrPut",
            returnType = "V",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K"),
                CustomFunctionParameter(name = "defaultValue", type = "() -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
                val key_ = args[0] as RuntimeValue
            val defaultValue_ = (args[1] as LambdaValue).let { lambda -> {  
        
        
                    val result = lambda.execute(arrayOf())
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.getOrPut(key_, defaultValue_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 301, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "getValue",
            returnType = "V",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val key_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.getValue(key_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 302, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "groupBy",
            returnType = "Map<K, List<T>>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "keySelector", type = "(T) -> K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "K", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val keySelector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.groupBy(keySelector_)
                result?.mapValues { ListValue(it.value, typeArgs["T"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) }?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), ObjectType(ListClass.clazz, listOf<DataType>(typeArgs["T"]!!.copyOf(isNullable = false)), superTypes = emptyList()) /* _t = Map<K, List<T>>; t.name = Map; t = Map<K, List<T>> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 303, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "groupBy",
            returnType = "Map<K, List<V>>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "keySelector", type = "(T) -> K"),
                CustomFunctionParameter(name = "valueSelector", type = "(T) -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val keySelector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
            val valueSelector_ = (args[1] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.groupBy(keySelector_, valueSelector_)
                result?.mapValues { ListValue(it.value, typeArgs["V"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) }?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), ObjectType(ListClass.clazz, listOf<DataType>(typeArgs["V"]!!.copyOf(isNullable = false)), superTypes = emptyList()) /* _t = Map<K, List<V>>; t.name = Map; t = Map<K, List<V>> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 306, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "isNotEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.isNotEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 310, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>?",
            functionName = "isNullOrEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as? KotlinValueHolder<*>)?.value as Map<RuntimeValue, RuntimeValue>?
        
                val result = unwrappedReceiver.isNullOrEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 311, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "map",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(MapEntry<K, V>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.inline),
            inlineFunctionBody = "{\n    val result = mutableListOf<R>()\n    for (entry in this) {\n        result.add(transform(entry))\n    }\n    return result\n}",
            inlineFunctionBodyFormat = FunctionBodyFormat.Block,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.map(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 312, col = 8),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "mapKeys",
            returnType = "Map<R, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(MapEntry<K, V>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.mapKeys(transform_)
                result?.let { MapValue(it, typeArgs["R"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<R, V>; t.name = Map; t = Map<R, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 319, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "mapNotNull",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(MapEntry<K, V>) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue?, RuntimeValue?>
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue?, RuntimeValue?> ->
                    val wa0 = arg0?.toRuntimeValue()?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as RuntimeValue).toNullable()
                } }
        
                val result = unwrappedReceiver.mapNotNull(transform_)
                result?.map { it.toRuntimeValue() }?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 320, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "mapValues",
            returnType = "Map<K, R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(MapEntry<K, V>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.mapValues(transform_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["R"]!!.copyOf(isNullable = false) /* _t = Map<K, R>; t.name = Map; t = Map<K, R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 321, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "maxBy",
            returnType = "MapEntry<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(MapEntry<K, V>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxBy(selector_)
                result?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 322, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "maxByOrNull",
            returnType = "MapEntry<K, V>?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(MapEntry<K, V>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxByOrNull(selector_)
                result?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>?; t.name = MapEntry; t = MapEntry<K, V>? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 323, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "maxOf",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(MapEntry<K, V>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxOf(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 324, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "maxOfOrNull",
            returnType = "R?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(MapEntry<K, V>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxOfOrNull(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 325, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "minBy",
            returnType = "MapEntry<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(MapEntry<K, V>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minBy(selector_)
                result?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 326, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "minByOrNull",
            returnType = "MapEntry<K, V>?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(MapEntry<K, V>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minByOrNull(selector_)
                result?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>?; t.name = MapEntry; t = MapEntry<K, V>? */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 327, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "minOf",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(MapEntry<K, V>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minOf(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 328, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "minOfOrNull",
            returnType = "R?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(MapEntry<K, V>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minOfOrNull(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 329, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "minus",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val key_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.minus(key_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 330, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "minus",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "keys", type = "List<K>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val keys_ = (args[0] as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.minus(keys_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 331, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "minusAssign",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
                val key_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.minusAssign(key_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 332, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "minusAssign",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "keys", type = "List<K>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
                val keys_ = (args[0] as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.minusAssign(keys_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 333, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "none",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.none()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 334, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "none",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(MapEntry<K, V>) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.none(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 335, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "M",
            functionName = "onEach",
            returnType = "M",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(MapEntry<K, V>) -> Unit"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
                TypeParameter(name = "M", typeUpperBound = "Map<K, V>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    Unit
                } }
        
                val result = unwrappedReceiver.onEach(action_)
                result?.let { DelegatedValue<Map<RuntimeValue, RuntimeValue>>(it, (receiver.type() as ObjectType).clazz, listOf<DataType>(typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = M; t.name = Map; t = Map<K, V> */), symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 336, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "onEachIndexed",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(Int, MapEntry<K, V>) -> Unit"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    Unit
                } }
        
                val result = unwrappedReceiver.onEachIndexed(action_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 337, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "onEachIndexed",
            returnType = "MutableMap<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(Int, MapEntry<K, V>) -> Unit"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: MapEntry<RuntimeValue, RuntimeValue> ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { MapEntryValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MapEntry<K, V>; t.name = MapEntry; t = MapEntry<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    Unit
                } }
        
                val result = unwrappedReceiver.onEachIndexed(action_)
                result?.let { MutableMapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MutableMap<K, V>; t.name = MutableMap; t = MutableMap<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 338, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>?",
            functionName = "orEmpty",
            returnType = "Map<K, V>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as? KotlinValueHolder<*>)?.value as Map<RuntimeValue, RuntimeValue>?
        
                val result = unwrappedReceiver.orEmpty()
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 339, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "plus",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "pair", type = "Pair<K, V>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val pair_ = (args[0] as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.plus(pair_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 340, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "plus",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "pairs", type = "List<Pair<K, V>>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val pairs_ = (args[0] as KotlinValueHolder<List<*>>).value.map { (it as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue> }
        
                val result = unwrappedReceiver.plus(pairs_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 341, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "plusAssign",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "pair", type = "Pair<K, V>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
                val pair_ = (args[0] as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.plusAssign(pair_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 342, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "plusAssign",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "pairs", type = "List<Pair<K, V>>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
                val pairs_ = (args[0] as KotlinValueHolder<List<*>>).value.map { (it as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue> }
        
                val result = unwrappedReceiver.plusAssign(pairs_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 343, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "put",
            returnType = "V?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K"),
                CustomFunctionParameter(name = "value", type = "V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
                val key_ = args[0] as RuntimeValue
            val value_ = args[1] as RuntimeValue
        
                val result = unwrappedReceiver.put(key_, value_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 344, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "putAll",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "pairs", type = "List<Pair<K, V>>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
                val pairs_ = (args[0] as KotlinValueHolder<List<*>>).value.map { (it as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue> }
        
                val result = unwrappedReceiver.putAll(pairs_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 345, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "remove",
            returnType = "V?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
                val key_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.remove(key_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 346, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "set",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "key", type = "K"),
                CustomFunctionParameter(name = "value", type = "V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
                val key_ = args[0] as RuntimeValue
            val value_ = args[1] as RuntimeValue
        
                val result = unwrappedReceiver.set(key_, value_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 347, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "toList",
            returnType = "List<Pair<K, V>>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.toList()
                result?.map { PairValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, ObjectType(PairClass.clazz, listOf<DataType>(typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false)), superTypes = emptyList()) /* _t = List<Pair<K, V>>; t.name = List; t = List<Pair<K, V>> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 348, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<Pair<K, V>>",
            functionName = "toMap",
            returnType = "Map<K, V>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { (it as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue> }
        
                val result = unwrappedReceiver.toMap()
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 349, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "toMap",
            returnType = "Map<K, V>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.toMap()
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 350, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "toMutableMap",
            returnType = "MutableMap<K, V>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
        
                val result = unwrappedReceiver.toMutableMap()
                result?.let { MutableMapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MutableMap<K, V>; t.name = MutableMap; t = MutableMap<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 351, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Map<K, V>",
            functionName = "withDefault",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "defaultValue", type = "(K) -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Map<RuntimeValue, RuntimeValue>
                val defaultValue_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.withDefault(defaultValue_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 352, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableMap<K, V>",
            functionName = "withDefault",
            returnType = "MutableMap<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "defaultValue", type = "(K) -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableMap<RuntimeValue, RuntimeValue>
                val defaultValue_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.withDefault(defaultValue_)
                result?.let { MutableMapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = MutableMap<K, V>; t.name = MutableMap; t = MutableMap<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 353, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Set<T>",
            functionName = "contains",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Set<RuntimeValue>
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.contains(element_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 361, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Set<T>",
            functionName = "containsAll",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Collection<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Set<RuntimeValue>
                val elements_ = (args[0] as KotlinValueHolder<Collection<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.containsAll(elements_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 362, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Set<T>",
            functionName = "isEmpty",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Set<RuntimeValue>
        
                val result = unwrappedReceiver.isEmpty()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 363, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Set<T>",
            functionName = "iterator",
            returnType = "Iterator<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Set<RuntimeValue>
        
                val result = unwrappedReceiver.iterator()
                result?.let { IteratorValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Iterator<T>; t.name = Iterator; t = Iterator<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 364, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "intersect",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "Iterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val other_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.intersect(other_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 365, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Set<T>",
            functionName = "minus",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Set<RuntimeValue>
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.minus(element_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 368, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Set<T>",
            functionName = "minus",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Iterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Set<RuntimeValue>
                val elements_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.minus(elements_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 369, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Set<T>",
            functionName = "minusElement",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Set<RuntimeValue>
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.minusElement(element_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 370, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Set<T>?",
            functionName = "orEmpty",
            returnType = "Set<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as? KotlinValueHolder<*>)?.value as Set<RuntimeValue>?
        
                val result = unwrappedReceiver.orEmpty()
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 371, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Set<T>",
            functionName = "plus",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Set<RuntimeValue>
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.plus(element_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 372, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Set<T>",
            functionName = "plus",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Iterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Set<RuntimeValue>
                val elements_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.plus(elements_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 373, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "Set<T>",
            functionName = "plusElement",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as Set<RuntimeValue>
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.plusElement(element_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 374, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "subtract",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "Iterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val other_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.subtract(other_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 375, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "toMutableSet",
            returnType = "MutableSet<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.toMutableSet()
                result?.toMutableSet()?.let { MutableSetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = MutableSet<T>; t.name = MutableSet; t = MutableSet<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 376, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "toSet",
            returnType = "Set<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.toSet()
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 377, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "Iterable<T>",
            functionName = "union",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "Iterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                val other_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.union(other_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 378, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableSet<T>",
            functionName = "add",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableSet<RuntimeValue>
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.add(element_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 380, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableSet<T>",
            functionName = "addAll",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Collection<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableSet<RuntimeValue>
                val elements_ = (args[0] as KotlinValueHolder<Collection<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.addAll(elements_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 381, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableSet<T>",
            functionName = "clear",
            returnType = "Unit",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableSet<RuntimeValue>
        
                val result = unwrappedReceiver.clear()
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 382, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableSet<T>",
            functionName = "remove",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableSet<RuntimeValue>
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.remove(element_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 383, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableSet<T>",
            functionName = "removeAll",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Collection<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableSet<RuntimeValue>
                val elements_ = (args[0] as KotlinValueHolder<Collection<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.removeAll(elements_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 384, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "MutableSet<T>",
            functionName = "retainAll",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "Collection<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as MutableSet<RuntimeValue>
                val elements_ = (args[0] as KotlinValueHolder<Collection<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.retainAll(elements_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 385, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "mutableSetOf",
            returnType = "MutableSet<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "T", modifiers = setOf("vararg")),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val elements_ = (args[0] as KotlinValueHolder<List<RuntimeValue>>).value.map { it as RuntimeValue }
        
                val result = mutableSetOf(*elements_.toTypedArray())
                result?.toMutableSet()?.let { MutableSetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = MutableSet<T>; t.name = MutableSet; t = MutableSet<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 388, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "setOf",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "T", modifiers = setOf("vararg")),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val elements_ = (args[0] as KotlinValueHolder<List<RuntimeValue>>).value.map { it as RuntimeValue }
        
                val result = setOf(*elements_.toTypedArray())
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 390, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = null,
            functionName = "setOfNotNull",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "T?", modifiers = setOf("vararg")),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
        
                val elements_ = (args[0] as KotlinValueHolder<List<RuntimeValue>>).value.map { (it as RuntimeValue).toNullable() }
        
                val result = setOfNotNull(*elements_.toTypedArray())
                result?.map { it.toRuntimeValue() }?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 391, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "all",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.all(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 396, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "any",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.any(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 397, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "chunked",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "size", type = "Int"),
                CustomFunctionParameter(name = "transform", type = "(List<T>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val size_ = (args[0] as IntValue).value
            val transform_ = (args[1] as LambdaValue).let { lambda -> { arg0: List<RuntimeValue> ->
                    val wa0 = arg0?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.chunked(size_, transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 399, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "contains",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.contains(element_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 400, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "count",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.count(predicate_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 401, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "count",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.count()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 402, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "distinct",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.distinct()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 403, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "distinctBy",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "K", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.distinctBy(selector_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 404, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "drop",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.drop(n_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 405, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "dropWhile",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.dropWhile(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 406, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "elementAt",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val index_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.elementAt(index_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 407, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "elementAtOrElse",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
                CustomFunctionParameter(name = "defaultValue", type = "(Int) -> T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val index_ = (args[0] as IntValue).value
            val defaultValue_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.elementAtOrElse(index_, defaultValue_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 408, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "elementAtOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "index", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val index_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.elementAtOrNull(index_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 409, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "filter",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filter(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 410, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "filterIndexed",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(Int, T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filterIndexed(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 411, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "filterNot",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.filterNot(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 412, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "find",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.find(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 413, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "findLast",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.findLast(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 414, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "first",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.first()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 415, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "first",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.first(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 416, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "firstNotNullOf",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { (it as RuntimeValue).toNullable() }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue? ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as RuntimeValue).toNullable()
                } }
        
                val result = unwrappedReceiver.firstNotNullOf(transform_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 417, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "firstNotNullOfOrNull",
            returnType = "R?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { (it as RuntimeValue).toNullable() }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue? ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as RuntimeValue).toNullable()
                } }
        
                val result = unwrappedReceiver.firstNotNullOfOrNull(transform_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 420, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "firstOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.firstOrNull()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 423, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "firstOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.firstOrNull(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 424, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "flatMap",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> Iterable<R>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                } }
        
                val result = unwrappedReceiver.flatMap(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 425, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "flatMapIndexed",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(Int, T) -> Iterable<R>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    (result as KotlinValueHolder<Iterable<*>>).value.map { it as RuntimeValue }
                } }
        
                val result = unwrappedReceiver.flatMapIndexed(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 428, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "fold",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "initial", type = "R"),
                CustomFunctionParameter(name = "operation", type = "(R, T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val initial_ = args[0] as RuntimeValue
            val operation_ = (args[1] as LambdaValue).let { lambda -> { arg0: RuntimeValue, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.fold(initial_, operation_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 431, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "foldIndexed",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "initial", type = "R"),
                CustomFunctionParameter(name = "operation", type = "(Int, R, T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val initial_ = args[0] as RuntimeValue
            val operation_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue, arg2: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
                    val wa2 = arg2?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1, wa2))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.foldIndexed(initial_, operation_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 435, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "forEach",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(T) -> Unit"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.inline),
            inlineFunctionBody = "{\n    for (element in this) {\n        action(element)\n    }\n}",
            inlineFunctionBodyFormat = FunctionBodyFormat.Block,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    Unit
                } }
        
                val result = unwrappedReceiver.forEach(action_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 439, col = 8),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "forEachIndexed",
            returnType = "Unit",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "action", type = "(Int, T) -> Unit"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val action_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    Unit
                } }
        
                val result = unwrappedReceiver.forEachIndexed(action_)
                UnitValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 444, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "indexOf",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.indexOf(element_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 445, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "indexOfFirst",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.indexOfFirst(predicate_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 446, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "indexOfLast",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.indexOfLast(predicate_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 447, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "joinToString",
            returnType = "String",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "separator", type = "String", defaultValueExpression = "\", \""),
                CustomFunctionParameter(name = "prefix", type = "String", defaultValueExpression = "\"\""),
                CustomFunctionParameter(name = "postfix", type = "String", defaultValueExpression = "\"\""),
                CustomFunctionParameter(name = "limit", type = "Int", defaultValueExpression = "-(1)"),
                CustomFunctionParameter(name = "truncated", type = "String", defaultValueExpression = "\"...\""),
                CustomFunctionParameter(name = "transform", type = "((T) -> String)?", defaultValueExpression = "null"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val separator_ = (args[0] as StringValue).value
            val prefix_ = (args[1] as StringValue).value
            val postfix_ = (args[2] as StringValue).value
            val limit_ = (args[3] as IntValue).value
            val truncated_ = (args[4] as StringValue).value
            val transform_ = (args[5] as? LambdaValue)?.let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as StringValue).value
                } }
        
                val result = unwrappedReceiver.joinToString(separator_, prefix_, postfix_, limit_, truncated_, transform_)
                result?.let { StringValue(it /* _t = String; t.name = String; t = String */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 448, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "last",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.last()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 456, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "last",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.last(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 457, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "lastIndexOf",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.lastIndexOf(element_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 458, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "lastOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.lastOrNull()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 459, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "lastOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.lastOrNull(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 460, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "map",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.inline),
            inlineFunctionBody = "{\n    val result = mutableListOf<R>()\n    for (element in this) {\n        result.add(transform(element))\n    }\n    return result\n}",
            inlineFunctionBodyFormat = FunctionBodyFormat.Block,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.map(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 461, col = 8),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "mapIndexed",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(Int, T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.mapIndexed(transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 468, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "mapIndexedNotNull",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(Int, T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { (it as RuntimeValue).toNullable() }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue? ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    (result as RuntimeValue).toNullable()
                } }
        
                val result = unwrappedReceiver.mapIndexedNotNull(transform_)
                result?.map { it.toRuntimeValue() }?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 469, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "mapNotNull",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Any"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { (it as RuntimeValue).toNullable() }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue? ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as RuntimeValue).toNullable()
                } }
        
                val result = unwrappedReceiver.mapNotNull(transform_)
                result?.map { it.toRuntimeValue() }?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 470, col = 11),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "max",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.max()
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 471, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "maxBy",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxBy(selector_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 472, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "maxByOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxByOrNull(selector_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 473, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "maxOf",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxOf(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 474, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "maxOfOrNull",
            returnType = "R?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.maxOfOrNull(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 475, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "maxOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.maxOrNull()
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 476, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "min",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.min()
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 477, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "minBy",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minBy(selector_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 478, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "minByOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minByOrNull(selector_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 479, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "minOf",
            returnType = "R",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minOf(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 480, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "minOfOrNull",
            returnType = "R?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.minOfOrNull(selector_)
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 481, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "minOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.minOrNull()
                result ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 482, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "minus",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.minus(element_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 483, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "minus",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "PrimitiveIterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val elements_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.minus(elements_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 484, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "minusElement",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.minusElement(element_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 485, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "none",
            returnType = "Boolean",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.none(predicate_)
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 486, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "none",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.none()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 487, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "partition",
            returnType = "Pair<List<T>, List<T>>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.partition(predicate_)
                result.let { ListValue(it.first, typeArgs["T"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) to ListValue(it.second, typeArgs["T"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) }?.let { PairValue(it, ObjectType(ListClass.clazz, listOf<DataType>(typeArgs["T"]!!.copyOf(isNullable = false)), superTypes = emptyList()), ObjectType(ListClass.clazz, listOf<DataType>(typeArgs["T"]!!.copyOf(isNullable = false)), superTypes = emptyList()) /* _t = Pair<List<T>, List<T>>; t.name = Pair; t = Pair<List<T>, List<T>> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 488, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "plus",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.plus(element_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 489, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "plus",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "elements", type = "List<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.operator),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val elements_ = (args[0] as KotlinValueHolder<List<*>>).value.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.plus(elements_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 490, col = 10),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "plusElement",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "element", type = "T"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val element_ = args[0] as RuntimeValue
        
                val result = unwrappedReceiver.plusElement(element_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 491, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "reversed",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.reversed()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 492, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "scan",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "initial", type = "R"),
                CustomFunctionParameter(name = "operation", type = "(R, T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val initial_ = args[0] as RuntimeValue
            val operation_ = (args[1] as LambdaValue).let { lambda -> { arg0: RuntimeValue, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.scan(initial_, operation_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 493, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "scanIndexed",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "initial", type = "R"),
                CustomFunctionParameter(name = "operation", type = "(Int, R, T) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val initial_ = args[0] as RuntimeValue
            val operation_ = (args[1] as LambdaValue).let { lambda -> { arg0: Int, arg1: RuntimeValue, arg2: RuntimeValue ->
                    val wa0 = arg0?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
                    val wa2 = arg2?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1, wa2))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.scanIndexed(initial_, operation_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 494, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "shuffled",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.shuffled()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 495, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "single",
            returnType = "T",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.single()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 496, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "single",
            returnType = "T",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.single(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 497, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "singleOrNull",
            returnType = "T?",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.singleOrNull()
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 498, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "singleOrNull",
            returnType = "T?",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.singleOrNull(predicate_)
                result?.let { it as RuntimeValue } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 499, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "sorted",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.sorted()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 500, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "sortedBy",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as? ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.sortedBy(selector_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 501, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "sortedByDescending",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "selector", type = "(T) -> R?"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = "Comparable<R>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val selector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as? ComparableRuntimeValue<Comparable<Any>, Any>
                } }
        
                val result = unwrappedReceiver.sortedByDescending(selector_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 502, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "sortedDescending",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = "Comparable<T>"),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as ComparableRuntimeValue<Comparable<Any>, Any> }
        
                val result = unwrappedReceiver.sortedDescending()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 503, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "take",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "n", type = "Int"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val n_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.take(n_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 504, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "takeWhile",
            returnType = "List<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "predicate", type = "(T) -> Boolean"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val predicate_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as BooleanValue).value
                } }
        
                val result = unwrappedReceiver.takeWhile(predicate_)
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 505, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "toList",
            returnType = "List<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.toList()
                result?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 506, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "toMutableList",
            returnType = "MutableList<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.toMutableList()
                result?.toMutableList()?.let { MutableListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = MutableList<T>; t.name = MutableList; t = MutableList<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 507, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "windowed",
            returnType = "List<R>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "size", type = "Int"),
                CustomFunctionParameter(name = "step", type = "Int", defaultValueExpression = "1"),
                CustomFunctionParameter(name = "partialWindows", type = "Boolean", defaultValueExpression = "false"),
                CustomFunctionParameter(name = "transform", type = "(List<T>) -> R"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val size_ = (args[0] as IntValue).value
            val step_ = (args[1] as IntValue).value
            val partialWindows_ = (args[2] as BooleanValue).value
            val transform_ = (args[3] as LambdaValue).let { lambda -> { arg0: List<RuntimeValue> ->
                    val wa0 = arg0?.let { ListValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = List<T>; t.name = List; t = List<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.windowed(size_, step_, partialWindows_, transform_)
                result?.let { ListValue(it, typeArgs["R"]!!.copyOf(isNullable = false) /* _t = List<R>; t.name = List; t = List<R> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 513, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "zip",
            returnType = "List<Pair<T, R>>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "PrimitiveIterable<R>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val other_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.zip(other_)
                result?.map { PairValue(it, typeArgs["T"]!!.copyOf(isNullable = false), typeArgs["R"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) }?.let { ListValue(it, ObjectType(PairClass.clazz, listOf<DataType>(typeArgs["T"]!!.copyOf(isNullable = false), typeArgs["R"]!!.copyOf(isNullable = false)), superTypes = emptyList()) /* _t = List<Pair<T, R>>; t.name = List; t = List<Pair<T, R>> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 519, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "zip",
            returnType = "List<V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "PrimitiveIterable<R>"),
                CustomFunctionParameter(name = "transform", type = "(T, R) -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "R", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val other_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
            val transform_ = (args[1] as LambdaValue).let { lambda -> { arg0: RuntimeValue, arg1: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
                    val wa1 = arg1?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0, wa1))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.zip(other_, transform_)
                result?.let { ListValue(it, typeArgs["V"]!!.copyOf(isNullable = false) /* _t = List<V>; t.name = List; t = List<V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 522, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "associate",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "transform", type = "(T) -> Pair<K, V>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val transform_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    (result as KotlinValueHolder<*>).value as Pair<RuntimeValue, RuntimeValue>
                } }
        
                val result = unwrappedReceiver.associate(transform_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 526, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "associateBy",
            returnType = "Map<K, T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "keySelector", type = "(T) -> K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "K", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val keySelector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.associateBy(keySelector_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Map<K, T>; t.name = Map; t = Map<K, T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 529, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<K>",
            functionName = "associateBy",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "valueSelector", type = "(K) -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val valueSelector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.associateBy(valueSelector_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 533, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<K>",
            functionName = "associateWith",
            returnType = "Map<K, V>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "valueSelector", type = "(K) -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val valueSelector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.associateWith(valueSelector_)
                result?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), typeArgs["V"]!!.copyOf(isNullable = false) /* _t = Map<K, V>; t.name = Map; t = Map<K, V> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 537, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "groupBy",
            returnType = "Map<K, List<T>>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "keySelector", type = "(T) -> K"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "K", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val keySelector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.groupBy(keySelector_)
                result?.mapValues { ListValue(it.value, typeArgs["T"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) }?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), ObjectType(ListClass.clazz, listOf<DataType>(typeArgs["T"]!!.copyOf(isNullable = false)), superTypes = emptyList()) /* _t = Map<K, List<T>>; t.name = Map; t = Map<K, List<T>> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 540, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "groupBy",
            returnType = "Map<K, List<V>>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "keySelector", type = "(T) -> K"),
                CustomFunctionParameter(name = "valueSelector", type = "(T) -> V"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
                TypeParameter(name = "K", typeUpperBound = null),
                TypeParameter(name = "V", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val keySelector_ = (args[0] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
            val valueSelector_ = (args[1] as LambdaValue).let { lambda -> { arg0: RuntimeValue ->
                    val wa0 = arg0?.let { it as RuntimeValue } ?: NullValue
        
                    val result = lambda.execute(arrayOf(wa0))
                    result as RuntimeValue
                } }
        
                val result = unwrappedReceiver.groupBy(keySelector_, valueSelector_)
                result?.mapValues { ListValue(it.value, typeArgs["V"]!!.copyOf(isNullable = false), symbolTable = interpreter.symbolTable()) }?.let { MapValue(it, typeArgs["K"]!!.copyOf(isNullable = false), ObjectType(ListClass.clazz, listOf<DataType>(typeArgs["V"]!!.copyOf(isNullable = false)), superTypes = emptyList()) /* _t = Map<K, List<V>>; t.name = Map; t = Map<K, List<V>> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 543, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "intersect",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "PrimitiveIterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val other_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.intersect(other_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 547, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "subtract",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "PrimitiveIterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val other_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.subtract(other_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 550, col = 7),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "toMutableSet",
            returnType = "MutableSet<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.toMutableSet()
                result?.toMutableSet()?.let { MutableSetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = MutableSet<T>; t.name = MutableSet; t = MutableSet<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 551, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "toSet",
            returnType = "Set<T>",
            parameterTypes = listOf(),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.toSet()
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 552, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "PrimitiveIterable<T>",
            functionName = "union",
            returnType = "Set<T>",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "other", type = "PrimitiveIterable<T>"),
            ),
            typeParameters = listOf(
                TypeParameter(name = "T", typeUpperBound = null),
            ),
            modifiers = setOf<FunctionModifier>(FunctionModifier.infix),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
                val other_ = (args[0] as KotlinValueHolder<Iterable<*>>).value.map { wrapPrimitiveValueAsRuntimeValue(it, typeArgs["T"]!!, interpreter.symbolTable()) }.map { it as RuntimeValue }
        
                val result = unwrappedReceiver.union(other_)
                result?.toSet()?.let { SetValue(it, typeArgs["T"]!!.copyOf(isNullable = false) /* _t = Set<T>; t.name = Set; t = Set<T> */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Collections", lineNum = 553, col = 7),
        ),

    )
}
