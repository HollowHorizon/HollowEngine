
/** Generated code. DO NOT MODIFY! Changes to this file will be overwritten. **/

package com.sunnychung.lib.multiplatform.kotlite.stdlib

import com.sunnychung.lib.multiplatform.kotlite.model.AnyType
import com.sunnychung.lib.multiplatform.kotlite.model.BooleanValue
import com.sunnychung.lib.multiplatform.kotlite.model.ByteValue
import com.sunnychung.lib.multiplatform.kotlite.model.ComparableRuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.CustomFunctionParameter
import com.sunnychung.lib.multiplatform.kotlite.model.CharValue
import com.sunnychung.lib.multiplatform.kotlite.model.DataType
import com.sunnychung.lib.multiplatform.kotlite.model.DelegatedValue
import com.sunnychung.lib.multiplatform.kotlite.model.DoubleValue
import com.sunnychung.lib.multiplatform.kotlite.model.ExtensionProperty
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionModifier
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionBodyFormat
import com.sunnychung.lib.multiplatform.kotlite.model.FunctionType
import com.sunnychung.lib.multiplatform.kotlite.model.GlobalProperty
import com.sunnychung.lib.multiplatform.kotlite.model.IntValue
import com.sunnychung.lib.multiplatform.kotlite.model.IterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorClass
import com.sunnychung.lib.multiplatform.kotlite.model.IteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.KotlinValueHolder
import com.sunnychung.lib.multiplatform.kotlite.model.LambdaValue
import com.sunnychung.lib.multiplatform.kotlite.model.LibraryModule
import com.sunnychung.lib.multiplatform.kotlite.model.ListClass
import com.sunnychung.lib.multiplatform.kotlite.model.ListValue
import com.sunnychung.lib.multiplatform.kotlite.model.LongValue
import com.sunnychung.lib.multiplatform.kotlite.model.NothingType
import com.sunnychung.lib.multiplatform.kotlite.model.NullValue
import com.sunnychung.lib.multiplatform.kotlite.model.ObjectType
import com.sunnychung.lib.multiplatform.kotlite.model.PairClass
import com.sunnychung.lib.multiplatform.kotlite.model.PairValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIterableValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveIteratorValue
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveType
import com.sunnychung.lib.multiplatform.kotlite.model.PrimitiveTypeName
import com.sunnychung.lib.multiplatform.kotlite.model.ProvidedClassDefinition
import com.sunnychung.lib.multiplatform.kotlite.model.SourcePosition
import com.sunnychung.lib.multiplatform.kotlite.model.StringValue
import com.sunnychung.lib.multiplatform.kotlite.model.FloatValue
import com.sunnychung.lib.multiplatform.kotlite.model.ShortValue
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameter
import com.sunnychung.lib.multiplatform.kotlite.model.TypeParameterType
import com.sunnychung.lib.multiplatform.kotlite.model.RuntimeValue
import com.sunnychung.lib.multiplatform.kotlite.model.UnitType
import com.sunnychung.lib.multiplatform.kotlite.model.UnitValue
import com.sunnychung.lib.multiplatform.kotlite.util.wrapPrimitiveValueAsRuntimeValue

import com.sunnychung.lib.multiplatform.kotlite.stdlib.random.KRandomClass
import com.sunnychung.lib.multiplatform.kotlite.stdlib.random.KRandomValue


typealias KRandom = kotlin.random.Random


abstract class AbstractRandomLibModule : LibraryModule("Random") {
    override val classes = emptyList<ProvidedClassDefinition>()

    override val properties = listOf<ExtensionProperty>(
    )
    
    override val globalProperties = emptyList<GlobalProperty>()
    
    override val functions = listOf<CustomFunctionDefinition>(
        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextBits",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "bitCount", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
                val bitCount_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.nextBits(bitCount_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 1, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextBoolean",
            returnType = "Boolean",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
        
                val result = unwrappedReceiver.nextBoolean()
                result?.let { BooleanValue(it /* _t = Boolean; t.name = Boolean; t = Boolean */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 2, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextDouble",
            returnType = "Double",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
        
                val result = unwrappedReceiver.nextDouble()
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 3, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextDouble",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "until", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
                val until_ = (args[0] as DoubleValue).value
        
                val result = unwrappedReceiver.nextDouble(until_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 4, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextDouble",
            returnType = "Double",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "from", type = "Double"),
                CustomFunctionParameter(name = "until", type = "Double"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
                val from_ = (args[0] as DoubleValue).value
            val until_ = (args[1] as DoubleValue).value
        
                val result = unwrappedReceiver.nextDouble(from_, until_)
                result?.let { DoubleValue(it /* _t = Double; t.name = Double; t = Double */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 5, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextFloat",
            returnType = "Float",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
        
                val result = unwrappedReceiver.nextFloat()
                result?.let { FloatValue(it /* _t = Float; t.name = Float; t = Float */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 6, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextInt",
            returnType = "Int",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
        
                val result = unwrappedReceiver.nextInt()
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 7, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextInt",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "until", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
                val until_ = (args[0] as IntValue).value
        
                val result = unwrappedReceiver.nextInt(until_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 8, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextInt",
            returnType = "Int",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "from", type = "Int"),
                CustomFunctionParameter(name = "until", type = "Int"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
                val from_ = (args[0] as IntValue).value
            val until_ = (args[1] as IntValue).value
        
                val result = unwrappedReceiver.nextInt(from_, until_)
                result?.let { IntValue(it /* _t = Int; t.name = Int; t = Int */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 9, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextLong",
            returnType = "Long",
            parameterTypes = listOf(),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
        
                val result = unwrappedReceiver.nextLong()
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 10, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextLong",
            returnType = "Long",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "until", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
                val until_ = (args[0] as LongValue).value
        
                val result = unwrappedReceiver.nextLong(until_)
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 11, col = 1),
        ),

        CustomFunctionDefinition(
            receiverType = "KRandom",
            functionName = "nextLong",
            returnType = "Long",
            parameterTypes = listOf(
                CustomFunctionParameter(name = "from", type = "Long"),
                CustomFunctionParameter(name = "until", type = "Long"),
            ),
            typeParameters = emptyList(),
            modifiers = setOf<FunctionModifier>(),
            inlineFunctionBody = null,
            inlineFunctionBodyFormat = null,
            executable = { interpreter, receiver, args, typeArgs ->
                val unwrappedReceiver = (receiver as KotlinValueHolder<*>).value as KRandom
                val from_ = (args[0] as LongValue).value
            val until_ = (args[1] as LongValue).value
        
                val result = unwrappedReceiver.nextLong(from_, until_)
                result?.let { LongValue(it /* _t = Long; t.name = Long; t = Long */, symbolTable = interpreter.symbolTable()) } ?: NullValue
            },
            position = SourcePosition(filename = "Random", lineNum = 12, col = 1),
        ),

    )
}
