package de.fabmax.kool.pipeline.backend.vk

import de.fabmax.kool.pipeline.ComputePass
import de.fabmax.kool.pipeline.ComputePipeline
import de.fabmax.kool.util.memStack

class ComputePipelineVk(
    val computePipeline: ComputePipeline,
    private val computeShaderModule: VkShaderModule,
    backend: RenderBackendVk,
) : PipelineVk(computePipeline, backend) {

    private val vkComputePipeline: VkComputePipeline = createComputePipelineVk()

    fun bind(task: ComputePass.Task, passEncoderState: PassEncoderState): Boolean {
        val pipelineData = computePipeline.capturedPipelineData
        if (!pipelineData.checkBindings()) {
            return false
        }

        passEncoderState.setComputePipeline(vkComputePipeline)
        val computeData = pipelineData.getOrCreateVkData()
        computeData.updateBuffers(passEncoderState)
        computeData.prepareBind(passEncoderState)
        passEncoderState.setBindGroup(computeData, pipelineLayout, BindPoint.Compute, groupIndex = 0)
        return true
    }

    private fun createComputePipelineVk(): VkComputePipeline = memStack {
        device.createComputePipeline(stack = this) {
            layout(pipelineLayout.handle)

            val code = computePipeline.shaderCode as ShaderCodeVk
            val stage = code.computeStage!!
            stage {
                it.`sType$Default`()
                it.stage(stage.stage)
                it.module(computeShaderModule.handle)
                it.pName(ASCII(stage.entryPoint))
            }
        }
    }

    override fun doRelease() {
        super.doRelease()
        backend.pipelineManager.removeComputePipeline(this)
        backend.device.destroyComputePipeline(vkComputePipeline)
    }
}